/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.DenunciaDao;
import Main.Alterar;
import Model.Denuncia;
import java.io.File;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Aluno
 */
public class AlterarController implements Initializable {

    @FXML
    private TextField txTelefone;

    @FXML
    private TextField txRua;

    @FXML
    private TextArea txDescricao;

    @FXML
    private Label lbId;

    @FXML
    private TextField txEstado;

    @FXML
    private TextField txCidade;

    @FXML
    private Button btAlterar;

    @FXML
    private ImageView imgFoto;

    @FXML
    private DatePicker dtDatadenuncia;

    @FXML
    private Button btCancelar;

    private static Denuncia denuncia2;

    private String caminhoFoto;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initDenuncia();

        btCancelar.setOnMouseClicked((MouseEvent e) -> {
            Alterar.getStage().close();
        });
        btAlterar.setOnMouseClicked((MouseEvent e) -> {
            atualiza();
        });
        imgFoto.setOnMouseClicked((MouseEvent e) -> {
            selecionaFoto();
        });
    }

    public void initDenuncia() {
        imgFoto.setImage(new Image("file:///" + denuncia2.getFoto()));
        txTelefone.setText(denuncia2.getTelefone());
        txEstado.setText(denuncia2.getEstado());
        txCidade.setText(denuncia2.getCidade());
        txRua.setText(denuncia2.getRua());
        txDescricao.setText(denuncia2.getDescricao());
        caminhoFoto = denuncia2.getFoto();
        lbId.setText(denuncia2.getId()+"");
        dtDatadenuncia.setValue(denuncia2.getDatadenuncia());
        
    }

    public static Denuncia getDenuncia2() {
        return denuncia2;
    }

    public static void setDenuncia2(Denuncia denuncia2) {
        AlterarController.denuncia2 = denuncia2;
    }

    public void atualiza() {
        
        Long id = Long.parseLong(lbId.getText());
        String telefone = txTelefone.getText(),
                estado = txEstado.getText(),
                cidade = txCidade.getText(),
                rua = txRua.getText(),
                descricao = txDescricao.getText();
        LocalDate data = dtDatadenuncia.getValue();
        if(txTelefone.getText().equals("") || txEstado.getText().equals("") || txCidade.getText().equals("") || txRua.getText().equals("")|| txDescricao.getText().equals("")|| dtDatadenuncia.getValue().equals("")){
        Alert erro = new Alert(Alert.AlertType.ERROR);
            erro.setHeaderText("Campos nulos!");
            erro.show();
    }else{
            DenunciaDao dao = new DenunciaDao();
           Denuncia d = new Denuncia(id,telefone, estado, cidade, rua, data, descricao, caminhoFoto);
            if(dao.update(d)){
            Alert cad = new Alert(Alert.AlertType.CONFIRMATION);
            cad.setHeaderText("Update da denuncia realizada");
            fecha();
            try {
                fecha();
                cad.show();

            } catch (Exception ex) {
                Logger.getLogger(CadastroController.class.getName()).log(Level.SEVERE, null, ex);
            }

        } else {
            Alert erro = new Alert(Alert.AlertType.ERROR);
            erro.setHeaderText("Update da Denuncia não realizada");
            erro.show();
        }
    }
        }
    
    public void fecha(){
        Alterar.getStage().close();
    }
     public void selecionaFoto() {
        FileChooser f = new FileChooser();
        f.getExtensionFilters().add(new FileChooser.ExtensionFilter("Imagens","*.jpg","*.png","*.jpeg"));
        File file = f.showOpenDialog(new Stage());
        if(file != null){
        imgFoto.setImage(new Image("file:///"+file.getAbsolutePath()));
        caminhoFoto = file.getAbsolutePath();
    }
}

}

