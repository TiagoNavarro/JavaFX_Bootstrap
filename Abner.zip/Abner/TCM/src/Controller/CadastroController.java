/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.PessoaDao;
import Main.Cadastro;
import Main.Item;
import Main.Login;
import Main.Tabela;
import Main.TabelaUser;
import Model.Pessoa;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.EventHandler;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Aluno
 */
public class CadastroController implements Initializable {

    @FXML
    private Button btDeletar;
    @FXML
    private Button btAlterar;
    @FXML
    private PasswordField psSenha;
    @FXML
    private Button btCadastrar;
    @FXML
    private Button btCancelar;
    @FXML
    private PasswordField psConfirmar;
    @FXML
    private TextField txNome;
    @FXML
    private TextField txEmail;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btCancelar.setOnMouseClicked(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent e) {
                Cadastro.getStage().close();
                Login login = new Login();
                Cadastro.getStage().close();
                try {
                    login.start(new Stage());
                } catch (Exception ex) {
                    Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        });

        btCadastrar.setOnMouseClicked(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent e) {
                cadastraPessoa();
            }
        });
    }

    private void cadastraPessoa() {
        String nome = txNome.getText(),
                email = txEmail.getText(),
                senha = psSenha.getText(),
                confirmacao = psConfirmar.getText();
        if(txNome.getText().equals("") || txEmail.getText().equals("") || psSenha.getText().equals("") || psConfirmar.getText().equals(""))
        {
           
            Alert erro = new Alert(Alert.AlertType.ERROR);
            erro.setHeaderText("Campos nulos!");
            erro.show();
            
        }else{
        if (senha.equals(confirmacao)) {
            Pessoa p = new Pessoa(nome, email, senha);
            PessoaDao dao = new PessoaDao();
            if (dao.add(p)) {

                Alert cad = new Alert(Alert.AlertType.CONFIRMATION);
                cad.setHeaderText("Bem-vindo!! "+nome);
                
                Cadastro.getStage().close();
                TabelaUser Tabela = new TabelaUser();
                try {
                    Tabela.start(new Stage());
                    Cadastro.getStage().close();
                    cad.show();

                } catch (Exception ex) {
                    Logger.getLogger(CadastroController.class.getName()).log(Level.SEVERE, null, ex);
                }

            } else {
                Alert erro = new Alert(Alert.AlertType.ERROR);
                erro.setHeaderText("Usuario não cadastrado ");
                erro.show();
            }
        } else {
            Alert erro = new Alert(Alert.AlertType.ERROR);
            erro.setHeaderText("Senhas não coincidem ");
            erro.show();

        }
        }
    }
}
