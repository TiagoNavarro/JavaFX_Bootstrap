/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.DenunciaDao;
import Model.Denuncia;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.PieChart;

/**
 * FXML Controller class
 *
 * @author Aluno
 */
public class GraficoController implements Initializable {

    @FXML
    private PieChart pieChart;
    private int or,ho,pu,dom,ind;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        calculagrafico();
        initGraph();
    }

    public void calculagrafico() {
        DenunciaDao dao = new DenunciaDao();
        List<Denuncia> denuncias = dao.getList();

        for (int x = 0; x < denuncias.size(); x++) {
            if (denuncias.get(x).getCidade().toLowerCase().equals("curitiba")) {
                or++;
            } else if (denuncias.get(x).getCidade().toLowerCase().equals("quatro barras")) {
                ho++;

            } else if (denuncias.get(x).getCidade().toLowerCase().equals("colombo")) {
                pu++;

            } else if (denuncias.get(x).getCidade().toLowerCase().equals("campina grande do sul")) {
                dom++;
            }
        }
    }

    public void initGraph() {
        pieChart.getData().addAll(new PieChart.Data("Quatro Barras("+ho+")", ho),
                new PieChart.Data("Colombo ("+pu+")", pu),
                new PieChart.Data("Campina Grande do Sul ("+dom+")", dom),
                new PieChart.Data("Curitiba("+or+")",or));
    }

}
