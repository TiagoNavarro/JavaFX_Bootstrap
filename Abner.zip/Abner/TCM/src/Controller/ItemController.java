/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.DenunciaDao;
import Main.Cadastro;
import Main.Item;
import Main.Login;
import Main.Tabela;
import Model.Denuncia;
import java.io.File;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.EventHandler;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Aluno
 */
public class ItemController implements Initializable {

    @FXML
    private Button btDenunciar;

    @FXML
    private TextArea txDescricao;

    @FXML
    private TextField txTelefone;

    @FXML
    private TextField txRua;
    @FXML
    private TextField txEstado;

    @FXML
    private TextField txCidade;

    @FXML
    private DatePicker dtDatadenuncia;

    @FXML
    private Button btCancelar;

    @FXML
    private Label lbID;

    @FXML
    private Label lbNome;

    @FXML
    private Label lbEmail;

    @FXML
    private ImageView imgFoto;
    
    private String caminhoFoto;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btDenunciar.setOnMouseClicked((MouseEvent e) -> {
            denuncia();
        });

        btDenunciar.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER) {
                denuncia();
            }
        });
        btCancelar.setOnMouseClicked((MouseEvent e) -> {
            fecha();
        });
        btCancelar.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER) {
                fecha();
            }
        });
        imgFoto.setOnMouseClicked((MouseEvent e) -> {
            selecionaFoto();
        });

    }

    public void denuncia() {
        String estado = txEstado.getText(), cidade = txCidade.getText(), rua = txRua.getText(), telefone = txTelefone.getText(), descricao = txDescricao.getText();
        LocalDate data = dtDatadenuncia.getValue();
       if(txTelefone.getText().equals("") || txEstado.getText().equals("") || txCidade.getText().equals("") || txRua.getText().equals("")|| txDescricao.getText().equals("")|| dtDatadenuncia.getValue().equals(""))
        {
            Alert erro = new Alert(Alert.AlertType.ERROR);
            erro.setHeaderText("Campos nulos!");
            erro.show();
        }else{
            
        

        Denuncia den = new Denuncia(telefone, estado, cidade, rua, data, descricao, caminhoFoto);
        DenunciaDao dao = new DenunciaDao();
        if (dao.add(den)) {

            Alert cad = new Alert(Alert.AlertType.CONFIRMATION);
            cad.setHeaderText("Denuncia realizada");

            fecha();
            try {
                fecha();
                cad.show();

            } catch (Exception ex) {
                Logger.getLogger(CadastroController.class.getName()).log(Level.SEVERE, null, ex);
            }

        } else {
            Alert erro = new Alert(Alert.AlertType.ERROR);
            erro.setHeaderText("Denuncia não realizada");
            erro.show();
        }
    }
    }

    public void fecha() {
        Item.getStage().close();
        try {
        } catch (Exception ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void selecionaFoto() {
        FileChooser f = new FileChooser();
        f.getExtensionFilters().add(new ExtensionFilter("Imagens","*.jpg","*.png","*.jpeg"));
        File file = f.showOpenDialog(new Stage());
        if(file != null){
        imgFoto.setImage(new Image("file:///"+file.getAbsolutePath()));
        caminhoFoto = file.getAbsolutePath();
    }
}
}
