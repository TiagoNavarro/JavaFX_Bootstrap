/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.PessoaDao;
import Main.Cadastro;
import Main.Login;
import Main.Tabela;
import Main.TabelaUser;
import Model.Pessoa;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 *
 * @author Aluno
 */
public class LoginController implements Initializable {

    @FXML
    private TextField textsenha;

    @FXML
    private TextField textuser;

    @FXML
    private Button btSair;

    @FXML
    private Button btEntrar;

    @FXML
    private Button btNovo;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btEntrar.setOnMouseClicked((MouseEvent e) -> {
            logar();
        });
        btEntrar.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER) {
                logar();
            }
        });
        textsenha.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER) {
                logar();
            }
        });
        btSair.setOnMouseClicked((MouseEvent e) -> {
            fecha();
        });

        btSair.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER) {
                fecha();
            }
        });

        btNovo.setOnMouseClicked(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent e) {
                Login.getStage().close();
                Cadastro cadastro = new Cadastro();
                Login.getStage().close();
                try {
                    cadastro.start(new Stage());
                } catch (Exception ex) {
                    Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    public void fecha() {
        Login.getStage().close();
    }

    public void logar() {
        if (textuser.getText().equals("") || textsenha.getText().equals("")) {
             Alert alert = new Alert(AlertType.ERROR);
                    alert.setHeaderText("Campos nulos!");
                    alert.setTitle("ERRO");
                    alert.setContentText("O ERRO aconteceu devido aos campos estarem nulos");
                    alert.show();
        } else {
        
        
        if (textuser.getText().equals("admin") && textsenha.getText().equals("admin")) {
            Tabela p = new Tabela();
            try {
                fecha();
                p.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {

            PessoaDao dao = new PessoaDao();
            List<Pessoa> pessoas = dao.getList();

            for (int x = 0; x < pessoas.size(); x++) {
                if (textuser.getText().equals(pessoas.get(x).getEmail()) && textsenha.getText().equals(pessoas.get(x).getSenha())) {
                    TabelaUser t = new TabelaUser();
                    x = pessoas.size();
                    fecha();
                    try {
                        t.start(new Stage());
                    } catch (Exception ex) {
                        Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else if (x == pessoas.size() - 1) {

                    Alert alert = new Alert(AlertType.ERROR);
                    alert.setHeaderText("Login inválido");
                    alert.setTitle("ERRO");
                    alert.setContentText("O ERRO aconteceu devido ao usúario ser invalido");
                    alert.show();
                    textsenha.clear();
                    textuser.clear();
                }
            }
        }
        
        }
    }
}
