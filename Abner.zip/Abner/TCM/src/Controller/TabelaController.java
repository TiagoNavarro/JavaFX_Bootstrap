/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.DenunciaDao;
import Main.Alterar;
import Main.Cadastro;
import Main.Grafico;
import Main.Item;
import Main.Tabela;
import Main.TabelaUser;
import Model.Denuncia;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import static javafx.collections.FXCollections.observableList;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import Main.Login;

/**
 * FXML Controller class
 *
 * @author Aluno
 */
public class TabelaController implements Initializable {

    @FXML
    private Button btPdf;

    @FXML
    private Button btPesquisa;
    @FXML
    private Button btLogoff;
    @FXML
    private TextField txPesquisa;

    @FXML
    private Button btGrafico;

    @FXML
    private Button btAlterar;

    @FXML
    private Button btAtualizar;

    @FXML
    private Button btItem;

    @FXML
    private Button btGerarPDF;

    @FXML
    private Button btDeItem;
    @FXML
    private ImageView imgFoto;

    @FXML
    private TableView<Denuncia> tabela;

    @FXML
    private TableColumn<Denuncia, String> clmDescrição;

    @FXML
    private TableColumn<Denuncia, String> clmEstado;

    @FXML
    private TableColumn<Denuncia, String> clmRua;

    @FXML
    private TableColumn<Denuncia, String> clmCidade;

    @FXML
    private TableColumn<Denuncia, Long> clmID;

    @FXML
    private TableColumn<Denuncia, LocalDate> clmData;

    @FXML
    private TableColumn<Denuncia, String> clmTelefone;

    private Denuncia selecionada;

    private ObservableList<Denuncia> denuncias = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initTable();

        btDeItem.setOnMouseClicked((MouseEvent e) -> {
            deleta();
        });
        btDeItem.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER) {
                deleta();
            }
        });
        btAtualizar.setOnMouseClicked((MouseEvent e) -> {
            tabela.setItems(atualizaTabela());
        });
        btAtualizar.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER) {
                tabela.setItems(atualizaTabela());
            }
        });
        btItem.setOnMouseClicked((MouseEvent e) -> {
            denunciar();
        });
        btItem.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER) {
                denunciar();
            }
        });
        btLogoff.setOnMouseClicked((MouseEvent e) -> {
             Tabela.getStage().close();
                Login login = new Login();
                try {
                    login.start(new Stage());
                    Tabela.getStage().close();
                } catch (Exception ex) {
                    Logger.getLogger(TabelaController.class.getName()).log(Level.SEVERE, null, ex);
                }
        });
        btLogoff.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER) {
                 Tabela.getStage().close();
                Login login = new Login();
                try {
                    login.start(new Stage());
                    Tabela.getStage().close();
                } catch (Exception ex) {
                    Logger.getLogger(TabelaController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        btAlterar.setOnMouseClicked((MouseEvent e) -> {
            if (selecionada != null) {
                Alterar alt = new Alterar(selecionada);
                try {
                    alt.start(new Stage());
                } catch (Exception ex) {
                    Logger.getLogger(TabelaController.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                Alert a = new Alert(AlertType.WARNING);
                a.setHeaderText("selecione uma denúncia");
                a.show();
            }
        });
        btItem.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER) {
                denunciar();
            }
        });
        btPesquisa.setOnMouseClicked((MouseEvent e) -> {
            tabela.setItems(busca());
        });
        btPesquisa.setOnKeyPressed((KeyEvent e) -> {
            tabela.setItems(busca());
        });
        txPesquisa.setOnKeyReleased((KeyEvent e) -> {
            tabela.setItems(busca());
        });
        btGerarPDF.setOnMouseClicked((MouseEvent e) -> {
            gerarPDF();
        });
         btGerarPDF.setOnKeyPressed((KeyEvent e) -> {
             gerarPDF();
        });
        
        btGrafico.setOnMouseClicked((MouseEvent e) -> {
            Grafico grafico = new Grafico();
        try {
            grafico.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(TabelaController.class.getName()).log(Level.SEVERE, null, ex);
        }
     
        });

        tabela.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                selecionada = (Denuncia) newValue;
                mostraDetalhes();
            }
        });

    }

    public void initTable() {
        clmID.setCellValueFactory(new PropertyValueFactory("id"));
        clmTelefone.setCellValueFactory(new PropertyValueFactory("telefone"));
        clmEstado.setCellValueFactory(new PropertyValueFactory("estado"));
        clmCidade.setCellValueFactory(new PropertyValueFactory("cidade"));
        clmRua.setCellValueFactory(new PropertyValueFactory("rua"));
        clmData.setCellValueFactory(new PropertyValueFactory("datadenuncia"));
        clmDescrição.setCellValueFactory(new PropertyValueFactory("descricao"));
        tabela.setItems(atualizaTabela());
    }

    public ObservableList<Denuncia> atualizaTabela() {
        DenunciaDao dao = new DenunciaDao();
        denuncias = FXCollections.observableArrayList(dao.getList());
        return denuncias;
    }

    public void deleta() {
        if (selecionada != null) {
            DenunciaDao dao = new DenunciaDao();
            dao.delete(selecionada);
            Alert a = new Alert(AlertType.CONFIRMATION);
            a.setHeaderText("Denúncia deletada com sucesso");
            a.show();
            tabela.setItems(atualizaTabela());
        } else {
            Alert a = new Alert(AlertType.WARNING);
            a.setHeaderText("selecione uma denúncia");
            a.show();
        }
    }

    public void denunciar() {
        Item Item = new Item();
        try {
            Item.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(TabelaController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void mostraDetalhes() {
        if (selecionada != null) {
            imgFoto.setImage(new Image("File:///" + selecionada.getFoto()));
        } else {
            imgFoto.setImage(new Image("/Imagem/transparente.png.png"));
        }
    }

    private ObservableList<Denuncia> busca() {
        ObservableList<Denuncia> denunciaPesquisa = FXCollections.observableArrayList();
        for (int x = 0; x < denuncias.size(); x++) {
            if (denuncias.get(x).getCidade().toLowerCase().contains(txPesquisa.getText().toLowerCase())) {
                denunciaPesquisa.add(denuncias.get(x));
            }
        }
        return denunciaPesquisa;
    }

    public void gerarPDF() {
        Document doc = new Document();
        FileChooser f = new FileChooser();
        f.getExtensionFilters().add(new ExtensionFilter("PDF", "*.pdf"));
        File file = f.showSaveDialog(new Stage());
        if (file != null) {
            try {
                PdfWriter.getInstance(doc, new FileOutputStream(file.getAbsolutePath()));
                doc.open();
                List<Denuncia> denuncias = new DenunciaDao().getList();
                for (int x = 0; x < denuncias.size(); x++) {
                    doc.add(new Paragraph("ID: " + denuncias.get(x).getId()));
                    doc.add(new Paragraph("Telefone: " + denuncias.get(x).getTelefone()));
                    doc.add(new Paragraph("Estado: " + denuncias.get(x).getEstado()));
                    doc.add(new Paragraph("Cidade: " + denuncias.get(x).getCidade()));
                    doc.add(new Paragraph("Rua: " + denuncias.get(x).getRua()));
                    doc.add(new Paragraph("Data da denúncia: " + denuncias.get(x).getDatadenuncia().toString()));
                    doc.add(new Paragraph("Descrição: " + denuncias.get(x).getDescricao()));
                    doc.add(new Paragraph("Local da Foto: " + denuncias.get(x).getFoto()));
                    doc.add(new Paragraph("                                            "));
                }
                doc.close();
                Alert a = new Alert(AlertType.CONFIRMATION);
                a.setHeaderText("PDF gerado com sucesso");
                a.show();
            } catch (DocumentException ex) {
                Logger.getLogger(TabelaController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(TabelaController.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            Alert a = new Alert(AlertType.WARNING);
            a.setHeaderText("Defina um local para salvar o arquivo");
            a.show();
        }

    }
}
