/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.DenunciaDao;
import Main.Item;
import Main.Login;
import Main.Tabela;
import Main.TabelaUser;
import Model.Denuncia;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Aluno
 */
public class TabelaUserController implements Initializable {

    @FXML private Button btItem;
    @FXML private Button btPerfil;
    @FXML private Button btDeItem;
     @FXML private Button btPesquisa;
     @FXML private Button btLogoff;
      @FXML private TextField txPesquisa;
    @FXML
    private Button btAtualizar;
     @FXML
    private TableView<Denuncia> tabela;
     @FXML
    private ImageView imgFoto;

    @FXML
    private TableColumn<Denuncia, String> clmDescricao;

    @FXML
    private TableColumn<Denuncia, String> clmEstado;

    @FXML
    private TableColumn<Denuncia, String> clmRua;

    @FXML
    private TableColumn<Denuncia, String> clmCidade;

    @FXML
    private TableColumn<Denuncia, Long> clmID;

    @FXML
    private TableColumn<Denuncia, LocalDate> clmData;

    @FXML
    private TableColumn<Denuncia, String> clmTelefone;
    
    private Denuncia selecionada;

    private ObservableList<Denuncia> denuncias = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
         btLogoff.setOnMouseClicked((MouseEvent e) -> {
             TabelaUser.getStage().close();
                Login login = new Login();
                try {
                    login.start(new Stage());
                    TabelaUser.getStage().close();
                } catch (Exception ex) {
                    Logger.getLogger(TabelaUser.class.getName()).log(Level.SEVERE, null, ex);
                }
        });
        btLogoff.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER) {
               TabelaUser.getStage().close();
                Login login = new Login();
                try {
                    login.start(new Stage());
                    TabelaUser.getStage().close();
                } catch (Exception ex) {
                    Logger.getLogger(TabelaUser.class.getName()).log(Level.SEVERE, null, ex);
                } 
            }
        });
        
        btItem.setOnMouseClicked((MouseEvent e) -> {
            denunciar();
        });
        inittTable();
        btItem.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER) {
                denunciar();
            }
        });
         btAtualizar.setOnMouseClicked((MouseEvent e) -> {
            tabela.setItems(atualizarTabela());
        });
        btAtualizar.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER) {
                tabela.setItems(atualizarTabela());
            }
        });
         tabela.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                selecionada = (Denuncia) newValue;
                mostraDetalhes();
            }
        });
         btPesquisa.setOnMouseClicked((MouseEvent e) -> {
            tabela.setItems(busca());
        });
        btPesquisa.setOnKeyPressed((KeyEvent e) -> {
            tabela.setItems(busca());
        });
        txPesquisa.setOnKeyReleased((KeyEvent e) -> {
            tabela.setItems(busca());
        });
         
        
    }
  public void inittTable() {
        clmID.setCellValueFactory(new PropertyValueFactory("id"));
        clmTelefone.setCellValueFactory(new PropertyValueFactory("telefone"));
        clmEstado.setCellValueFactory(new PropertyValueFactory("estado"));
        clmCidade.setCellValueFactory(new PropertyValueFactory("cidade"));
        clmRua.setCellValueFactory(new PropertyValueFactory("rua"));
        clmData.setCellValueFactory(new PropertyValueFactory("datadenuncia"));
        clmDescricao.setCellValueFactory(new PropertyValueFactory("descricao"));
        tabela.setItems(atualizarTabela());
    }
    
    
     public void denunciar() {
        Item Item = new Item();
        try {
            Item.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(TabelaUserController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     public ObservableList<Denuncia> atualizarTabela() {
         DenunciaDao dao = new DenunciaDao();
        denuncias = FXCollections.observableArrayList(dao.getList());
        return denuncias;
    }
       public void mostraDetalhes() {
        if (selecionada != null) {
            imgFoto.setImage(new Image("File:///"+selecionada.getFoto()));
        } else {
            imgFoto.setImage(new Image("/Imagem/transparente.png.png"));
        }
    }
         private ObservableList<Denuncia> busca() {
        ObservableList<Denuncia> denunciaPesquisa = FXCollections.observableArrayList();
        for (int x = 0; x < denuncias.size(); x++) {
            if (denuncias.get(x).getCidade().toLowerCase().contains(txPesquisa.getText().toLowerCase())) {
                denunciaPesquisa.add(denuncias.get(x));
            }
        }
        return denunciaPesquisa;
    }
}
