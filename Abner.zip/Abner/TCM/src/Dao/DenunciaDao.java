/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import JDBC.ConnectionFactory;
import Model.Denuncia;
import Model.Pessoa;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Um mundo melhor
 */
public class DenunciaDao {

    private Connection con;

    public DenunciaDao() {
        this.con = new ConnectionFactory().getConnection();
    }

    public boolean add(Denuncia d) {
        String sql = "INSERT INTO denuncia(telefone,estado,cidade,rua,datadenuncia,descricao,foto) VALUES (?,?,?,?,?,?,?);";

        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, d.getTelefone());
            stmt.setString(2, d.getEstado());
            stmt.setString(3, d.getCidade());
            stmt.setString(4, d.getRua());
            stmt.setDate(5, Date.valueOf(d.getDatadenuncia()));
            stmt.setString(6, d.getDescricao());
            stmt.setString(7, d.getFoto());
            stmt.execute();
            stmt.close();
            con.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DenunciaDao.class.getName()).log(Level.SEVERE, null, ex);
            ex.printStackTrace();
            return false;
        }
    }

    public boolean update(Denuncia d) {
        String sql = "UPDATE denuncia SET telefone = ?, estado = ?, cidade = ?, rua = ?, datadenuncia = ?, descricao = ?, foto = ? WHERE id=?;";

        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, d.getTelefone());
            stmt.setString(2, d.getEstado());
            stmt.setString(3, d.getCidade());
            stmt.setString(4, d.getRua());
            stmt.setDate(5, Date.valueOf(d.getDatadenuncia()));
            stmt.setString(6, d.getDescricao());
            stmt.setString(7, d.getFoto());
            stmt.setLong(8, d.getId());
            stmt.execute();
            stmt.close();
            con.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DenunciaDao.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
     public boolean delete(Denuncia d) {
        String sql = "DELETE FROM denuncia WHERE id=?;";

        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setLong(1, d.getId());
            stmt.execute();
            stmt.close();
            con.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DenunciaDao.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

   

    public List<Denuncia> getList() {
        List<Denuncia> denuncias = new ArrayList<>();
        String sql = "SELECT * FROM denuncia";
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Denuncia d = new Denuncia();
                d.setId(rs.getLong("id"));//Essa string por paramentro é o nome da coluna la do banco
                d.setTelefone(rs.getString("telefone"));
                d.setEstado(rs.getString("estado"));
                d.setCidade(rs.getString("cidade"));
                d.setRua(rs.getString("rua"));
                Date data = Date.valueOf(rs.getString("datadenuncia"));
                d.setDatadenuncia(data.toLocalDate());
                d.setDescricao(rs.getString("descricao"));
                d.setFoto(rs.getString("foto"));
                
                denuncias.add(d);
            }
            stmt.close();
            rs.close();
            con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("ERRO, Lista não foi retornada");
            return null;
        }
        return denuncias;
    }
}
