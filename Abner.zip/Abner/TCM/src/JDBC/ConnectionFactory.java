/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Aluno
 */
public class ConnectionFactory {
  public Connection getConnection(){
        try {
            String nomeUsuario = "postgres";//Usuário do servidor(Padrão)
            String senhaUsuario = "12345";//Senha do Servidor
            String enderecoServidor ="localhost";
            String nomeBanco = "abner";
            
            return DriverManager.getConnection("jdbc:postgresql://"+enderecoServidor+
                    "/"+nomeBanco, nomeUsuario, senhaUsuario);
        } catch (SQLException ex) {
            System.out.println("ERRO, NÃO ABRI CONEXÃO ");
            throw new RuntimeException(ex);
        }
        
    }
    
}
