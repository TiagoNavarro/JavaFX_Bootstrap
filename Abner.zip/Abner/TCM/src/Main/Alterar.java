/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import Controller.AlterarController;
import Model.Denuncia;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 *
 * @author Aluno
 */
public class Alterar extends Application {

    static Stage stage;
    public Alterar(Denuncia d1){
        AlterarController.setDenuncia2(d1);
    }
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/View/Alterar.fxml"));
        
        Scene scene = new Scene(root);
        stage.setTitle("Alterar Denúncia");
        stage.getIcons().add(new Image("Imagem/images.jpg"));
        stage.setScene(scene);
        stage.show();
        Alterar.stage = stage;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    public static Stage getStage(){
        return Alterar.stage;
    }
    
    public void setStage(Stage s){
        Alterar.stage = s;
    }
    
    
}
