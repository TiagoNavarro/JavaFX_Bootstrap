/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 *
 * @author Aluno
 */
public class Grafico extends Application {

    static Stage stage;
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/View/Grafico.fxml"));
        
        Scene scene = new Scene(root);
        stage.setTitle("Grafico");
        stage.getIcons().add(new Image("Imagem/images.jpg"));
        stage.setScene(scene);
        stage.show();
        Login.stage = stage;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    public static Stage getStage(){
        return Grafico.stage;
    }
    
    public void setStage(Stage s){
        Grafico.stage = s;
    }
    
}
