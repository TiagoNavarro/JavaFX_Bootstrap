/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.time.LocalDate;

/**
 *
 * @author Aluno
 */
public class Denuncia {
    private Long id;  
    private String telefone;
    private String estado;
    private String cidade;
    private String rua;
    private LocalDate datadenuncia;
    private String descricao;
    private String foto;
    
    

    public Denuncia() {
    }

    public Denuncia(Long id, String telefone, String estado, String cidade, String rua, LocalDate Datadenuncia, String descricao, String foto) {
        this.id = id;
        this.telefone = telefone;
        this.estado = estado;
        this.cidade = cidade;
        this.rua = rua;
        this.datadenuncia = Datadenuncia;
        this.descricao = descricao;
        this.foto = foto;
    }

    public Denuncia(String telefone, String estado, String cidade, String rua, LocalDate Datadenuncia, String descricao, String foto) {
        this.telefone = telefone;
        this.estado = estado;
        this.cidade = cidade;
        this.rua = rua;
        this.datadenuncia = Datadenuncia;
        this.descricao = descricao;
        this.foto = foto;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the telefone
     */
    public String getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    /**
     * @return the estado
     */
    public String getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * @return the cidade
     */
    public String getCidade() {
        return cidade;
    }

    /**
     * @param cidade the cidade to set
     */
    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    /**
     * @return the rua
     */
    public String getRua() {
        return rua;
    }

    /**
     * @param rua the rua to set
     */
    public void setRua(String rua) {
        this.rua = rua;
    }

    /**
     * @return the Datadenuncia
     */
    public LocalDate getDatadenuncia() {
        return datadenuncia;
    }

    /**
     * @param Datadenuncia the Datadenuncia to set
     */
    public void setDatadenuncia(LocalDate Datadenuncia) {
        this.datadenuncia = Datadenuncia;
    }

    /**
     * @return the descricao
     */
    public String getDescricao() {
        return descricao;
    }

    /**
     * @param descricao the descricao to set
     */
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    
    
    
    
    
}
