/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import static Control.UsuarioAdmController.user;
import Dao.UsuarioDao;
import Model.Usuario;
import Util.AbreFechaTelas;
import Util.Alerta;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author Usuário
 */
public class G_UsuarioController implements Initializable,Controls {
    @FXML private TextField txNumero;
    @FXML private PasswordField psCSenha;
    @FXML private TextField txUsuario;

    @FXML private TextField txEndereço;
    @FXML private PasswordField psSenha;
    @FXML private Button btAtualizar;
    @FXML private TextField txNome;
    @FXML private TextField txEmail;
    @FXML private Button btCancelar;
    public static Usuario user;
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initActions();
        initTexto();
    }    

    @Override
    public void initActions() {
        initActionsMouse();
        initActionsKey();
    }

    @Override
    public void initActionsMouse() {
        btAtualizar.setOnMouseClicked((MouseEvent e)->{
            if(e.getButton() == MouseButton.PRIMARY){
                atualizar();
            }
        });
                
        btCancelar.setOnMouseClicked((MouseEvent e)->{
            if(e.getButton() == MouseButton.PRIMARY){
                AbreFechaTelas.fechaTelaG_Usuario();
            }
        });
    }

    @Override
    public void initActionsKey() {
    
    }
    
    public void initTexto(){
        txNome.setText(user.getNome());
        txEndereço.setText(user.getEndereco());
        txNumero.setText(user.getNumero().toString());
        txEmail.setText(user.getEmail());
        txUsuario.setText(user.getUsuario());
        psSenha.setText(user.getSenha());
        psCSenha.setText(user.getSenha());
    }
    
    public void atualizar(){
        String nome = txNome.getText(),endereco = txEndereço.getText(),numeroT = txNumero.getText(),email = txEmail.getText(),
                usuario = txUsuario.getText(),senha = psSenha.getText(),confirmacao = psCSenha.getText();
        
        if(nome.equals("")){
            Alerta.error("Preencha o Nome");
        }else if(endereco.equals("")){
            Alerta.error("Preencha o Endereço");    
        }else if(numeroT.equals("")){
            Alerta.error("Preencha o Número");
        }else if(email.equals("")){
            Alerta.error("Preencha o email");
        }else if(usuario.equals("")){
            Alerta.error("Preencha o usuário");
        }else if(senha.equals("")){
            Alerta.error("Preencha o senha");
        }else if(confirmacao.equals("")){
            Alerta.error("Preencha o confirmação da senha");
        }else if(!senha.equals(confirmacao)){
            Alerta.error("As senhas não coincidem");
        }else{
            try{
                int numero = Integer.parseInt(numeroT);
                    Usuario a = new Usuario(user.getId(),nome,endereco,numero,email,usuario,senha,user.getValorConta());
                    UsuarioDao dao = new UsuarioDao();
                    if(dao.update(a)){
                        Alerta.confirmation("Usuário Atualizado com sucesso!");
                        PrincipalUsuarioController.user = a;
                        AbreFechaTelas.fechaTelaG_Usuario();
                    }
            }catch(NumberFormatException e){
                Alerta.error("Número Inválido");
            }
       }
    }
    
}
