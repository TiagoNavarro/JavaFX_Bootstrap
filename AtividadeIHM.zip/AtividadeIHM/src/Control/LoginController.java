/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Dao.UsuarioDao;
import Main.Login;
import Model.Usuario;
import Util.AbreFechaTelas;
import Util.Alerta;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author Usuário
 */
public class LoginController implements Initializable,Controls {
    @FXML private Button btEntrar;
    @FXML private TextField txUsuario;
    @FXML private PasswordField psSenha;
    @FXML  private Button btNovo;
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initActions();
    }    

    @Override
    public void initActions() {
        initActionsMouse();
        initActionsKey();
    }

    @Override
    public void initActionsMouse() {
        btNovo.setOnMouseClicked((MouseEvent e)->{
            if(e.getButton() == MouseButton.PRIMARY){
                AbreFechaTelas.abreTelaNovoUsuario();
                Login.getStage().close();
                
            }
        });
        
        btEntrar.setOnMouseClicked((MouseEvent e)->{
            if(e.getButton() == MouseButton.PRIMARY){
                logar();
            }
        });
    }

    @Override
    public void initActionsKey() {
        
    }
    
    public void logar(){
        String nome = txUsuario.getText();
        String senha = psSenha.getText();
        
        if(nome.equals("admin")){
            if(senha.equals("admin")){
                AbreFechaTelas.abreTelaPrincipalAdm();
                AbreFechaTelas.fechaTelaLogin();
            }
        }else{
            UsuarioDao dao = new UsuarioDao(); 
            List<Usuario> usuarios = FXCollections.observableArrayList(dao.getList());
            for(int x = 0;x< usuarios.size();x++){
                if(nome.equals(usuarios.get(x).getUsuario())){
                    if(senha.equals(usuarios.get(x).getSenha())){
                            AbreFechaTelas.abreTelaPrincipalUsuario(usuarios.get(x));
                            AbreFechaTelas.fechaTelaLogin();
                    }else{
                    
                    }
                }else{
                    if(x+1 == usuarios.size()){
                        Alerta.error("Usuário ou/e senha inválidas");
                    }
                }
            }
        }
        
        
    }
    
}
