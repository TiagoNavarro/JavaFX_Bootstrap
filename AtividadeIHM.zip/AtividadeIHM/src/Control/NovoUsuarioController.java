/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Dao.UsuarioDao;
import Main.NovoUsuario;
import Model.Usuario;
import Util.AbreFechaTelas;
import Util.Alerta;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author Usuário
 */
public class NovoUsuarioController implements Initializable,Controls {
    @FXML private TextField txNumero;
    @FXML private PasswordField psCSenha;
    @FXML private TextField txUsuario;
    @FXML private TextField txConta;
    @FXML private TextField txEndereço;
    @FXML private PasswordField psSenha;
    @FXML private Button btCadastrar;
    @FXML private TextField txNome;
    @FXML private TextField txEmail;
    @FXML private Button btCancelar;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initActions();
    }    

    @Override
    public void initActions() {
        initActionsMouse();
        initActionsKey();
    }

    @Override
    public void initActionsMouse() {
        btCancelar.setOnMouseClicked((MouseEvent e)->{
            if(e.getButton() == MouseButton.PRIMARY){
                AbreFechaTelas.abreTelaLogin();
                NovoUsuario.getStage().close();
            }
        });
    
        btCadastrar.setOnMouseClicked((MouseEvent e)->{
            if(e.getButton() == MouseButton.PRIMARY){
                cadastrar();
            }
        });
    }

    public void cadastrar(){
        String nome = txNome.getText(),endereco = txEndereço.getText(),numeroT = txNumero.getText(),email = txEmail.getText(),
                usuario = txUsuario.getText(),senha = psSenha.getText(),confirmacao = psCSenha.getText(),valorT = txConta.getText();
        
        if(nome.equals("")){
            Alerta.error("Preencha o nome");
        }else if(endereco.equals("")){
            Alerta.error("Preencha o Endereço");    
        }else if(numeroT.equals("")){
            Alerta.error("Preencha o Número");
        }else if(email.equals("")){
            Alerta.error("Preencha o email");
        }else if(usuario.equals("")){
            Alerta.error("Preencha o usuário");
        }else if(senha.equals("")){
            Alerta.error("Preencha o senha");
        }else if(confirmacao.equals("")){
            Alerta.error("Preencha o confirmação da senha");
        }else if(!senha.equals(confirmacao)){
            Alerta.error("As senhas não coincidem");
        }else if(valorT.equals("")){
            Alerta.error("Preencha o valor da conta");
        }else{
            try{
                int numero = Integer.parseInt(numeroT);
                try{
                    double valor = Double.parseDouble(valorT);
                    Usuario a = new Usuario(nome,endereco,numero,email,usuario,senha,valor);
                    UsuarioDao dao = new UsuarioDao();
                    if(dao.add(a)){
                        Alerta.confirmation("Usuário Cadastrado com sucesso!");
                        AbreFechaTelas.abreTelaLogin();
                        AbreFechaTelas.fechaTelaNovoUsuario();
                    }
                    
                    
                }catch(NumberFormatException e){
                    Alerta.error("Valor Inválido");
                }
            }catch(NumberFormatException e){
                Alerta.error("Número Inválido");
            }
       }
        
        
        
    }
    
    
    @Override
    public void initActionsKey() {
    
    }
    
}
