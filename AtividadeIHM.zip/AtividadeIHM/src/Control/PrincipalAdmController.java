/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Dao.UsuarioDao;
import Model.Usuario;
import Util.AbreFechaTelas;
import Util.Alerta;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Tooltip;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;


/**
 * FXML Controller class
 *
 * @author Usuário
 */
public class PrincipalAdmController implements Initializable,Controls {
    @FXML private Button btRelatorio;
    @FXML private Button btUsuario;
    @FXML private Button btAtt;
    @FXML private TableView<Usuario> tabela;
    @FXML private TableColumn<Usuario, Double> clmConta;
    @FXML private TableColumn<Usuario, String> clmNome;
    @FXML private TableColumn<Usuario, String> clmUsuario;
    @FXML private TableColumn<Usuario, Long> clmID;
    @FXML private TableColumn<Usuario, String> clmEndereco;
    @FXML private TableColumn<Usuario, Integer> clmNumero;
    @FXML private TableColumn<Usuario, String> clmEmail;
    @FXML private Button btValor;
    private static Usuario user;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initActions();
        preencheTabela();
        btRelatorio.setTooltip(new Tooltip("(Não precisava no Original) Caminho do arquivo : C:/User/Public/pdf.pdf"));
    }    

    @Override
    public void initActions() {
        initActionsMouse();
        initActionsKey();
        
        tabela.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                if(newValue != null){
                    PrincipalAdmController.user = (Usuario) newValue;
                }
            }
        });
        
        
    }

    @Override
    public void initActionsMouse() {
        btAtt.setOnMouseClicked((MouseEvent e)->{
            if(e.getButton() == MouseButton.PRIMARY){
                atualizaTabela();
            }
        });
        
        btValor.setOnMouseClicked((MouseEvent e)->{
            if(e.getButton() == MouseButton.PRIMARY){
                gerenciarValor();
            }
        });
        
        btUsuario.setOnMouseClicked((MouseEvent e)->{
            if(e.getButton() == MouseButton.PRIMARY){
                gerenciarUsuario();
            }
        });
        
        btRelatorio.setOnMouseClicked((MouseEvent e)->{
            if(e.getButton() == MouseButton.PRIMARY){
                gerenciarRelatorio();
            }
        });
    }

    @Override
    public void initActionsKey() {
    
    }
    
    public void preencheTabela(){
        clmID.setCellValueFactory(new PropertyValueFactory("id"));
        clmNome.setCellValueFactory(new PropertyValueFactory("nome"));
        clmEndereco.setCellValueFactory(new PropertyValueFactory("endereco"));
        clmNumero.setCellValueFactory(new PropertyValueFactory("numero"));
        clmEmail.setCellValueFactory(new PropertyValueFactory("email"));
        clmUsuario.setCellValueFactory(new PropertyValueFactory("usuario"));
        clmConta.setCellValueFactory(new PropertyValueFactory("valorConta"));
        atualizaTabela();
        
    }
    
    public void atualizaTabela(){
        UsuarioDao dao = new UsuarioDao();
        ObservableList<Usuario> users = FXCollections.observableArrayList(dao.getList());
        tabela.setItems(users);
    }
    
    public void gerenciarValor(){
        if(PrincipalAdmController.user != null){
            AbreFechaTelas.abreTelaValorAdm(PrincipalAdmController.user);
        }else{
            Alerta.error("Selecione um item da lista");
        }
    }
    
    
    public void gerenciarUsuario(){
        if(PrincipalAdmController.user != null){
            AbreFechaTelas.abreTelaUsuarioAdm(PrincipalAdmController.user);
        }else{
            Alerta.error("Selecione um item da lista");
        }
    }
    
    public void gerenciarRelatorio(){
        Document a = new Document();
        try {
            PdfWriter.getInstance(a, new FileOutputStream("C:/Users/Tiago/Desktop/relatorio.pdf"));
            a.open();
            UsuarioDao dao = new UsuarioDao();
            List<Usuario> users = dao.getList();
            for(int x=0; x< users.size();x++){
                a.add(new Paragraph(users.get(x).toString()));
            }
            a.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(PrincipalAdmController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (DocumentException ex) {
            Logger.getLogger(PrincipalAdmController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
