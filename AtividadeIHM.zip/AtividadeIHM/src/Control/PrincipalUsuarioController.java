/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Model.Usuario;
import Util.AbreFechaTelas;
import Util.Alerta;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author Usuário
 */
public class PrincipalUsuarioController implements Initializable,Controls {
    @FXML private Button btRelatorio;
    @FXML private Button btUsuario;
    @FXML private Label lbUsuario;
    @FXML private Label lbEndereco;
    @FXML private Button btDados;
    @FXML private Label lbNome;
    @FXML private Label lbValor;
    @FXML private Label lbEmail;
    @FXML private Label lbNomeUsuario;
    public static Usuario user;
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initActions();
        initTexto();
    }    

    @Override
    public void initActions() {
        initActionsMouse();
        initActionsKey(); 
        
        btRelatorio.setTooltip(new Tooltip("(Não precisava no Original) Caminho do arquivo : C:/User/Public/Individual.pdf"));
    
    }

    @Override
    public void initActionsMouse() {
        btDados.setOnMouseClicked((MouseEvent e)->{
            if(e.getButton() == MouseButton.PRIMARY){
                initTexto();
            }
        });
        
        btRelatorio.setOnMouseClicked((MouseEvent e)->{
            if(e.getButton() == MouseButton.PRIMARY){
                gerenciarRelatorio();
            }
        });
        
        btUsuario.setOnMouseClicked((MouseEvent e)->{
            if(e.getButton() == MouseButton.PRIMARY){
                if(PrincipalUsuarioController.user != null){
                   AbreFechaTelas.abreTelaG_Usuario(PrincipalUsuarioController.user);
                }else{
                    Alerta.error("Usuário Nulo");
                }
            }
        });
    }

    @Override
    public void initActionsKey() {
    
    }
    
    public void initTexto(){
        lbNome.setText(user.getNome());
        lbEndereco.setText(user.getEndereco()+", "+user.getNumero());
        lbEmail.setText(user.getEmail());
        lbUsuario.setText(user.getUsuario());
        lbValor.setText("R$ "+user.getValorConta().toString());
        lbNomeUsuario.setText(user.getNome());
        
    }
    
    public void gerenciarRelatorio(){
        Document a = new Document();
        try {
            PdfWriter.getInstance(a, new FileOutputStream("C:/Users/Public/individual.pdf"));
            a.open();
            a.add(new Paragraph(user.toString()));
            a.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(PrincipalAdmController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (DocumentException ex) {
            Logger.getLogger(PrincipalAdmController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
