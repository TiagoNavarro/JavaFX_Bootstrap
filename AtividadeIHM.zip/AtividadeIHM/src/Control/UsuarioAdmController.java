/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Dao.UsuarioDao;
import Model.Usuario;
import Util.AbreFechaTelas;
import Util.Alerta;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author Usuário
 */
public class UsuarioAdmController implements Initializable,Controls{
    @FXML private TextField txNumero;
    @FXML private PasswordField psCSenha;
    @FXML private TextField txUsuario;
    @FXML private TextField txConta;
    @FXML private TextField txEndereço;
    @FXML private PasswordField psSenha;
    @FXML private Button btAtualizar;
    @FXML private TextField txNome;
    @FXML private TextField txEmail;
    @FXML private Button btCancelar;
    public static Usuario user;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        initActions();
        initTexto();
    }    

    @Override
    public void initActions() {
        initActionsMouse();
        initActionsKey();
    }

    @Override
    public void initActionsMouse() {
        btAtualizar.setOnMouseClicked((MouseEvent e)->{
            if(e.getButton() == MouseButton.PRIMARY){
                atualizar();
            }
        });
                
        btCancelar.setOnMouseClicked((MouseEvent e)->{
            if(e.getButton() == MouseButton.PRIMARY){
                AbreFechaTelas.fechaTelaUsuarioAdm();
            }
        });
    }

    @Override
    public void initActionsKey() {
    
    }
    
    public void initTexto(){
        txNome.setText(user.getNome());
        txEndereço.setText(user.getEndereco());
        txNumero.setText(user.getNumero().toString());
        txEmail.setText(user.getEmail());
        txUsuario.setText(user.getUsuario());
        psSenha.setText(user.getSenha());
        psCSenha.setText(user.getSenha());
        txConta.setText(user.getValorConta().toString());
        
    }
    
    public void atualizar(){
        String nome = txNome.getText(),endereco = txEndereço.getText(),numeroT = txNumero.getText(),email = txEmail.getText(),
                usuario = txUsuario.getText(),senha = psSenha.getText(),confirmacao = psCSenha.getText(),valorT = txConta.getText();
        
        if(nome.equals("")){
            Alerta.error("Preencha o Nome");
        }else if(endereco.equals("")){
            Alerta.error("Preencha o Endereço");    
        }else if(numeroT.equals("")){
            Alerta.error("Preencha o Número");
        }else if(email.equals("")){
            Alerta.error("Preencha o email");
        }else if(usuario.equals("")){
            Alerta.error("Preencha o usuário");
        }else if(senha.equals("")){
            Alerta.error("Preencha o senha");
        }else if(confirmacao.equals("")){
            Alerta.error("Preencha o confirmação da senha");
        }else if(!senha.equals(confirmacao)){
            Alerta.error("As senhas não coincidem");
        }else if(valorT.equals("")){
            Alerta.error("Preencha o valor da conta");
        }else{
            try{
                int numero = Integer.parseInt(numeroT);
                try{
                    double valor = Double.parseDouble(valorT);
                    Usuario a = new Usuario(user.getId(),nome,endereco,numero,email,usuario,senha,valor);
                    UsuarioDao dao = new UsuarioDao();
                    if(dao.update(a)){
                        Alerta.confirmation("Usuário Atualizado com sucesso!");
                        UsuarioAdmController.user = a;
                        initTexto();
                    }
                    
                    
                }catch(NumberFormatException e){
                    Alerta.error("Valor Inválido");
                }
            }catch(NumberFormatException e){
                Alerta.error("Número Inválido");
            }
       }
    }
}
