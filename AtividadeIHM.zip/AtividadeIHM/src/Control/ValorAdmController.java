/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Dao.UsuarioDao;
import Model.Usuario;
import Util.AbreFechaTelas;
import Util.Alerta;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author Usuário
 */
public class ValorAdmController implements Initializable,Controls {
    @FXML private TextField txValor;
    @FXML private TextField txID;
    @FXML private Button btAcrescentar;
    @FXML private Button btRetirar;
    @FXML private TextField txNome;
    @FXML private Button btCancelar;
    public static Usuario user;
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initActions();
        initTexto();
    }    

    @Override
    public void initActions() {
        initActionsMouse();
        initActionsKey();
    }

    @Override
    public void initActionsMouse() {
        btCancelar.setOnMouseClicked((MouseEvent e)->{
            if(e.getButton() == MouseButton.PRIMARY){
                AbreFechaTelas.fechaTelaValorAdm();
            }
        });
        
        btAcrescentar.setOnMouseClicked((MouseEvent e)->{
            if(e.getButton() == MouseButton.PRIMARY){
                acrescentar();
            }
        });
        
        btRetirar.setOnMouseClicked((MouseEvent e)->{
            if(e.getButton() == MouseButton.PRIMARY){
                retirar();
            }
        });
    }

    @Override
    public void initActionsKey() {
    
    }
    
    public void initTexto(){
        txID.setText(user.getId().toString());
        txNome.setText(user.getNome());
    }
    
    public void acrescentar(){
        try{
            Double valor = Double.parseDouble(txValor.getText());
            user.setValorConta(user.getValorConta()+valor);
            UsuarioDao dao = new UsuarioDao();
            if(dao.update(user)){
                Alerta.confirmation("Valor acrescentado com sucesso!");
                AbreFechaTelas.fechaTelaValorAdm();
            }
        }catch(NumberFormatException e){
            Alerta.error("Valor inválido");
        }
    }
    
    public void retirar(){
        try{
            Double valor = Double.parseDouble(txValor.getText());
            user.setValorConta(user.getValorConta()-valor);
            UsuarioDao dao = new UsuarioDao();
            if(dao.update(user)){
                Alerta.confirmation("Valor retirado com sucesso!");
                AbreFechaTelas.fechaTelaValorAdm();
            }
        }catch(NumberFormatException e){
            Alerta.error("Valor inválido");
        }
    }
}
