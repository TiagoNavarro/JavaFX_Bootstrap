/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Connection.Hibernate;
import Model.Usuario;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Patrick
 */
public class UsuarioDao {
    Hibernate connection = new Hibernate();
    Session sessao;
    
    public UsuarioDao(){
        sessao = connection.getConnection().openSession();
    }
    
    public boolean add(Usuario a){
        Transaction tx = sessao.beginTransaction();
        sessao.save(a);
        tx.commit();
        sessao.close();
        return true;
    }
    
    public boolean update(Usuario a){
        Transaction tx = sessao.beginTransaction();
        sessao.update(a);
        tx.commit();
        sessao.close();
        return true;
    }
    
    public boolean remove(Usuario a){
        Transaction tx = sessao.beginTransaction();
        sessao.delete(a);
        tx.commit();
        sessao.close();
        return true;
    }
    
    public List<Usuario> getList(){
        Transaction tx = sessao.beginTransaction();
        Query consult = sessao.createQuery("from Usuario");
        List<Usuario> lista = consult.list();
        tx.commit();
        sessao.close();
        return lista;
    }
    
    
    public void fechaConnections(){
        sessao.close();
    }
    
}
