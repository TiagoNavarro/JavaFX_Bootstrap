/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Util;

import Main.G_Usuario;
import Main.Login;
import Main.NovoUsuario;
import Main.PrincipalAdm;
import Main.PrincipalUsuario;
import Main.UsuarioAdm;
import Main.ValorAdm;
import Model.Usuario;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.stage.Stage;

/**
 *
 * @author Usuário
 */
public class AbreFechaTelas {
    public static void abreTelaLogin(){
        Login a = new Login();
        try {
            a.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(AbreFechaTelas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void fechaTelaLogin(){
        Login.getStage().close();
    }
    
    public static void abreTelaNovoUsuario(){
        NovoUsuario a = new NovoUsuario();
        try {
            a.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(AbreFechaTelas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void fechaTelaNovoUsuario(){
        NovoUsuario.getStage().close();
    }
    
    public static void abreTelaPrincipalAdm(){
        PrincipalAdm a = new PrincipalAdm();
        try {
            a.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(AbreFechaTelas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void fechaTelaPrincipalAdm(){
        PrincipalAdm.getStage().close();
    }
    
    public static void abreTelaPrincipalUsuario(Usuario u){
        PrincipalUsuario a = new PrincipalUsuario(u);
        try {
            a.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(AbreFechaTelas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void fechaTelaPrincipalUsuario(){
        PrincipalUsuario.getStage().close();
    }
    
    public static void abreTelaUsuarioAdm(Usuario o){
        UsuarioAdm a = new UsuarioAdm(o);
        try {
            a.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(AbreFechaTelas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void fechaTelaUsuarioAdm(){
        UsuarioAdm.getStage().close();
    }
    
    public static void abreTelaValorAdm(Usuario o){
        ValorAdm a = new ValorAdm(o);
        try {
            a.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(AbreFechaTelas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void fechaTelaValorAdm(){
        ValorAdm.getStage().close();
    }
    
    public static void abreTelaG_Usuario(Usuario p){
        G_Usuario a = new G_Usuario(p);
        try {
            a.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(AbreFechaTelas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void fechaTelaG_Usuario(){
        G_Usuario.getStage().close();
    }
    
    
    
}
