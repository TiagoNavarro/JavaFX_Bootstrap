/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atividadesjavafx;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Tiago
 */
public class AbreLogin extends Application {
    
    //STAGE LETRA MAIUSCULA RESPONSÁVEL PELA TELA, SEM STAGE O SISTEMA NÃO ABRE A TELA
    //O STAGE COM LETRA MINUSCULA SERVE PARA COLOCAR OS ELEMENTOS DA TELA
    //O START DA INICIO A TELA
    
    @Override
    public void start(Stage stage) throws Exception {
        //RESPONSÁVEL POR CHAMAR/CARREGAR O ARQUIVO DA TELA
        Parent root = FXMLLoader.load(getClass().getResource("TelaLogin.fxml"));
        //SCENE SIGNIFICA O CENÁRIO
        Scene scene = new Scene(root);
        //COLOCA O CENÁRIO DENTRO DA STAGE ATRAVÉS DO MÉTODO SETSCENE
        stage.setTitle("Acesso ao software");
        stage.setScene(scene);
        //O SHOW SERVE PARA EXIBIR A TELA
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
