/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atividadesjavafx;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 *
 * @author Tiago
 */
public class LoginController implements Initializable {
    
    
    @FXML private Label login;
    @FXML private Label senha;
    @FXML private TextField digitalogin;
    @FXML private TextField digitasenha;
    
    @FXML private Button btentrar;
    @FXML private Button btsair;
    @FXML private Button btcadastrar;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
    }   
    
    public void EntraCad() {
        btcadastrar.setOnMouseClicked((MouseEvent a) -> {
            TelaCadController abre = new TelaCadController();
            try {
                abre.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

    }
    
}
