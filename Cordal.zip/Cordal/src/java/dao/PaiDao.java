/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jdbc.ConnectionFactory;
import model.Pais;

/**
 *
 * @author Aluno
 
 */
public class PaiDao {
    public void setPais(Pais pai){
        Connection c = ConnectionFactory.getConnection();
        String sql = "INSERT INTO pais(nomepai, nomealuno, serie, cpf) "
                + "VALUES(?,?,?,?);";
        try{
           PreparedStatement stmt = c.prepareStatement(sql);
            stmt.setString(1, pai.getNome());
            stmt.setString(2, pai.getAluno());
            stmt.setString(3, pai.getSerie());
            stmt.setString(4, pai.getCpf());
            stmt.execute();
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
     public List<Pais> getPais(){
        Connection con;
        List<Pais> clientes = new ArrayList<Pais>();
        String sql = "SELECT * FROM pais";
        PreparedStatement stmt = null;
        try{
            con = ConnectionFactory.getConnection();
            stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Pais c = new Pais();
                c.setNome(rs.getString("nomepai"));
                c.setAluno(rs.getString("nomealuno"));
                c.setSerie(rs.getString("serie"));
                c.setCpf(rs.getString("cpf"));
                clientes.add(c);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return clientes;
    }

   

   
}
