/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jdbc.ConnectionFactory;
import model.Reclamacao;

/**
 *
 * @author Aluno
 */
public class ReclaDao {

    public void setReclamacao(Reclamacao r) {
        String sql = "INSERT INTO reclamacao(aluno, professor, disciplina, "
                + "reclamacao, faltas, notas) "
                + "VALUES(?,?,?,?,?,?);";
        Connection c = ConnectionFactory.getConnection();
        try {
            System.out.println("Chegando até o DAO");
            PreparedStatement stmt = c.prepareStatement(sql);
            stmt.setString(1, r.getNomealuno());
            stmt.setString(2, r.getProfessor());
            stmt.setString(3, r.getDisciplina());
            stmt.setString(4, r.getRecla());
            stmt.setString(5, r.getFaltas());
            stmt.setString(6, r.getNotas());
            System.out.println("Chegando cadastro de reclamação");
            stmt.execute();
            System.out.println("CADASTREI A RECLAMAÇÃO");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Reclamacao> getReclamacao() {
        List<Reclamacao> recla = new ArrayList<Reclamacao>();
        String sql = "SELECT * FROM reclamacao";
        PreparedStatement stmt = null;
        Connection con = ConnectionFactory.getConnection();
        try {
            stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Reclamacao c = new Reclamacao();
                c.setNomealuno(rs.getString("aluno"));
                c.setProfessor(rs.getString("professor"));
                c.setDisciplina(rs.getString("disciplina"));
                c.setRecla(rs.getString("reclamacao"));
                c.setFaltas(rs.getString("faltas"));
                c.setNotas(rs.getString("notas"));
                recla.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return recla;
    }
}
