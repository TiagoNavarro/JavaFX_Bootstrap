/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Aluno
 */
public class Reclamacao {
    private String nomealuno;
    private String professor;
    private String disciplina;
    private String recla;
    private String faltas;
    private String notas;
    
    
    public String getNomealuno() {
        return nomealuno;
    }

    public void setNomealuno(String nomealuno) {
        this.nomealuno = nomealuno;
    }

    public String getProfessor() {
        return professor;
    }

    public void setProfessor(String professor) {
        this.professor = professor;
    }

    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }

    public String getRecla() {
        return recla;
    }

    public void setRecla(String reclamacao) {
        this.recla = reclamacao;
    }

    public String getFaltas() {
        return faltas;
    }

    public void setFaltas(String faltas) {
        this.faltas = faltas;
    }
    

    public String getNotas() {
        return notas;
    }

    public void setNotas(String notas) {
        this.notas = notas;
    }
    public String toString() {
        return "pais{" + ", aluno=" + nomealuno + ", professor=" + professor + ", disciplina=" + disciplina + ", recla=" + recla +" ,faltas" +faltas+" ,notas" +notas+'}';
    }

    
}
