/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import dao.PaiDao;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Pais;

/**
 *
 * @author Aluno
 */
public class FormCadPais extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
   protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        
        String nome = (String) request.getParameter("nome");
        String aluno = (String) request.getParameter("aluno");
        String serie = (String) request.getParameter("serie");
        String cpf = (String) request.getParameter("cpf");
             Pais cliente = new Pais();
        cliente.setNome(request.getParameter("nome"));
        cliente.setAluno(request.getParameter("aluno"));
        cliente.setSerie(request.getParameter("serie"));
        cliente.setCpf(request.getParameter("cpf"));
        
        //PaiDao dao = new PaiDao();
        //dao.setpais(cliente);
        PaiDao p = new PaiDao();
        p.setPais(cliente);
        
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ProcessaFormulario</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ProcessaFormulario at " + request.getContextPath() + "</h1>");
            out.println(""
                    + "<p>A pessoa que se cadastrou se chama "+nome+" tem o filho com o nome de "+aluno+" que esta na serie: </p>"
                    + "<p>"+serie+" tem o CPF com o nome de"+cpf+"</p>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
