/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import static com.sun.corba.se.spi.presentation.rmi.StubAdapter.request;
import dao.ReclaDao;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import model.Reclamacao;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Aluno
 */
public class TestePrograma {
    
    public TestePrograma() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
     @Test
    public void testReclamacao() {
        List<Reclamacao> recla = new ArrayList<Reclamacao>();
        ReclaDao dao = new ReclaDao();
        recla = dao.getReclamacao();
        
        }
    }


