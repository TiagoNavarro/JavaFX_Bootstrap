﻿create table usuario(
id_usuario serial primary key,
nome varchar(15) not null,
sobrenome varchar(30) not null,
endereco varchar(100) not null,
numero_endereco int not null,
nascimento varchar(10) not null,
usuario varchar(10) not null,
senha varchar(12) not null,
confirmacao_senha varchar(12) not null
);