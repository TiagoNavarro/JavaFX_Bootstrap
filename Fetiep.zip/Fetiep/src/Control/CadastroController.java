/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Dao.UsuarioDao;
import Model.Usuario;
import Principais.Cadastro;
import Principais.Fetiep;
import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Patrick
 */
public class CadastroController implements Initializable {
    @FXML
    private AnchorPane anpCadastro;
    @FXML
    private Label lbNome;
    @FXML
    private TextField txNome;
    @FXML
    private TextField txSobrenome;
    @FXML
    private TextField txEndereco;
    @FXML
    private TextField txNumeroEndereco;
    @FXML
    private Label lbEndereco;
    @FXML
    private Label lbNascimento;
    @FXML
    private DatePicker dpNascimento;
    @FXML
    private TextField txUsuario;
    @FXML
    private Label lbUsuario;
    @FXML
    private PasswordField txSenha;
    @FXML
    private PasswordField txConfirmacaoSenha;        
    @FXML
    private ImageView imgFoto;
    @FXML
    private Button btAlterar;
    @FXML
    private Button btDeletar;
    @FXML
    private Button btCadastrar;
    @FXML
    private Button btCancelar;
    @FXML
    private Stage stage;
    @FXML
    private TextField txImgFoto;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initButtons();
    }    
    
    
    public void voltarAoLogin(){
        Fetiep principal = new Fetiep();
        try {
            Cadastro.getStage().close();
            principal.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(CadastroController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void fecharTelaCadastro(){
        Cadastro.getStage().close();
    }
    
    private static void configureFileChooser(
        final FileChooser fileChooser) {      
            fileChooser.setInitialDirectory(
                new File(System.getProperty("user.home"))
            );                 
            fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("JPG", "*.jpg"),
                new FileChooser.ExtensionFilter("JPEG", "*.jpeg"),    
                new FileChooser.ExtensionFilter("PNG", "*.png")
            );
    }
    
    public void initButtons(){
        
        btCancelar.setOnMouseClicked((MouseEvent m)->{
            fecharTelaCadastro();
        });
        
        btCancelar.setOnKeyPressed((KeyEvent ke) ->{
            if(ke.getCode() == KeyCode.ENTER){
                fecharTelaCadastro();
            }
        });
        
        btAlterar.setOnMouseClicked((MouseEvent k)->{
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Escolha a Imagem de Perfil");
            configureFileChooser(fileChooser);
            File file = fileChooser.showOpenDialog(stage);
            if(file.getAbsolutePath() != null){
                String diretorio = file.getAbsolutePath();
                try{
                    imgFoto.setImage(new Image("file:///"+diretorio));
                    txImgFoto.setText("file:///"+diretorio);
                }catch(IllegalArgumentException e){
                    JOptionPane.showMessageDialog(null,"Erro : Sua Foto não pode ser Adicionada, tente novamente mais tarde.",
                "Erro", JOptionPane.ERROR_MESSAGE);
                }
                
            }
        });
        
        btDeletar.setOnMouseClicked((MouseEvent m)->{
            imgFoto.setImage(new Image("/Image/FotoPerfilNull.png"));
            txImgFoto.setText("/Image/FotoPerfilNull.png");
        });
        
        btCadastrar.setOnMouseClicked((MouseEvent m)->{
            Usuario user = new Usuario();
            user.setNome(txNome.getText());
            user.setSobrenome(txSobrenome.getText());
            user.setEndereco(txEndereco.getText());
            user.setNumeroEndereco(Integer.parseInt(txNumeroEndereco.getText()));
            
            int ano = dpNascimento.getValue().getYear();
            int mes = dpNascimento.getValue().getMonthValue();
            int dia = dpNascimento.getValue().getDayOfMonth();
            user.setNascimento(dia+"/"+mes+"/"+ano);
            user.setUsuario(txUsuario.getText());
            user.setSenha(txSenha.getText());
            user.setFoto(txImgFoto.getText());
            UsuarioDao dao = new UsuarioDao();
            dao.adicionaUsuario(user);
            JOptionPane.showMessageDialog(null, "Usuario Cadastrado com Sucesso",null,JOptionPane.NO_OPTION);
            fecharTelaCadastro();
            atualizaTabela();
        });
    }
    
    public void atualizaTabela(){
        ListaUsuariosController atualizaTabela = new ListaUsuariosController();
        atualizaTabela.atualizaTabela();
    }
    
}
