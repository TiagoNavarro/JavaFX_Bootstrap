/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Dao.UsuarioDao;
import Model.Usuario;
import Principais.Cadastro;
import Principais.Fetiep;
import Principais.Principal;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 *
 * @author Patrick
 */
public class FetiepController implements Initializable {
    @FXML
    private AnchorPane anpLogin;
    @FXML
    private Label lbUsuario;
    @FXML
    private Label lbSenha;
    @FXML
    private Label lbIdioma;
    @FXML
    private Button btEntrar;
    @FXML
    private Button btNovoUsuario;
    @FXML
    private TextField txUsuario;
    @FXML
    private PasswordField txSenha;
    @FXML
    private ImageView logotipo;
    @FXML
    private ImageView imgChamativa;
    @FXML
    private ComboBox<String> cbxIdioma;
    ObservableList<String> list = FXCollections.observableArrayList("Português PT-BR", "Inglês");
    
    
    
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cbxIdioma.setItems(list);
        cbxIdioma.getSelectionModel().select(0);
        
        cbxIdioma.valueProperty().addListener(new ChangeListener<String>() {
            @Override 
            public void changed(ObservableValue ov, String t, String t1) {                
                editComponents();
            }    
        });
        
        /*anpLogin.setOnKeyPressed((KeyEvent ke) -> {
            if (ke.getCode() == KeyCode.ENTER) {
                logar();
            }    
        });*/
        
        btEntrar.setOnKeyPressed((KeyEvent ke) ->{
            if(ke.getCode() == KeyCode.ENTER){
                logar();
            }
        });
        
        btNovoUsuario.setOnKeyPressed((KeyEvent ke)->{
            if(ke.getCode() == KeyCode.ENTER){
                criarUsuario();
            }
        });
        
    } 
    
    public void editComponents(){
        if("Inglês".equals(cbxIdioma.getValue())){
            lbUsuario.setText("User ");
            txUsuario.setPromptText("Insert your username...");

            lbSenha.setText("Password ");
            txSenha.setPromptText("Insert your password...");
            
            btEntrar.setText("Enter");
            btNovoUsuario.setText("New User");
            
            lbIdioma.setText("Language");
        } else if ("Português PT-BR".equals(cbxIdioma.getValue())){
            lbUsuario.setText("Usuario");
            txUsuario.setPromptText("Digite seu Usuário...");

            lbSenha.setText("Senha");
            txSenha.setPromptText("Digite sua senha...");
           
            btEntrar.setText("Entre");
            btNovoUsuario.setText("Novo usuário");
        
            lbIdioma.setText("Idioma");
        }
    }
    
    @FXML
    public void logar() {
        List<Usuario> usuarios = new ArrayList<Usuario>();
        UsuarioDao dao = new UsuarioDao();
        usuarios = dao.getListaUsuario();
        
        if(usuarios.size() == 0){
            JOptionPane.showMessageDialog(null, "Login e/ou senha",
            "Erro", JOptionPane.ERROR_MESSAGE);
        }else{
            for(int x = 0; x < usuarios.size();x++){
                if(txUsuario.getText().equals(usuarios.get(x).getUsuario()) && txSenha.getText().equals(usuarios.get(x).getSenha())){
                    Principal p = new Principal();
                    try {
                        p.start(new Stage());
                        JOptionPane.showMessageDialog(null, "Bem Vindo!!!");
                        Fetiep.getStage().close();
                    } catch (Exception ex) {
                        Logger.getLogger(FetiepController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    x= usuarios.size()+2;
                }
                
                if(x == usuarios.size()-1){
                    JOptionPane.showMessageDialog(null, "Login e/ou senha",
                "Erro", JOptionPane.ERROR_MESSAGE);
                    txUsuario.setText("");
                    txSenha.setText("");
                    
                }
            }
        }
    }
    
    @FXML
    public void criarUsuario(){
        Cadastro cd = new Cadastro();
        try {
            cd.start(new Stage());
            Fetiep.getStage().close();
        } catch (Exception ex) {
            Logger.getLogger(FetiepController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
