/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Dao.UsuarioDao;
import Principais.Cadastro;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import Model.Usuario;
import Principais.ListaUsuario;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Patrick
 */
public class ListaUsuariosController implements Initializable {
    @FXML
    private TableView<Usuario> tvTabela;
    @FXML
    private TableColumn<Usuario,Integer> tcId;
    @FXML
    private TableColumn<Usuario,String>tcNome;
    @FXML
    private TableColumn<Usuario,String> tcSobrenome;
    @FXML
    private Button btVoltar;
    @FXML
    private Button btDeletar;
    @FXML
    private Button btNovo;
    @FXML
    private Button btEditar;
    
    List <Usuario> usuarios = new ArrayList<Usuario>();
    
    @FXML
    private Label lbSobrenome;
    @FXML
    private Label lbUsuario;
    @FXML
    private Label lbEndereco;
    @FXML
    private Label lbNascimento;
    @FXML 
    private Label lbNome;
    @FXML
    private Label lbNEndereco;
    //Aqui começa as labels que irão ter as informações dos usuários
    
    @FXML
    private Label lbNomeUsuario;
    @FXML
    private Label lbSobrenomeUsuario;
    @FXML
    private Label lbEnderecoUsuario;
    @FXML
    private ImageView imgFotoUsuario;
    @FXML
    private Label lbNomeDoUsuario;
    @FXML
    private Label lbNEnderecoUsuario;
    @FXML
    private Label lbNascimentoUsuario;
    @FXML 
    private TextField txID;
    
    private ListaUsuario listaUsuario;
    
        
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        tvTabela.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue) -> detalhesUsuario(newValue));
        
        setListaUsuario(new ListaUsuario());
        initButton();
        initColumns();
    }  
    
    public void setListaUsuario(ListaUsuario listaUser){
        this.listaUsuario = listaUser;
        tvTabela.setItems(listaUsuario.getBDUsuarios());
    }
    
    public void initButton(){
        btVoltar.setOnMouseClicked((MouseEvent m )->{
            ListaUsuario.getStage().close();
        });
        
        btNovo.setOnMouseClicked((MouseEvent m) ->{
            criarUsuario();
        });
        
        btDeletar.setOnMouseClicked((MouseEvent e)->{
            int id = Integer.parseInt(txID.getText());
            Usuario user = new Usuario();
            UsuarioDao dao = new UsuarioDao();
            user.setId(id);
            try{
                dao.deletaUsuario(user);
            }catch(Exception w){
                JOptionPane.showMessageDialog(null, "Usuario não pode ser deletado!","erro",JOptionPane.ERROR_MESSAGE);
            }
            JOptionPane.showMessageDialog(null, "Usuario deletado com sucesso");
            atualizaTabela();
        });
        
 
    }
    
    public void initColumns(){
        tcId.setCellValueFactory(new PropertyValueFactory<>("id"));
        tcNome.setCellValueFactory(cellData -> cellData.getValue().getNomeProperty());
        //tcNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        tcSobrenome.setCellValueFactory(cellData -> cellData.getValue().getSobrenomeProperty());
        
    }
    
    @FXML
    public void criarUsuario(){
        Cadastro cd = new Cadastro();
        try {
            cd.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(FetiepController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void detalhesUsuario(Usuario user){
        if (user != null) {
            // Preenche as labels com informações do objeto person.
            lbNomeUsuario.setText(user.getNome());
            lbSobrenomeUsuario.setText(user.getSobrenome());
            lbEnderecoUsuario.setText(user.getEndereco());
            lbNEnderecoUsuario.setText(""+user.getNumeroEndereco());
            lbNascimentoUsuario.setText(user.getNascimento());
            lbNomeDoUsuario.setText(user.getUsuario());
            txID.setText(""+user.getId());
            try{
                imgFotoUsuario.setImage(new Image(user.getFoto()));
            }catch(Exception e){
                imgFotoUsuario.setImage(new Image("/Image/ImagemNaoCarregada.jpg"));
            }        
        } else {
            lbNomeUsuario.setText("");
            lbSobrenomeUsuario.setText("");
            lbEnderecoUsuario.setText("");
            lbNEnderecoUsuario.setText("");
            lbNascimentoUsuario.setText("");
            lbNomeDoUsuario.setText("");
            imgFotoUsuario.setImage(new Image("/Image/FotoPerfilNull.png"));
        }
    }
    
    public void atualizaTabela(){
        ListaUsuario l = new ListaUsuario();
        setListaUsuario(l);
    }
}
