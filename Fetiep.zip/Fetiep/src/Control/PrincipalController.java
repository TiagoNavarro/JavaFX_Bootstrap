/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Principais.ListaUsuario;
import Principais.Principal;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Patrick
 */
public class PrincipalController implements Initializable {
    @FXML 
    private Button btListaUsuarios;
    @FXML
    private Stage stage;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btListaUsuarios.setOnMouseClicked((MouseEvent m) ->{
            /*
            List <Usuario> usuarios = new ArrayList<Usuario>();
            UsuarioDao dao = new UsuarioDao();
            usuarios = dao.getListaUsuario();
            JOptionPane.showMessageDialog(null, "Número total de Usuários cadastrados no Sistema : "
                    +usuarios.size());
        */
            listarUsuarios();
        });
        
    }
    
    public void listarUsuarios(){
        ListaUsuario lu = new ListaUsuario();
        try{
            Principal.getStage().close();
            lu.start(new Stage());
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Não foi Possivel Abrir a lista de Usuários","erro",JOptionPane.ERROR_MESSAGE);
        }
    }
    
}
