/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import JDBC.ConnectionFactory;
import Model.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Patrick
 */
public class UsuarioDao {
    private Connection connection;

    public UsuarioDao(){
        try {
            Class.forName("org.postgresql.Driver");
            this.connection = new ConnectionFactory().getConnection();
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public void adicionaUsuario(Usuario usuario){
        String sql = "INSERT INTO usuario(nome,sobrenome,endereco,numeroEndereco,nascimento,usuario,senha,foto)"
                + "VALUES (?,?,?,?,?,?,?,?)";
        
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, usuario.getNome());
            stmt.setString(2, usuario.getSobrenome());
            stmt.setString(3, usuario.getEndereco());
            stmt.setInt(4, usuario.getNumeroEndereco());
            stmt.setString(5, usuario.getNascimento());
            stmt.setString(6, usuario.getUsuario());
            stmt.setString(7, usuario.getSenha());
            stmt.setString(8, usuario.getFoto());
            stmt.execute();
            stmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public List<Usuario> getListaUsuario(){
        List<Usuario> usuarios = new ArrayList<Usuario>();
        String sql = "SELECT * FROM usuario";
        try {
            PreparedStatement stmt = this.connection.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                Usuario a = new Usuario();
                a.setId(rs.getInt("id_usuario"));
                a.setNome(rs.getString("nome"));
                a.setSobrenome(rs.getString("sobrenome"));
                a.setEndereco(rs.getString("endereco"));
                a.setNumeroEndereco(rs.getInt("numeroendereco"));
                a.setNascimento(rs.getString("nascimento"));
                a.setUsuario(rs.getString("usuario"));
                a.setSenha(rs.getString("senha"));
                a.setFoto(rs.getString("foto"));
                usuarios.add(a);
            }
            
            rs.close();
            stmt.close();
            return usuarios;
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    public void deletaUsuario(Usuario user){
        String sql = "DELETE FROM usuario WHERE id_usuario=?";
        try{
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, user.getId());
            stmt.execute();
            stmt.close();
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
    }
    
}
