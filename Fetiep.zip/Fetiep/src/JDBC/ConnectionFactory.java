package JDBC;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 * @author Patrick
 */
public class ConnectionFactory {
    public Connection getConnection(){
        try {
            //Retornando a conexao com o banco de dados
            return DriverManager.getConnection(
                    //DSN da conex�o de banco de dados		 login		 senha
                    "jdbc:postgresql://localhost/fetiep", "postgres", "12345");
            //Cria SQLException
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }   
    }    
}