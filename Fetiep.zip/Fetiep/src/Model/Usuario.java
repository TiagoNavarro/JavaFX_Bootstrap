/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author Patrick
 */
public class Usuario {
    protected IntegerProperty id;
    protected StringProperty nome;
    protected StringProperty sobrenome;
    protected StringProperty endereco;
    protected IntegerProperty numeroEndereco;
    protected StringProperty nascimento;
    protected StringProperty usuario;
    protected StringProperty senha;
    protected StringProperty foto;

    public Usuario() {
        this.id = new SimpleIntegerProperty(0);
        this.nome = new SimpleStringProperty("");
        this.sobrenome = new SimpleStringProperty("");
        this.endereco = new SimpleStringProperty("");
        this.numeroEndereco = new SimpleIntegerProperty(0);
        this.nascimento = new SimpleStringProperty("");
        this.usuario = new SimpleStringProperty("");
        this.senha = new SimpleStringProperty("");
        this.foto = new SimpleStringProperty("");
    }

    
    
    public Usuario(int id, String nome, String sobrenome, String endereco, int numeroEndereco, 
            String nascimento, String usuario, String senha,String foto) {
        this.id = new SimpleIntegerProperty(id);
        this.nome = new SimpleStringProperty(nome);
        this.sobrenome = new SimpleStringProperty(sobrenome);
        this.endereco = new SimpleStringProperty(endereco);
        this.numeroEndereco = new SimpleIntegerProperty(numeroEndereco);
        this.nascimento = new SimpleStringProperty(nascimento);
        this.usuario = new SimpleStringProperty(usuario);
        this.senha = new SimpleStringProperty(senha);
        this.foto = new SimpleStringProperty(foto);
    }

    public IntegerProperty getIdProperty() {
        return id;
    }

    public void setIdProperty(IntegerProperty id) {
        this.id = id;
    }

    public StringProperty getNomeProperty() {
        return nome;
    }

    public void setNomeProperty(StringProperty nome) {
        this.nome = nome;
    }

    public StringProperty getSobrenomeProperty() {
        return sobrenome;
    }

    public void setSobrenomeProperty(StringProperty sobrenome) {
        this.sobrenome = sobrenome;
    }

    public StringProperty getEnderecoProperty() {
        return endereco;
    }

    public void setEnderecoProperty(StringProperty endereco) {
        this.endereco = endereco;
    }

    public IntegerProperty getNumeroEnderecoProperty() {
        return numeroEndereco;
    }

    public void setNumeroEnderecoProperty(IntegerProperty numeroEndereco) {
        this.numeroEndereco = numeroEndereco;
    }

    public StringProperty getNascimentoProperty() {
        return nascimento;
    }

    public void setNascimentoProperty(StringProperty nascimento) {
        this.nascimento = nascimento;
    }

    public StringProperty getUsuarioProperty() {
        return usuario;
    }

    public void setUsuarioProperty(StringProperty usuario) {
        this.usuario = usuario;
    }

    public StringProperty getSenhaProperty() {
        return senha;
    }

    public void setSenhaProperty(StringProperty senha) {
        this.senha = senha;
    }

    public StringProperty getFotoProperty() {
        return foto;
    }

    public void setFotoProperty(StringProperty foto) {
        this.foto = foto;
    }

        
    
    public int getId() {
        return id.get();
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public String getNome() {
        return nome.get();
    }

    public void setNome(String nome) {
        this.nome.set(nome);
    }

    public String getSobrenome() {
        return sobrenome.get();
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome.set(sobrenome);
    }

    public String getEndereco() {
        return endereco.get();
    }

    public void setEndereco(String endereco) {
        this.endereco.set(endereco);
    }

    public int getNumeroEndereco() {
        return numeroEndereco.get();
    }

    public void setNumeroEndereco(int numeroEndereco) {
        this.numeroEndereco.set(numeroEndereco);
    }

    public String getNascimento() {
        return nascimento.get();
    }

    public void setNascimento(String nascimento) {
        this.nascimento.set(nascimento);
    }

    public String getUsuario() {
        return usuario.get();
    }

    public void setUsuario(String usuario) {
        this.usuario.set(usuario);
    }

    public String getSenha() {
        return senha.get();
    }

    public void setSenha(String senha) {
        this.senha.set(senha);
    }

    public String getFoto() {
        return foto.get();
    }

    public void setFoto(String foto) {
        this.foto.set(foto);
    }
    
    
}
