/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principais;

import Dao.UsuarioDao;
import Model.Usuario;
import java.util.ArrayList;
import java.util.List;
import static javafx.application.Application.launch;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 *
 * @author Patrick
 */
public class ListaUsuario {
    private static Stage stage;
    
    private ObservableList<Usuario> usuarioss = FXCollections.observableArrayList();
        
    
    public ListaUsuario(){
        UsuarioDao dao = new UsuarioDao();
        List<Usuario> usuarios = new ArrayList<Usuario>();
        usuarios = dao.getListaUsuario();
        usuarioss.setAll(usuarios);
    }
    
    public ObservableList<Usuario> getBDUsuarios() {
        return usuarioss;
    }
    
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/View/ListaUsuarios.fxml"));
        
        Scene scene = new Scene(root);
        stage.setTitle("Fetiep - Lista de Usuário");
        stage.getIcons().add(new Image(getClass().getResourceAsStream("/Image/Icone Fetiep.png")));
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
        ListaUsuario.stage = stage;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
    public static Stage getStage(){
        return stage;
    }
}
