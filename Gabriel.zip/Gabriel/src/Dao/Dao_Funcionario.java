package Dao;

import JDBC.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.ResultSet;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx_aprendendo.Models.Funcionario;
import static javafx_aprendendo.Controls.FXML_Editar_FuncionarioController.*;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class Dao_Funcionario
{
    public static Connection conexao_BD;
    
    public static ResultSet r;
    
    public static PreparedStatement st;
    
    public Dao_Funcionario()
    {
        Dao_Funcionario.conexao_BD = ConnectionFactory.getConnection();
    }
    
    public static void Coloca_Funcionario(Funcionario func)
    {     
        String sql = "INSERT INTO Funcionario" + "(Nome, Telefone, Salario, Cargo, Sexo, Datadia)"
                + "VALUES(?,?,?,?,?,?);";
        
         Date data = Date.valueOf(func.getDatadia());
            
        try{
            
            PreparedStatement stat = conexao_BD.prepareStatement(sql);
            
            stat.setString(1, func.getNome());
            stat.setInt(2, func.getTelefone());
            stat.setFloat(3, func.getSalario());
            stat.setString(4, func.getCargo());
            stat.setString(5, func.getSexo());
            stat.setDate(6,Date.valueOf(func.getDatadia()));      
            stat.execute();
            stat.close();
            
        }catch(SQLException ex){
            System.out.println("verde " + ex.getMessage());
        }
    }  
    
    public void Edita_Funcionario(Funcionario Func)
    {
        String sql = "UPDATE Funcionario SET Nome = ?, Telefone = ?, Salario = ?, Cargo = ?, Sexo = ?, datadia = ? WHERE Nome = ? AND Telefone = ? AND Salario = ? AND Cargo = ? AND Sexo = ? AND datadia = ?";
        try{
            PreparedStatement stmt = conexao_BD.prepareStatement(sql);
            stmt.setString(1, Func.getNome());
            stmt.setString(7, Nome);
            stmt.setInt(2, Func.getTelefone());
            stmt.setInt(8, Telefone);
            stmt.setFloat(3, Func.getSalario());
            stmt.setFloat(9, Salario);
            stmt.setString(4, Func.getCargo());
            stmt.setString(10, Cargo);
            stmt.setString(5, Func.getSexo());
            stmt.setString(11, Sexo);
            Date datadia = Date.valueOf(Func.getDatadia());
            stmt.setDate(6, datadia);
            stmt.setDate(12, Date.valueOf(datad));
            stmt.execute();
            stmt.close();
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
    }
    
    public void Deleta_Funcionario(Funcionario Func)
    {
        String sql = "DELETE FROM Funcionario WHERE Nome=?";
        try{
            PreparedStatement stmt = conexao_BD.prepareStatement(sql);
            stmt.setString(1, Func.getNome());
            stmt.execute();
            stmt.close();
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
    }        
    
    public ObservableList<Funcionario> get_Funcionario()
    {  
        try{
            ObservableList<Funcionario> Func = FXCollections.observableArrayList();
            PreparedStatement stmt = this.conexao_BD.prepareStatement("SELECT * FROM Funcionario");
            ResultSet rs = stmt.executeQuery();
            
            r = rs;
            st = stmt;
            
            while(rs.next()){
                //criando o obejto f
                Funcionario f = new Funcionario();
                f.setNome(rs.getString("Nome"));
                f.setTelefone(rs.getInt("Telefone"));
                f.setSalario(rs.getFloat("Salario"));
                f.setCargo(rs.getString("Cargo"));
                f.setSexo(rs.getString("Sexo"));
                Date datadia = rs.getDate("datadia");
                f.setData(datadia.toLocalDate());
                
                //Posso fazer um novo set Data convertendo
                //adicionando o objeto a lista    
                Func.add(f);
            }
            //fecha conexao
            stmt.executeQuery();
            //rs.close();
            //stmt.close();
            return Func;
            
        }catch(SQLException e){
                throw new RuntimeException(e);  
        }
    }        
}

//Banco de Dados

/*
CREATE TABLE Funcionario(
	Id_Funcionario SERIAL,
	Nome VARCHAR NOT NULL,
	Telefone INTEGER NOT NULL,
	Salario FLOAT NOT NULL,
	Cargo VARCHAR NOT NULL,
	Sexo VARCHAR NOT NULL,
	Datadia DATE NOT NULL,
	PRIMARY KEY(Id_Funcionario)
)

INSERT INTO Funcionario (Nome, Telefone, Salario, Cargo, Sexo, Datadia) VALUES('Marcela', 78126532, 2658, 'Atendente', 'Feminino', '02/10/1995');
INSERT INTO Funcionario (Nome, Telefone, Salario, Cargo, Sexo, Datadia) VALUES('Ana', 12453256, 4159, 'Web Design', 'Feminino', '12/07/1994');
INSERT INTO Funcionario (Nome, Telefone, Salario, Cargo, Sexo, Datadia) VALUES('Gabriel', 45895678, 7000, 'Gerente de TI', 'Masculino', '30/11/1997');
INSERT INTO Funcionario (Nome, Telefone, Salario, Cargo, Sexo, Datadia) VALUES('Claudia', 56984174, 3500, 'Analista', 'Feminino', '20/07/1997');
INSERT INTO Funcionario (Nome, Telefone, Salario, Cargo, Sexo, Datadia) VALUES('Claudio', 41748552, 3000, 'Analista', 'Masculino', '07/08/1995');
INSERT INTO Funcionario (Nome, Telefone, Salario, Cargo, Sexo, Datadia) VALUES('Gabriela', 25632145, 5400, 'Programadora', 'Feminino', '21/11/1997');
INSERT INTO Funcionario (Nome, Telefone, Salario, Cargo, Sexo, Datadia) VALUES('Adriano', 96967365, 1200, 'Estagiario', 'Masculino', '18/05/1998');
INSERT INTO Funcionario (Nome, Telefone, Salario, Cargo, Sexo, Datadia) VALUES('Fabiana', 21365401, 4000, 'Designer', 'Feminino', '14/07/1996');
INSERT INTO Funcionario (Nome, Telefone, Salario, Cargo, Sexo, Datadia) VALUES('Julia', 41203698, 1200, 'Estagiaria', 'Feminino', '15/09/1998');
INSERT INTO Funcionario (Nome, Telefone, Salario, Cargo, Sexo, Datadia) VALUES('Luciano', 89560102, 4200, 'Marketing', 'Masculino', '07/02/1995');
*/
