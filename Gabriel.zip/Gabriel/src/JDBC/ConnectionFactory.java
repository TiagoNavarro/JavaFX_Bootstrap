package JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class ConnectionFactory
{
    public static Connection getConnection()
    {
        Connection conexao_BD_POSTGREE = null;
        //Connection conexao_BD_MYSQL = null;
        
        try{
            conexao_BD_POSTGREE = DriverManager.getConnection("jdbc:postgresql://localhost/BD_JavaFX_Aprendendo", "postgres", "12345");
        }catch(SQLException ex){
            System.out.println("azul " + ex.getMessage());
        }
        
        return conexao_BD_POSTGREE;
    }
}
