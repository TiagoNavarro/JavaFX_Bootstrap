package javafx_aprendendo.Controls;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author <Gabriel Mello de Oliveira
 */

public class FXML_CadastroController implements Initializable
{

    //Labels
    @FXML private Label Txt_Nome;
    @FXML private Label Txt_CPF;
    
    //Buttons
    @FXML private Button BT_Cadastrar;
    @FXML private Button BT_Voltar;
    @FXML private Button BT_Limpar;
    
    //TextFields
    @FXML private TextField CT_Nome;
    @FXML private TextField CT_CPF;
    @FXML private TextField CT_RG;
 
    @FXML
    private void Cadastrar(ActionEvent event)
    {
        Stage_Cadastro.close();
    }
    
    @FXML
    private void Voltar(ActionEvent event)
    {
        Stage_Cadastro.close();
    }
    
    @FXML
    private void Limpar(ActionEvent event)
    {
        CT_Nome.setText("");
        
        CT_CPF.clear();
        
        CT_RG.clear();
    }
    
    //Cria o Stage da tela de Cadastro e da nome para ele.
    public static Stage Stage_Cadastro;
    
    public void start(Stage stage) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("FXML_Cadastro.fxml"));
        
        Scene scene = new Scene(root);
        stage.setTitle("Cadastro");
        stage.setScene(scene);
        stage.show();
        
        //O "Stage_Cadastro" vai receber tudo que tem na stage.
        Stage_Cadastro = stage;
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb){
        // TODO
    }    
    
}
