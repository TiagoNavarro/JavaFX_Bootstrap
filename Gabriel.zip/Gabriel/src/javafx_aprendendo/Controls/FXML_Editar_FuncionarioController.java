package javafx_aprendendo.Controls;

import Dao.Dao_Funcionario;
import static Dao.Dao_Funcionario.r;
import static Dao.Dao_Funcionario.st;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx_aprendendo.Models.Funcionario;

/**
 * FXML Controller class
 *
 * @author <Gabriel Mello de Oliveira
 */

public class FXML_Editar_FuncionarioController implements Initializable
{
    //Labels
    @FXML private Label Txt_Nome;
    @FXML private Label Txt_Telefone;
    @FXML private Label Txt_Salario;
    @FXML private Label Txt_Cargo;
    @FXML private Label Txt_Sexo;
    
    //Buttons
    @FXML private Button BT_Editar;
    @FXML private Button BT_Voltar;
    
    //TextFields
    @FXML private TextField CT_Nome;
    @FXML private TextField CT_Telefone;
    @FXML private TextField CT_Salario;
    @FXML private TextField CT_Cargo;
    @FXML private TextField CT_Pesquisa;
    
    //ComboBox
    @FXML private ComboBox CB_Sexo;
    
    //DatePicker
    @FXML private DatePicker Datadia;
    
    //Stage
    @FXML public static Stage Stage_Editar;
  
    //Variáveis do TextField
    @FXML public static String Nome;
    @FXML public static Integer Telefone;
    @FXML public static Float Salario;
    @FXML public static String Cargo;
    @FXML public static String Sexo;
    @FXML public static LocalDate datad;
    
    @FXML private void Carrega() throws SQLException
    { 
        r = st.executeQuery();
        r.next();
        
        FXML_PaineisController Paineis = new FXML_PaineisController();
        
        Funcionario f = new Funcionario();
  
        f.setNome(Nome);
        CT_Nome.setText(Nome);
        
        f.setTelefone(Telefone);
        CT_Telefone.setText(Telefone.toString());
        
        f.setSalario(Salario);
        CT_Salario.setText(String.valueOf(Salario));
        
        f.setCargo(Cargo);
        CT_Cargo.setText(Cargo);
         
        CB_Sexo.setItems(Paineis.Tipo_Sexo);
        f.setSexo(Sexo);
        CB_Sexo.setValue(Sexo);
        
        Datadia.setValue(datad);
        f.setData(datad);
        
        st.execute();
        
    }        
    
    @FXML private void Editar(ActionEvent Acao)
    {
        Dao_Funcionario dao = new Dao_Funcionario();
        
        Funcionario f = new Funcionario();
        
        f.setNome(CT_Nome.getText());
        f.setTelefone(Integer.valueOf(CT_Telefone.getText()));
        f.setSalario(Float.valueOf(CT_Salario.getText()));
        f.setCargo(CT_Cargo.getText());
        f.setSexo(CB_Sexo.getValue().toString());
        f.setData(Datadia.getValue());
        
        dao.Edita_Funcionario(f);
        
        Alert alert = new Alert(Alert.AlertType.INFORMATION); 
            
        alert.setTitle("Sucesso!");
        alert.setHeaderText("Funcionário editado com sucesso!");
        alert.setContentText("Edição realizada com sucesso!");
        alert.showAndWait();
   
    } 
      
    @FXML private void Voltar(ActionEvent Acao)
    {
        Stage_Editar.close();
    }
    
    public void Start(Stage stage) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("FXML_Editar_Funcionario.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
        
        Stage_Editar = stage;
        
    }        
    
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
        try {
            Carrega();
        } catch (SQLException ex) {
            Logger.getLogger(FXML_Editar_FuncionarioController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }      
}
