package javafx_aprendendo.Controls;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.stage.Stage;
import static javafx_aprendendo.Controls.FXML_Editar_FuncionarioController.*;

/**
 * FXML Controller class
 *
 * @author Gabriel
 */

public class FXML_GraficosController implements Initializable
{
    @FXML private BarChart barchart;
    @FXML private CategoryAxis categoryaxis;
    @FXML private NumberAxis numberaxis;
    
    @FXML public void Grafico()
    {
       
    }        
    
    public void start(Stage stage) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("FXML_Graficos.fxml"));
        Scene cena = new Scene(root);
        stage.setScene(cena);
        stage.show();
    }        
    
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
        Grafico();
    }    
    
}
