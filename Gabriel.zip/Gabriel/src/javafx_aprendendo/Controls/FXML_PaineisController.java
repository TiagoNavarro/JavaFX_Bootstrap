package javafx_aprendendo.Controls;

import Dao.Dao_Funcionario;
import static Dao.Dao_Funcionario.Coloca_Funcionario;
import java.awt.event.ActionListener;
import static java.lang.Double.parseDouble;
import static java.lang.Float.parseFloat;
import static java.lang.Integer.parseInt;
import java.net.URL;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Observable;
import java.util.ResourceBundle;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import static javafx_aprendendo.Controls.FXML_Editar_FuncionarioController.*;
import javafx_aprendendo.Models.Funcionario;

/**
 * FXML Controller class
 *
 * @author <Gabriel Mello de Oliveira
 */

public class FXML_PaineisController implements Initializable
{  
    //Labels
    @FXML private Label Txt_Nome;
    @FXML private Label Txt_Telefone;
    @FXML private Label Txt_Salario;
    @FXML private Label Txt_Cargo;
    @FXML private Label Txt_Sexo;
    @FXML private Label Txt_Pesquisa;
    
    //Buttons
    @FXML private Button BT_Cadastrar;
    
    //TextFields
    @FXML private TextField CT_Nome;
    @FXML private TextField CT_Telefone;
    @FXML private TextField CT_Salario;
    @FXML private TextField CT_Cargo;
    @FXML private TextField CT_Pesquisa;
    
    //ComboBox
    @FXML private ComboBox CB_Sexo;
    
    //DatePicker
    @FXML private DatePicker Datadia;
    
    //Tabelas
    @FXML TableView <Funcionario> Tabela_Funcionario;
    @FXML TableColumn <Funcionario, String> Coluna_Nome;
    @FXML TableColumn <Funcionario, Integer> Coluna_Telefone;
    @FXML TableColumn <Funcionario, Float> Coluna_Salario;
    @FXML TableColumn <Funcionario, String> Coluna_Cargo;
    @FXML TableColumn <Funcionario, String> Coluna_Sexo;
    @FXML TableColumn <Funcionario, String> Coluna_DataDia;
    
    @FXML Dao_Funcionario dao = new Dao_Funcionario();
    
    @FXML ObservableList<String> Tipo_Sexo = FXCollections.observableArrayList("Masculino", "Feminino", "Outro");
    
    @FXML private ObservableList <Funcionario> Funcionario_OBList;
    
    @FXML private static Funcionario Funcionario_Selecionado;
    
    @FXML
    private void Cadastrar(ActionEvent event)
    {
        if(CT_Nome.getText().equals("") || CT_Telefone.getText().equals("") || CT_Salario.getText().equals("") || CT_Cargo.getText().equals("") || CB_Sexo.getValue().equals(null) || Datadia.getValue().equals(null))
        {
            
            Alert alert = new Alert(Alert.AlertType.WARNING); 
            
            alert.setTitle("Erro!");
            alert.setHeaderText("Campos vazios!");
            alert.setContentText("Preencha todos os campos");
            alert.showAndWait();
        }else{
            
            try{
            
            Funcionario func = new Funcionario();
            
            func.setNome(CT_Nome.getText());
            func.setTelefone(Integer.valueOf(CT_Telefone.getText()));
            func.setSalario(Float.valueOf(CT_Salario.getText()));
            func.setCargo(CT_Cargo.getText());
            func.setSexo(CB_Sexo.getValue().toString());        
            func.setData(Datadia.getValue());
            Dao_Funcionario.Coloca_Funcionario(func); 
                        
            Alert alert = new Alert(Alert.AlertType.INFORMATION); 
            
            alert.setTitle("Sucesso!");
            alert.setHeaderText("Campos preenchidos com sucesso!");
            alert.setContentText("Cadastro realizado com sucesso!");
            alert.showAndWait();
            
            Limpar();
            
            Preencher_Tabela();
            
            }catch(Exception ex){
                System.out.println("erro ao cadastrar: " + ex.getMessage());
            }
        }    
    }
    
    @FXML
    private void Limpar()
    {
        CT_Nome.clear();
        CT_Telefone.clear();
        CT_Salario.clear();
        CT_Cargo.clear();
        CB_Sexo.setValue("");
        Datadia.setValue(LocalDate.now());
    }
    
    @FXML
    public void Edita_Funcionario(ActionEvent acao) throws Exception
    {
        if(FXML_PaineisController.Funcionario_Selecionado != null)
        {       
            Nome = Funcionario_Selecionado.getNome(); 
            Telefone = Funcionario_Selecionado.getTelefone();
            Salario = Funcionario_Selecionado.getSalario();
            Cargo = Funcionario_Selecionado.getCargo(); 
            Sexo = Funcionario_Selecionado.getSexo();
            datad = Funcionario_Selecionado.getDatadia();
                            
            FXML_Editar_FuncionarioController Tela_Editar = new FXML_Editar_FuncionarioController();          
            Tela_Editar.Start(new Stage());
        }else{
                Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Por favor, selecione um Funcionário!");
                a.showAndWait();
        }
    }
    
    @FXML
    public void Deleta_Funcionario(ActionEvent acao)
    {
        if(FXML_PaineisController.Funcionario_Selecionado != null){
                Dao_Funcionario DAO = new Dao_Funcionario();
                DAO.Deleta_Funcionario(FXML_PaineisController.Funcionario_Selecionado);
                Alert a=new Alert(Alert.AlertType.CONFIRMATION);
                a.setHeaderText("Funcionario deletado com sucesso!");
                a.showAndWait();
                Preencher_Tabela();
        }else{
                Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Por favor, selecione um Funcionário!");
                a.showAndWait();
        }
    }        
    
    @FXML
    public void Preencher_Tabela()
    {
        Coluna_Nome.setCellValueFactory(new PropertyValueFactory("Nome"));
        Coluna_Telefone.setCellValueFactory(new PropertyValueFactory("Telefone"));        
        Coluna_Salario.setCellValueFactory(new PropertyValueFactory("Salario"));
        Coluna_Cargo.setCellValueFactory(new PropertyValueFactory("Cargo"));
        Coluna_Sexo.setCellValueFactory(new PropertyValueFactory("Sexo"));
        Coluna_DataDia.setCellValueFactory(new PropertyValueFactory("Datadia"));
       
        
        Dao_Funcionario DAO = new Dao_Funcionario();
        Funcionario_OBList = DAO.get_Funcionario();
        Tabela_Funcionario.setItems(Funcionario_OBList);        
    }        
    
    @FXML
    public void Pesquisar()
    {
        ObservableList<Funcionario> Func = FXCollections.observableArrayList();
        
        for (Funcionario Funcionario_OBList1 : Funcionario_OBList) {
            if (Funcionario_OBList1.getNome().contains(CT_Pesquisa.getText())) {
                Func.add(Funcionario_OBList1);
            }
        }
        Tabela_Funcionario.setItems(Func);        
    }        
    
    //Cria o Stage da tela Paineis e da nome para ele.
    @FXML public static Stage Stage_Paineis;
    
    @FXML
    public void start(Stage stage) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("FXML_Paineis.fxml"));
        
        Scene scene = new Scene(root);
        stage.setTitle("Home");
        stage.setScene(scene);
        //stage.setResizable(false);
        stage.show();
        
        //O "Stage_Home" vai receber tudo que tem na stage.
        Stage_Paineis = stage;
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
        CB_Sexo.setItems(Tipo_Sexo);
        
        //Preenche a Tabela quando a tela é aberta
        Preencher_Tabela();
        
        Tabela_Funcionario.getSelectionModel().selectedItemProperty().addListener(new ChangeListener()
        {
             @Override
             public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                 if(newValue != null){
                    FXML_PaineisController.Funcionario_Selecionado = (Funcionario) newValue;
                 }else{
                    FXML_PaineisController.Funcionario_Selecionado = null;
                 }
             }
         });
         
         CT_Pesquisa.setOnKeyReleased((KeyEvent e)->{
             Pesquisar();
         });
         
    }        
}
