package javafx_aprendendo.Controls;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class JavaFX_Aprendendo extends Application
{   
    @Override
    //O "start" da início da tela.
    //O "Stage" é responsável pela Tela do sistema, se tirar a tela não é nem mostrada, toda tela tem um Stage.
    //O "stage" ele serve para colocar os elementos da tela.
    public void start(Stage stage) throws Exception
    {
        //Essa linha é responsável por chamar/carregar o Arquivo FXML(Tela).
        //O "root" é um objeto que recebe o local do arquivo.
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));        
        
        //O "Scene" é criado e colocado o "root" dentro dele, mostrando a localização do arquivo.
        Scene scene = new Scene(root);        
        
        //O "Scene" é colocado dentro da "stage".
        stage.setScene(scene);
        
        //Coloca um título para a tela.
        stage.setTitle("Aprendendo JavaFX");
        
        //stage.setFullScreen(true);
        
        stage.setResizable(false);
        
        //O "show" serve para mostrar a tela, exibir a tela.
        stage.show();
        
        FXMLDocumentController.Stage = stage;
            
    }
    
    /**
     * @param args the command line arguments
     */
    
    //Executa o código.
    public static void main(String[] args)
    {
        launch(args);
    }   
}
