/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import dao.AlunosDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Alunos;

/**
 *
 * @author aluno
 */
public class CadastraAlunos extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        Alunos alunos = new Alunos();
        alunos.setApro1(Integer.parseInt(request.getParameter("apro1")));
        alunos.setApro2(Integer.parseInt(request.getParameter("apro2")));
        alunos.setApro3(Integer.parseInt(request.getParameter("apro3")));
        alunos.setApro4(Integer.parseInt(request.getParameter("apro4")));
        alunos.setApro5(Integer.parseInt(request.getParameter("apro5")));
        alunos.setRepro1(Integer.parseInt(request.getParameter("repro1")));
        alunos.setRepro2(Integer.parseInt(request.getParameter("repro2")));
        alunos.setRepro3(Integer.parseInt(request.getParameter("repro3")));
        alunos.setRepro4(Integer.parseInt(request.getParameter("repro4")));
        alunos.setRepro5(Integer.parseInt(request.getParameter("repro5")));
        alunos.setEvad1(Integer.parseInt(request.getParameter("evad1")));
        alunos.setEvad2(Integer.parseInt(request.getParameter("evad2")));
        alunos.setEvad3(Integer.parseInt(request.getParameter("evad3")));
        alunos.setEvad4(Integer.parseInt(request.getParameter("evad4")));
        alunos.setEvad5(Integer.parseInt(request.getParameter("evad5")));
        alunos.setTrans1(Integer.parseInt(request.getParameter("trans1")));
        alunos.setTrans2(Integer.parseInt(request.getParameter("trans2")));
        alunos.setTrans3(Integer.parseInt(request.getParameter("trans3")));
        alunos.setTrans4(Integer.parseInt(request.getParameter("trans4")));
        alunos.setTrans5(Integer.parseInt(request.getParameter("trans5")));
        alunos.setAno(Integer.parseInt(request.getParameter("ano")));
        alunos.setColegio(request.getParameter("colegio"));
        
            AlunosDAO dao = new AlunosDAO();
            dao.setAlunos(alunos);


        }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}