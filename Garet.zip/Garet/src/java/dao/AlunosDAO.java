/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jdbc.ConnectionFactory;
import model.Alunos;

/**
 *
 * @author aluno
 */
public class AlunosDAO {
    Connection con;
    public void setAlunos(Alunos c){
        String sql = "INSERT INTO aprovados(apro1,apro2,apro3,apro4,apro5,repro1,repro2,repro3,repro4,repro5,evad1,evad2,evad3,evad4,evad5,trans1,trans2,trans3,trans4,trans5,ano,colegio)"
                + "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
        con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        try{
            stmt = con.prepareStatement(sql);
            stmt.setInt(1, c.getApro1());
            stmt.setInt(2, c.getApro2());
            stmt.setInt(3, c.getApro3());
            stmt.setInt(4, c.getApro4());
            stmt.setInt(5, c.getApro5());
            stmt.setInt(6, c.getRepro1());
            stmt.setInt(7, c.getRepro2());
            stmt.setInt(8, c.getRepro3());
            stmt.setInt(9, c.getRepro4());
            stmt.setInt(10, c.getRepro5());
            stmt.setInt(11, c.getEvad1());
            stmt.setInt(12, c.getEvad2());
            stmt.setInt(13, c.getEvad3());
            stmt.setInt(14, c.getEvad4());
            stmt.setInt(15, c.getEvad5());
            stmt.setInt(16, c.getTrans1());
            stmt.setInt(17, c.getTrans2());
            stmt.setInt(18, c.getTrans3());
            stmt.setInt(19, c.getTrans4());
            stmt.setInt(20, c.getTrans5());
            stmt.setInt(21, c.getAno());
            stmt.setString(22, c.getColegio());
            
            stmt.execute();
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
            try{
                stmt.close();
            }catch(SQLException e){
                e.printStackTrace();
            }
        }
    }
    public List<Alunos> getAlunos(){
        Connection con;
        List<Alunos> alunos = new ArrayList<Alunos>();
        String sql = "SELECT * FROM aprovados;";
        PreparedStatement stmt = null;
        try{
            con = ConnectionFactory.getConnection();
            stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Alunos c = new Alunos();
                    c.setApro1(rs.getInt("apro1"));
                    c.setApro2(rs.getInt("apro2"));
                    c.setApro3(rs.getInt("apro3"));
                    c.setApro4(rs.getInt("apro4"));
                    c.setApro5(rs.getInt("apro5"));
                    c.setRepro1(rs.getInt("repro1"));
                    c.setRepro2(rs.getInt("repro2"));
                    c.setRepro3(rs.getInt("repro3"));
                    c.setRepro4(rs.getInt("repro4"));
                    c.setRepro5(rs.getInt("repro5"));
                    c.setEvad1(rs.getInt("evad1"));
                    c.setEvad2(rs.getInt("evad2"));
                    c.setEvad3(rs.getInt("evad3"));
                    c.setEvad4(rs.getInt("evad4"));
                    c.setEvad5(rs.getInt("evad5"));
                    c.setTrans1(rs.getInt("trans1"));
                    c.setTrans2(rs.getInt("trans2"));
                    c.setTrans3(rs.getInt("trans3"));
                    c.setTrans4(rs.getInt("trans4"));
                    c.setTrans5(rs.getInt("trans5"));
                    c.setAno(rs.getInt("ano"));
                    c.setColegio(rs.getString("Colegio"));
                    alunos.add(c);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return alunos;
    }
}
