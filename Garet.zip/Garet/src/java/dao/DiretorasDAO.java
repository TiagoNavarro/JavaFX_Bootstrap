package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jdbc.ConnectionFactory;
import model.Diretoras;

/**
 *
 * @author aluno
 */
public class DiretorasDAO {
    Connection con;
    public void setDiretoras(Diretoras c){
        String sql = "INSERT INTO usuario(nome,sobrenome,colegio1,login,senha)"
                + "VALUES(?,?,?,?,?);";
        con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        try{
            stmt = con.prepareStatement(sql);
            stmt.setString(1, c.getNome());
            stmt.setString(2, c.getSobrenome());
            stmt.setString(3, c.getColegio1());
            stmt.setString(4, c.getLogin());
            stmt.setString(5, c.getSenha());
            
            
            stmt.execute();
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
            try{
                stmt.close();
            }catch(SQLException e){
                e.printStackTrace();
            }
        }
    }
    public List<Diretoras> getDiretoras(){
        Connection con;
        List<Diretoras> diretoras = new ArrayList<Diretoras>();
        String sql = "SELECT * FROM usuario;";
        PreparedStatement stmt = null;
        try{
            con = ConnectionFactory.getConnection();
            stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Diretoras c = new Diretoras();
                    c.setNome(rs.getString("nome"));
                    c.setSobrenome(rs.getString("sobrenome"));
                    c.setColegio1(rs.getString("colegio1"));
                    c.setLogin(rs.getString("login"));
                    c.setSenha(rs.getString("senha"));
                    
                    diretoras.add(c);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return diretoras;
    }
}

