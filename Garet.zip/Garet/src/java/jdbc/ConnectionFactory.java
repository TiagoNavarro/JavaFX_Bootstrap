/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import org.postgresql.Driver;
/**
 *
 * @author aluno
 */
public class ConnectionFactory {
    public static Connection getConnection(){
        Connection c = null;
        try{
            Class.forName("org.postgresql.Driver");
            c = DriverManager.getConnection("jdbc:postgresql://localhost/alunos", "postgres", "12345");
        }catch(SQLException e){
            System.out.println("INICIO DO ERRO");
            e.printStackTrace();
            System.out.println("FIM DO ERRO");
        }catch(ClassNotFoundException e){
            System.out.println("INICIO DO ERRO");
            e.printStackTrace();
            System.out.println("FIM DO ERRO");
        }
        return c;
    }
}
