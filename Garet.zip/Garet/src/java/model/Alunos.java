/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author aluno
 */
public class Alunos {
    private int totalApro;
    private int apro1;
    private int apro2;
    private int apro3;
    private int apro4;
    private int apro5;
    
    private int totalRepro;
    private int repro1;
    private int repro2;
    private int repro3;
    private int repro4;
    private int repro5;
    
    private int totalEvad;
    private int evad1;
    private int evad2;
    private int evad3;
    private int evad4;
    private int evad5;
    
    private int totalTrans;
    private int trans1;
    private int trans2;
    private int trans3;
    private int trans4;
    private int trans5;
    private int ano;
    private String colegio;

    public int getApro1() {
        return apro1;
    }

    public void setApro1(int apro1) {
        this.apro1 = apro1;
    }

    public int getApro2() {
        return apro2;
    }

    public void setApro2(int apro2) {
        this.apro2 = apro2;
    }

    public int getApro3() {
        return apro3;
    }

    public void setApro3(int apro3) {
        this.apro3 = apro3;
    }

    public int getApro4() {
        return apro4;
    }

    public void setApro4(int apro4) {
        this.apro4 = apro4;
    }

    public int getApro5() {
        return apro5;
    }

    public void setApro5(int apro5) {
        this.apro5 = apro5;
    }

    public int getRepro1() {
        return repro1;
    }

    public void setRepro1(int repro1) {
        this.repro1 = repro1;
    }

    public int getRepro2() {
        return repro2;
    }

    public void setRepro2(int repro2) {
        this.repro2 = repro2;
    }

    public int getRepro3() {
        return repro3;
    }

    public void setRepro3(int repro3) {
        this.repro3 = repro3;
    }

    public int getRepro4() {
        return repro4;
    }

    public void setRepro4(int repro4) {
        this.repro4 = repro4;
    }

    public int getRepro5() {
        return repro5;
    }

    public void setRepro5(int repro5) {
        this.repro5 = repro5;
    }

    public int getEvad1() {
        return evad1;
    }

    public void setEvad1(int evad1) {
        this.evad1 = evad1;
    }

    public int getEvad2() {
        return evad2;
    }

    public void setEvad2(int evad2) {
        this.evad2 = evad2;
    }

    public int getEvad3() {
        return evad3;
    }

    public void setEvad3(int evad3) {
        this.evad3 = evad3;
    }

    public int getEvad4() {
        return evad4;
    }

    public void setEvad4(int evad4) {
        this.evad4 = evad4;
    }

    public int getEvad5() {
        return evad5;
    }

    public void setEvad5(int evad5) {
        this.evad5 = evad5;
    }

    public int getTrans1() {
        return trans1;
    }

    public void setTrans1(int trans1) {
        this.trans1 = trans1;
    }

    public int getTrans2() {
        return trans2;
    }

    public void setTrans2(int trans2) {
        this.trans2 = trans2;
    }

    public int getTrans3() {
        return trans3;
    }

    public void setTrans3(int trans3) {
        this.trans3 = trans3;
    }

    public int getTrans4() {
        return trans4;
    }

    public void setTrans4(int trans4) {
        this.trans4 = trans4;
    }

    public int getTrans5() {
        return trans5;
    }

    public void setTrans5(int trans5) {
        this.trans5 = trans5;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public int getTotalApro() {
        return totalApro = apro1+apro2+apro3+apro4+apro5;
    }

    public void setTotalApro(int totalApro) {
        this.totalApro = apro1+apro2+apro3+apro4+apro5;
    }

    public int getTotalRepro() {
        return totalRepro = repro1+repro2+repro3+repro4+repro5;
    }

    public void setTotalRepro(int totalRepro) {
        this.totalRepro = repro1+repro2+repro3+repro4+repro5;
    }

    public int getTotalEvad() {
        return totalEvad = evad1+evad2+evad3+evad4+evad5;
    }

    public void setTotalEvad(int totalEvad) {
        this.totalEvad = evad1+evad2+evad3+evad4+evad5;
    }

    public int getTotalTrans() {
        return totalTrans = trans1+trans2+trans3+trans4+trans5;
    }

    public void setTotalTrans(int totalTrans) {
        this.totalTrans = trans1+trans2+trans3+trans4+trans5;
    }

    public String getColegio() {
        return colegio;
    }

    public void setColegio(String colegio) {
        this.colegio = colegio;
    }

    
    
    
    

    
}
