/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author aluno
 */
public class ProcessaFormulario extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        
        
        String apro1 = (String) request.getParameter("apro1");
        String apro2 = (String) request.getParameter("apro2");
        String apro3 = (String) request.getParameter("apro3");
        String apro4 = (String) request.getParameter("apro4");
        String apro5 = (String) request.getParameter("apro5");
        String repro1 = (String) request.getParameter("repro1");
        String repro2 = (String) request.getParameter("repro2");
        String repro3 = (String) request.getParameter("repro3");
        String repro4 = (String) request.getParameter("repro4");
        String repro5 = (String) request.getParameter("repro5");
        String evad1 = (String) request.getParameter("evad1");
        String evad2 = (String) request.getParameter("evad5");
        String evad3 = (String) request.getParameter("evad3");
        String evad4 = (String) request.getParameter("evad4");
        String evad5 = (String) request.getParameter("evad5");
        String trans1 = (String) request.getParameter("trans1");
        String trans2 = (String) request.getParameter("trans2");
        String trans3 = (String) request.getParameter("trans3");
        String trans4 = (String) request.getParameter("trans4");
        String trans5 = (String) request.getParameter("trans5");
        String ano = (String) request.getParameter("ano");
        String colegio = (String) request.getParameter("colegio");
        
        String nome = (String) request.getParameter("nome");
        String sobrenome = (String) request.getParameter("sobrenome");
        String colegio1 = (String) request.getParameter("colegio1");
        String login = (String) request.getParameter("login");
        String senha = (String) request.getParameter("senha");
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
