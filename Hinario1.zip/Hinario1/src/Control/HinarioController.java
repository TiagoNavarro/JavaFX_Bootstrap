/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;


import Model.Musica;
import hinario.Hinario;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Side;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import Util.Effect;
import Util.ListaMusica;
import javafx.animation.FadeTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.MenuBar;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.util.Duration;

/**
 *
 * @author Patrick
 */
public class HinarioController extends Effect implements Initializable {
    
    @FXML private Tab tabJovem;
    @FXML private TextField txNumeroHino;
    @FXML private Tab tabDoxologia;
    @FXML private Tab tabHinario;
    @FXML private Tab tabColetaneas;
    @FXML private Tab tabColetanea2;
    @FXML private Tab tabBusca;
    
    @FXML private Button btAbrir;
    @FXML private AnchorPane acpInteiro;
    @FXML private TabPane tabP;
    @FXML private ImageView setaEsquerda;
    @FXML private ImageView setaDireita;
    @FXML private ImageView setaCima;
    @FXML private ImageView setaBaixo;
    @FXML private ImageView idImgFull;
    @FXML private ImageView idImgFull1;
    @FXML private ImageView idImgFull2;
    @FXML private ImageView idImgFull3;
    @FXML private ImageView idImgFull4;
    @FXML private ImageView img2015;
    @FXML private ImageView img2014;
    @FXML private ImageView img2013;
    @FXML private ImageView img2012;
    @FXML private ImageView img2011;
    @FXML private ImageView img2010;
    @FXML private ImageView img2009;
    @FXML private ImageView img2008;
    @FXML private ImageView img2007;
    @FXML private ImageView img2006;
    @FXML private ImageView img2005;
    @FXML private ImageView img2004;
    @FXML private ImageView img2003;
    @FXML private ImageView img2002;
    @FXML private ImageView img2001;
    @FXML private ImageView img2000;
    @FXML private ImageView img1999;
    @FXML private ImageView img1998;
    @FXML private ImageView img1997;
    @FXML private ImageView img1996;
    @FXML private ImageView img1995;
    @FXML private ImageView img1994;
    @FXML private ImageView img1993;
    @FXML private ImageView img1992;
    @FXML private Label lb2015;
    @FXML private Label lb2014;
    @FXML private Label lb2013;
    @FXML private Label lb2012;
    @FXML private Label lb2011;
    @FXML private Label lb2010;
    @FXML private Label lb2009;
    @FXML private Label lb2008;
    @FXML private Label lb2007;
    @FXML private Label lb2006;
    @FXML private Label lb2005;
    @FXML private Label lb2004;
    @FXML private Label lb2003;
    @FXML private Label lb2002;
    @FXML private Label lb2001;
    @FXML private Label lb2000;
    @FXML private Label lb1999;
    @FXML private Label lb1998;
    @FXML private Label lb1997;
    @FXML private Label lb1996;
    @FXML private Label lb1995;
    @FXML private Label lb1994;
    @FXML private Label lb1993;
    @FXML private Label lb1992;
    
    //Doxologia
    @FXML private ImageView nosTeAdoramos;
    @FXML private ImageView provaDeAmor;
    @FXML private ImageView adoracaoInfantil;
    @FXML private ImageView aPalavraDoSenhor;
    @FXML private ImageView emPazEuVou;
    @FXML private ImageView aoSairDoSantoLugar;
    @FXML private ImageView cultoAbertura;
    @FXML private ImageView cultoDoxologia;
    @FXML private ImageView amem;
    @FXML private ImageView ofertorio;
    @FXML private ImageView despedida;
    @FXML private ImageView pedidoDeOracao;
    @FXML private ImageView amigoNaoSaiaSemCristo;
    @FXML private ImageView aoOrarmosSenhor;
    @FXML private ImageView deusDeIsrael;
    @FXML private ImageView ohAdorai;
    @FXML private ImageView permanecaEmMim;
    @FXML private ImageView queroOfertar;
    @FXML private ImageView sintaAPresencaDoSenhor;
    @FXML private ImageView umMilagreSeRealizara;
    @FXML private ImageView vemEspiritoSanto;
    @FXML private ImageView vindeMeninos;
    @FXML private ImageView nosBracosDeJesus;
    @FXML private ImageView familia;
    @FXML private Label lbNosTeAdoramos;
    @FXML private Label lbProvaDeAmor;
    @FXML private Label lbAdoracaoInfantil;
    @FXML private Label lbAPalavraDoSenhor;
    @FXML private Label lbEmPazEuVou;
    @FXML private Label lbAoSairDoSantoLugar;

    //Coletâneas
    
    @FXML private ImageView adoradores;
    @FXML private ImageView salmos;
    @FXML private ImageView filhosDeIsrael;
    @FXML private ImageView jesusLuzDoMundo;
    @FXML private ImageView estaEscrito;
    @FXML private ImageView estaEscrito2;
    @FXML private ImageView ministerioNovoTempo;
    @FXML private ImageView ministerioNovoSentido;
    @FXML private ImageView ministerioNovaVoz;
    @FXML private ImageView redencaoJP;
    @FXML private ImageView fernandaLara;
    @FXML private ImageView aEsperancaEJesus;
    @FXML private ImageView amizade;
    @FXML private ImageView amizadeEPraSempre;
    @FXML private ImageView digaAoMundo;
    @FXML private ImageView jesusMeuReiAmigo;
    @FXML private ImageView restaurandoVidas;
    @FXML private ImageView escolhidosParaBrilhar;
    @FXML private ImageView vamosLouvar;
    @FXML private ImageView louveAoSenhor;
    @FXML private ImageView emComunhao;
    @FXML private ImageView eleMeLevaAAdorar;
    @FXML private ImageView eRecebereiPoder;
    @FXML private ImageView eSoLouvar;

    @FXML private Label lbAdoradores;
    @FXML private Label lbSalmos;
    @FXML private Label lbFilhosDeIsrael;
    @FXML private Label lbJesusLuzDoMundo;
    @FXML private Label lbMinisterio;
    @FXML private Label lbMinisterio2;
    @FXML private Label lbMinisterioNovoTempo;
    @FXML private Label lbMinisterioNovoSentido;
    @FXML private Label lbMinisterioNovaVoz;
    @FXML private Label lbRedencaoJP;
    @FXML private Label lbFernandaLara;
    @FXML private Label lbAEsperancaEJesus;
    @FXML private Label lbAmizade;
    @FXML private Label lbAmizadeEPraSempre;
    @FXML private Label lbDigaAoMundo;
    @FXML private Label lbJesusMeuReiAmigo;
    @FXML private Label lbRestaurandoVidas;
    @FXML private Label lbEscolhidosParaBrilhar;
    @FXML private Label lbVamosLouvar;
    @FXML private Label lbLouveAoSenhor;
    @FXML private Label lbEmComunhao;
    @FXML private Label lbEleMeLevaAAdorar;
    @FXML private Label lbERecebereiPoder;
    @FXML private Label lbESoLouvar;
    
    //Coletâneas 2
    
    @FXML private ImageView diasDePoder;
    @FXML private ImageView encontroJovensSomosTeus;
    @FXML private ImageView naTrilhaDaConquista;
    @FXML private ImageView evangelismoIntegrado;
    @FXML private ImageView eHoraDeViver;
    @FXML private ImageView escolhidoPorJesus;
    @FXML private ImageView impactoEsperanca;
    @FXML private ImageView colheita2006;
    @FXML private ImageView superacao;
    @FXML private ImageView novoSentidoQueroTeVer;
    @FXML private ImageView melhoreOMundo;
    @FXML private ImageView naPresencaDeDeus;
    @FXML private ImageView musicoterapia;
    @FXML private ImageView mensageirosDaEsperanca;
    @FXML private ImageView amigosDaEsperança;
    @FXML private ImageView cristoVolteVolteJa;
    @FXML private ImageView familiaPorFamilias;
    @FXML private ImageView louvor2005;
    @FXML private ImageView louvor2006;
    @FXML private ImageView camporiAAMAR;
    @FXML private ImageView camporiACeAM;
    @FXML private ImageView novaDescoberta;
    @FXML private ImageView vidaPlena;
    @FXML private ImageView evangelismoComEsperanca;

    @FXML private Label lbDiasDePoder;
    @FXML private Label lbEncontroJovensSomosTeus;
    @FXML private Label lbNaTrilhaDaConquista;
    @FXML private Label lbEvangelismoIntegrado;
    @FXML private Label lbEHoraDeViver;
    @FXML private Label lbEscolhidoPorJesus;
    @FXML private Label lbImpactoEsperanca;
    @FXML private Label lbColheita2006;
    @FXML private Label lbSuperacao;
    @FXML private Label lbNovoSentidoQueroTeVer;
    @FXML private Label lbMelhoreOMundo;
    @FXML private Label lbNaPresencaDeDeus;
    @FXML private Label lbMusicoterapia;
    @FXML private Label lbMensageirosDaEsperanca;
    @FXML private Label lbAmigosDaEsperança;
    @FXML private Label lbCristoVolteVolteJa;
    @FXML private Label lbFamiliaPorFamilias;
    @FXML private Label lbLouvor2005;
    @FXML private Label lbLouvor2006;
    @FXML private Label lbCamporiAAMAR;
    @FXML private Label lbCamporiACeAM;
    @FXML private Label lbNovaDescoberta;
    @FXML private Label lbVidaPlena;
    @FXML private Label lbEvangelismoComEsperanca;
    
    //Busca
    @FXML private TextField txBusca;
    @FXML private TextField txBuscaInvisivel;
    @FXML private Button btBuscar;
    @FXML private Button btAbrirHino;
    @FXML private MenuBar menuResultado;
    @FXML private TableView<Musica> tbHinos;
    @FXML private TableColumn<Musica,String> clmCDMusica;
    @FXML private TableColumn<Musica,String> clmNomeMusica;
    @FXML private TextField txDiretorio;
    @FXML private AnchorPane acpBusca;
    private ListaMusica listaMusicas = new ListaMusica();
    private ObservableList<Musica> musicas = listaMusicas.getMusica();
    
    private String numero;
    private String diretorio;
    private String caminho;
    private Scene scene;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initAction();
        initActionsKeyBusca();
        initActionsMouseBusca();
        executaCDS();
        initEffects();
        initTable();
     }   
    
    public void initTable(){
        //tbHinos.setItems(musicas);
        clmCDMusica.setCellValueFactory(cellData -> cellData.getValue().getCd());
        clmNomeMusica.setCellValueFactory(cellData -> cellData.getValue().getMusica());
        tbHinos.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue) -> diretorioHinoAbrir(newValue));
    }
    
    public void diretorioHinoAbrir(Musica musica){
        if(musica != null){
            txDiretorio.setText(musica.getCaminhoHino());
            System.out.println(txDiretorio.getText());
        }else{
            txDiretorio.setText("");
        }
    }
    
    public void initAction(){
        btAbrir.setOnMouseClicked((MouseEvent e) ->{
            pegaHino();
        });
        
        txNumeroHino.setOnKeyPressed((KeyEvent e)->{
            Validacao.numericField(txNumeroHino);
            
            if(e.getCode() == KeyCode.ENTER){
                pegaHino();
            }
        });
        
        //Ações dos botões de aumentar e diminuir
        mouseClickedAumentaDiminui(idImgFull,idImgFull1,idImgFull2,idImgFull3,idImgFull4,acpInteiro);
        mouseClickedAumentaDiminui(idImgFull1,idImgFull,idImgFull2,idImgFull3,idImgFull4,acpInteiro);
        mouseClickedAumentaDiminui(idImgFull2,idImgFull,idImgFull1,idImgFull3,idImgFull4,acpInteiro);
        mouseClickedAumentaDiminui(idImgFull3,idImgFull,idImgFull1,idImgFull2,idImgFull4,acpInteiro);
        mouseClickedAumentaDiminui(idImgFull4,idImgFull,idImgFull1,idImgFull2,idImgFull3,acpInteiro);
        
        tabPaneSide(setaCima,tabP,1);
        tabPaneSide(setaBaixo,tabP,2);
        tabPaneSide(setaEsquerda,tabP,3);
        tabPaneSide(setaDireita,tabP,4);
    }
    
    public void pegaHino(){
        String complemento="";
        diretorio = "C:/Coletânea de Louvor/HASD/";
        numero = txNumeroHino.getText();
        if(numero.length() == 1){
            complemento = "00";
        }else if(numero.length() == 2){
            complemento = "0";
        }
        numero = complemento+numero;
        caminho = diretorio + numero;    
        System.out.println(caminho);
        try{
            Runtime.getRuntime().exec(caminho);
        }catch(Exception e){
            louvorNaoEncontrado();
        }
        txNumeroHino.setText("");
    }
    
    public void initActionsMouseBusca(){
        
        
        btBuscar.setOnMouseClicked((MouseEvent e)->{
            procura();
        });
    }
    
    public void initActionsKeyBusca(){
        acpBusca.setOnKeyPressed((KeyEvent e)->{
            if(e.getCode() == KeyCode.F1){
                String diretorioHino = txDiretorio.getText();
                onMouseClicked(diretorioHino);
            }
        });
        
        txBusca.setOnKeyReleased((KeyEvent e)->{
            if(e.getCode() != KeyCode.BACK_SPACE){
                if(txBusca.getText().length()==1 && e.getCode() != KeyCode.ENTER && e.getCode() != KeyCode.UP && e.getCode() != KeyCode.DOWN
                    && e.getCode() != KeyCode.LEFT && e.getCode() != KeyCode.RIGHT && e.getCode() != KeyCode.F1 && e.getCode() != KeyCode.F2
                    && e.getCode() != KeyCode.F3 && e.getCode() != KeyCode.F4 && e.getCode() != KeyCode.F5 && e.getCode() != KeyCode.F6
                    && e.getCode() != KeyCode.F7 && e.getCode() != KeyCode.F8 && e.getCode() != KeyCode.F9 && e.getCode() != KeyCode.F10
                    && e.getCode() != KeyCode.F11 && e.getCode() != KeyCode.F12 && e.getCode() != KeyCode.ESCAPE && e.getCode() != KeyCode.END
                    && e.getCode() != KeyCode.PAUSE && e.getCode() != KeyCode.INSERT  && e.getCode() != KeyCode.HOME  && e.getCode() != KeyCode.PAGE_DOWN
                    && e.getCode() != KeyCode.PAGE_UP && e.getCode() != KeyCode.CONTROL  && e.getCode() != KeyCode.SHIFT && e.getCode() != KeyCode.ALT
                    && e.getCode() != KeyCode.CAPS && e.getCode() != KeyCode.TAB && e.getCode() != KeyCode.DELETE && e.getCode() != KeyCode.PRINTSCREEN
                    && e.getCode() != KeyCode.ALT_GRAPH && e.getCode() != KeyCode.WINDOWS){
                        initAparece(tbHinos);
                        initAparece(menuResultado);
                }
            }
            procura();
        });
       
       txBusca.setOnKeyPressed((KeyEvent e)->{
            if(e.getCode() == KeyCode.BACK_SPACE){
                if(txBusca.getText().length() != 0){
                    if(txBusca.getText().length()-1 <= 0){
                        initDesaparece(tbHinos);
                        initDesaparece(menuResultado);
                    }
                }
             }
            procura();
       });
    }
    
    public void procura(){
        if (!txBusca.getText().equals("")){
            tbHinos.setItems(findItems());
        } else {
            tbHinos.setItems(musicas);
        }
    }
    
    private void initAparece(Node e) {
        Duration d = new Duration(500);
        FadeTransition fadeTransition = new FadeTransition();
        fadeTransition.setFromValue(0);
        fadeTransition.setToValue(1);
        fadeTransition.setDuration(d);
        fadeTransition.setNode(e);
        fadeTransition.play();
    }
    
    private void initDesaparece(Node e) {
        Duration d = new Duration(500);
        FadeTransition fadeTransition = new FadeTransition();
        fadeTransition.setFromValue(1);
        fadeTransition.setToValue(0);
        fadeTransition.setDuration(d);
        fadeTransition.setNode(e);
        fadeTransition.play();
    }
        
    public void executaCDS(){
        onMouseClicked(img2015,"C:/Coletânea de Louvor/JA 2015.exe");
        onMouseClicked(img2014,"C:/Coletânea de Louvor/JA 2014.exe");
        onMouseClicked(img2013,"C:/Coletânea de Louvor/JA 2013.exe");
        onMouseClicked(img2012,"C:/Coletânea de Louvor/JA 2012.exe");
        onMouseClicked(img2011,"C:/Coletânea de Louvor/JA 2011.exe");
        onMouseClicked(img2010,"C:/Coletânea de Louvor/JA 2010.exe");
        onMouseClicked(img2009,"C:/Coletânea de Louvor/JA 2009.exe");
        onMouseClicked(img2008,"C:/Coletânea de Louvor/JA 2008.exe");
        onMouseClicked(img2007,"C:/Coletânea de Louvor/JA 2007.exe");
        onMouseClicked(img2006,"C:/Coletânea de Louvor/JA 2006.exe");
        onMouseClicked(img2005,"C:/Coletânea de Louvor/JA 2005.exe");
        onMouseClicked(img2004,"C:/Coletânea de Louvor/JA 2004.exe");
        onMouseClicked(img2003,"C:/Coletânea de Louvor/JA 2003.exe");
        onMouseClicked(img2002,"C:/Coletânea de Louvor/JA 2002.exe");
        onMouseClicked(img2001,"C:/Coletânea de Louvor/JA 2001.exe");
        onMouseClicked(img2000,"C:/Coletânea de Louvor/JA 2000.exe");
        onMouseClicked(img1999,"C:/Coletânea de Louvor/JA 1999.exe");
        onMouseClicked(img1998,"C:/Coletânea de Louvor/JA 1998.exe");
        onMouseClicked(img1997,"C:/Coletânea de Louvor/JA 1997.exe");
        onMouseClicked(img1996,"C:/Coletânea de Louvor/JA 1996.exe");
        onMouseClicked(img1995,"C:/Coletânea de Louvor/JA 1995.exe");
        onMouseClicked(img1994,"C:/Coletânea de Louvor/JA 1994.exe");
        onMouseClicked(img1993,"C:/Coletânea de Louvor/JA 1993.exe");
        onMouseClicked(img1992,"C:/Coletânea de Louvor/JA 1992.exe");
        
        // Aba doxologia ações
        onMouseClicked(nosTeAdoramos,"C:/Coletânea de Louvor/Doxologia/Nós Te Adoramos.exe");
        onMouseClicked(provaDeAmor,"C:/Coletânea de Louvor/Doxologia/Prova de Amor - Ofertório.exe");
        onMouseClicked(adoracaoInfantil,"C:/Coletânea de Louvor/Doxologia/AdoracaoInfantil.exe");
        onMouseClicked(aPalavraDoSenhor,"C:/Coletânea de Louvor/Doxologia/A Palavra do Senhor.exe");
        onMouseClicked(emPazEuVou,"C:/Coletânea de Louvor/Doxologia/emPazEuVou.exe");
        onMouseClicked(aoSairDoSantoLugar,"C:/Coletânea de Louvor/Doxologia/Ao Sair do Santo Lugar.exe");
       
        //Aba Coletâneas ações
        onMouseClicked(adoradores,"C:/Coletânea de Louvor/Adoradores.exe");
        onMouseClicked(salmos,"C:/Coletânea de Louvor/Salmos.exe");
        onMouseClicked(filhosDeIsrael,"C:/Coletânea de Louvor/Filhos de Israel.exe");
        onMouseClicked(jesusLuzDoMundo,"C:/Coletânea de Louvor/jesusLuzDoMundo.exe");
        onMouseClicked(estaEscrito,"C:/Coletânea de Louvor/Ministério de Louvor Vol.1.exe");
        onMouseClicked(estaEscrito2,"C:/Coletânea de Louvor/Ministério de Louvor.exe");
        onMouseClicked(ministerioNovoTempo,"C:/Coletânea de Louvor/Ministério de Louvor Novo Tempo.exe");
        onMouseClicked(ministerioNovoSentido,"C:/Coletânea de Louvor/Novo Sentido.exe");
        onMouseClicked(ministerioNovaVoz,"C:/Coletânea de Louvor/Nova Voz.exe");
        onMouseClicked(redencaoJP,"C:/Coletânea de Louvor/Jeferson_Pillar_Redencao.exe");
        onMouseClicked(fernandaLara,"C:/Coletânea de Louvor/Fernanda_Lara_Magnifico_Deus.exe");
        onMouseClicked(aEsperancaEJesus,"C:/Coletânea de Louvor/a_esperanca_e_jesus_pg.exe");
        onMouseClicked(amizade,"C:/Coletânea de Louvor/Amizade.exe");
        onMouseClicked(amizadeEPraSempre,"C:/Coletânea de Louvor/Amizade é Pra Sempre.exe");
        onMouseClicked(digaAoMundo,"C:/Coletânea de Louvor/Diga ao Mundo.exe");
        onMouseClicked(jesusMeuReiAmigo,"C:/Coletânea de Louvor/Jesus, Meu Rei, Meu Amigo.exe");
        onMouseClicked(restaurandoVidas,"C:/Coletânea de Louvor/restaurando vidas.exe");
        onMouseClicked(escolhidosParaBrilhar,"C:/Coletânea de Louvor/escolhidos para brilhar.exe");
        onMouseClicked(vamosLouvar,"C:/Coletânea de Louvor/Vamos Louvar.exe");
        onMouseClicked(louveAoSenhor,"C:/Coletânea de Louvor/louve ao senhor.exe");
        onMouseClicked(emComunhao,"C:/Coletânea de Louvor/Em Comunhão.exe");
        onMouseClicked(eleMeLevaAAdorar,"C:/Coletânea de Louvor/ELE Me Leva a ADORAR.exe");
        onMouseClicked(eRecebereiPoder,"C:/Coletânea de Louvor/e recebereis poder.exe");
        onMouseClicked(eSoLouvar,"C:/Coletânea de Louvor/É Só Louvor.exe");
        
        //Aba Coletaneas 2 ações
        
        onMouseClicked(diasDePoder,"C:/Coletânea de Louvor/21_dias_de_Poder.exe");
        onMouseClicked(encontroJovensSomosTeus,"C:/Coletânea de Louvor/Encontro Jovem Somos Teus.exe");
        onMouseClicked(naTrilhaDaConquista,"C:/Coletânea de Louvor/Na Trilha da Conquista.exe");
        onMouseClicked(evangelismoIntegrado,"C:/Coletânea de Louvor/Evangelismo Integrado.exe");
        onMouseClicked(eHoraDeViver,"C:/Coletânea de Louvor/");
        onMouseClicked(escolhidoPorJesus,"C:/Coletânea de Louvor/Escolhidos por Jesus.exe");
        onMouseClicked(impactoEsperanca,"C:/Coletânea de Louvor/Impacto Esperança.exe");
        onMouseClicked(colheita2006,"C:/Coletânea de Louvor/Colheita 2006.exe");
        onMouseClicked(superacao,"C:/Coletânea de Louvor/superação.exe");
        onMouseClicked(novoSentidoQueroTeVer,"C:/Coletânea de Louvor/Quero Te Ver.exe");
        onMouseClicked(melhoreOMundo,"C:/Coletânea de Louvor/Melhore o Mundo.exe");
        onMouseClicked(naPresencaDeDeus,"C:/Coletânea de Louvor/Na Presença de Deus.exe");
        onMouseClicked(musicoterapia,"C:/Coletânea de Louvor/Pra ser Feliz.exe");
        onMouseClicked(mensageirosDaEsperanca,"C:/Coletânea de Louvor/Mensageiros da Esperança.exe");
        onMouseClicked(amigosDaEsperança,"C:/Coletânea de Louvor/Amigos da Esperança.exe");
        onMouseClicked(cristoVolteVolteJa,"C:/Coletânea de Louvor/Cristo Volte, Volte Já.exe");
        onMouseClicked(familiaPorFamilias,"C:/Coletânea de Louvor/familia por familias.exe");
        onMouseClicked(louvor2005,"C:/Coletânea de Louvor/Louvor 2005.exe");
        onMouseClicked(louvor2006,"C:/Coletânea de Louvor/Louvor 2006.exe");
        onMouseClicked(camporiAAMAR,"C:/Coletânea de Louvor/campori aamar.exe");
        onMouseClicked(camporiACeAM,"C:/Coletânea de Louvor/campori aceam.exe");
        onMouseClicked(novaDescoberta,"C:/Coletânea de Louvor/Nova_Descoberta.exe");
        onMouseClicked(vidaPlena,"C:/Coletânea de Louvor/Vida_Plena.exe");
        onMouseClicked(evangelismoComEsperanca,"C:/Coletânea de Louvor/Evangelizando_com_Esperança.exe");
    }
    
    
    public void initEffects(){
        mouseClickedEntered();
        mouseClickedExited();
        initDesaparece(tbHinos);
        initDesaparece(menuResultado);
    }
    
    
    public void mouseClickedEntered(){
        onMouseEntered(img2015,lb2015);
        onMouseEntered(img2014,lb2014);
        onMouseEntered(img2013,lb2013);
        onMouseEntered(img2012,lb2012);
        onMouseEntered(img2011,lb2011);
        onMouseEntered(img2010,lb2010);
        onMouseEntered(img2009,lb2009);
        onMouseEntered(img2008,lb2008);
        onMouseEntered(img2007,lb2007);
        onMouseEntered(img2006,lb2006);
        onMouseEntered(img2005,lb2005);
        onMouseEntered(img2004,lb2004);
        onMouseEntered(img2003,lb2003);
        onMouseEntered(img2002,lb2002);
        onMouseEntered(img2001,lb2001);
        onMouseEntered(img2000,lb2000);
        onMouseEntered(img1999,lb1999);
        onMouseEntered(img1998,lb1998);
        onMouseEntered(img1997,lb1997);
        onMouseEntered(img1996,lb1996);
        onMouseEntered(img1995,lb1995);
        onMouseEntered(img1994,lb1994);
        onMouseEntered(img1993,lb1993);
        onMouseEntered(img1992,lb1992);
        //2 Aba - Doxologia
        onMouseEntered(nosTeAdoramos,lbNosTeAdoramos);
        onMouseEntered(provaDeAmor,lbProvaDeAmor);
        onMouseEntered(adoracaoInfantil,lbAdoracaoInfantil);
        onMouseEntered(aPalavraDoSenhor,lbAPalavraDoSenhor);
        onMouseEntered(emPazEuVou,lbEmPazEuVou);
        onMouseEntered(aoSairDoSantoLugar,lbAoSairDoSantoLugar);
        
        //3 Aba Coletâneas 
        onMouseEntered(adoradores,lbAdoradores);
        onMouseEntered(salmos,lbSalmos);
        onMouseEntered(filhosDeIsrael,lbFilhosDeIsrael);
        onMouseEntered(jesusLuzDoMundo,lbJesusLuzDoMundo);
        onMouseEntered(estaEscrito,lbMinisterio);
        onMouseEntered(estaEscrito2,lbMinisterio2);
        onMouseEntered(ministerioNovoTempo,lbMinisterioNovoTempo);
        onMouseEntered(ministerioNovoSentido,lbMinisterioNovoSentido);
        onMouseEntered(ministerioNovaVoz,lbMinisterioNovaVoz);
        onMouseEntered(redencaoJP,lbRedencaoJP);
        onMouseEntered(fernandaLara,lbFernandaLara);
        onMouseEntered(aEsperancaEJesus,lbAEsperancaEJesus);
        onMouseEntered(amizade,lbAmizade);
        onMouseEntered(amizadeEPraSempre,lbAmizadeEPraSempre);
        onMouseEntered(digaAoMundo,lbDigaAoMundo);
        onMouseEntered(jesusMeuReiAmigo,lbJesusMeuReiAmigo);
        onMouseEntered(restaurandoVidas,lbRestaurandoVidas);
        onMouseEntered(escolhidosParaBrilhar,lbEscolhidosParaBrilhar);
        onMouseEntered(vamosLouvar,lbVamosLouvar);
        onMouseEntered(louveAoSenhor,lbLouveAoSenhor);
        onMouseEntered(emComunhao,lbEmComunhao);
        onMouseEntered(eleMeLevaAAdorar,lbEleMeLevaAAdorar);
        onMouseEntered(eRecebereiPoder,lbERecebereiPoder);
        onMouseEntered(eSoLouvar,lbESoLouvar);
    
        //4 aba Coletâneas 2
        
        onMouseEntered(diasDePoder,lbDiasDePoder);
        onMouseEntered(encontroJovensSomosTeus,lbEncontroJovensSomosTeus);
        onMouseEntered(naTrilhaDaConquista,lbNaTrilhaDaConquista);
        onMouseEntered(evangelismoIntegrado,lbEvangelismoIntegrado);
        onMouseEntered(eHoraDeViver,lbEHoraDeViver);
        onMouseEntered(escolhidoPorJesus,lbEscolhidoPorJesus);
        onMouseEntered(impactoEsperanca,lbImpactoEsperanca);
        onMouseEntered(colheita2006,lbColheita2006);
        onMouseEntered(superacao,lbSuperacao);
        onMouseEntered(novoSentidoQueroTeVer,lbNovoSentidoQueroTeVer);
        onMouseEntered(melhoreOMundo,lbMelhoreOMundo);
        onMouseEntered(naPresencaDeDeus,lbNaPresencaDeDeus);
        onMouseEntered(musicoterapia,lbMusicoterapia);
        onMouseEntered(mensageirosDaEsperanca,lbMensageirosDaEsperanca);
        onMouseEntered(amigosDaEsperança,lbAmigosDaEsperança);
        onMouseEntered(cristoVolteVolteJa,lbCristoVolteVolteJa);
        onMouseEntered(familiaPorFamilias,lbFamiliaPorFamilias);
        onMouseEntered(louvor2005,lbLouvor2005);
        onMouseEntered(louvor2006,lbLouvor2006);
        onMouseEntered(camporiAAMAR,lbCamporiAAMAR);
        onMouseEntered(camporiACeAM,lbCamporiACeAM);
        onMouseEntered(novaDescoberta,lbNovaDescoberta);
        onMouseEntered(vidaPlena,lbVidaPlena);
        onMouseEntered(evangelismoComEsperanca,lbEvangelismoComEsperanca);
        
        //Busca
        onMouseEntered(txBusca,btBuscar,btAbrirHino);
    }
    
    public void mouseClickedExited(){
        onMouseExited(img2015,lb2015);
        onMouseExited(img2014,lb2014);
        onMouseExited(img2013,lb2013);
        onMouseExited(img2012,lb2012);
        onMouseExited(img2011,lb2011);
        onMouseExited(img2010,lb2010);
        onMouseExited(img2009,lb2009);
        onMouseExited(img2008,lb2008);
        onMouseExited(img2007,lb2007);
        onMouseExited(img2006,lb2006);
        onMouseExited(img2005,lb2005);
        onMouseExited(img2004,lb2004);
        onMouseExited(img2003,lb2003);
        onMouseExited(img2002,lb2002);
        onMouseExited(img2001,lb2001);
        onMouseExited(img2000,lb2000);
        onMouseExited(img1999,lb1999);
        onMouseExited(img1998,lb1998);
        onMouseExited(img1997,lb1997);
        onMouseExited(img1996,lb1996);
        onMouseExited(img1995,lb1995);
        onMouseExited(img1994,lb1994);
        onMouseExited(img1993,lb1993);
        onMouseExited(img1992,lb1992);
        
        //2 Aba - Doxologia
        onMouseExited(nosTeAdoramos,lbNosTeAdoramos);
        onMouseExited(provaDeAmor,lbProvaDeAmor);
        onMouseExited(adoracaoInfantil,lbAdoracaoInfantil);
        onMouseExited(aPalavraDoSenhor,lbAPalavraDoSenhor);
        onMouseExited(emPazEuVou,lbEmPazEuVou);
        onMouseExited(aoSairDoSantoLugar,lbAoSairDoSantoLugar);
        
        //3 Aba - Coletaneas
        onMouseExited(adoradores,lbAdoradores);
        onMouseExited(salmos,lbSalmos);
        onMouseExited(filhosDeIsrael,lbFilhosDeIsrael);
        onMouseExited(jesusLuzDoMundo,lbJesusLuzDoMundo);
        onMouseExited(estaEscrito,lbMinisterio);
        onMouseExited(estaEscrito2,lbMinisterio2);
        onMouseExited(ministerioNovoTempo,lbMinisterioNovoTempo);
        onMouseExited(ministerioNovoSentido,lbMinisterioNovoSentido);
        onMouseExited(ministerioNovaVoz,lbMinisterioNovaVoz);
        onMouseExited(redencaoJP,lbRedencaoJP);
        onMouseExited(fernandaLara,lbFernandaLara);
        onMouseExited(aEsperancaEJesus,lbAEsperancaEJesus);
        onMouseExited(amizade,lbAmizade);
        onMouseExited(amizadeEPraSempre,lbAmizadeEPraSempre);
        onMouseExited(digaAoMundo,lbDigaAoMundo);
        onMouseExited(jesusMeuReiAmigo,lbJesusMeuReiAmigo);
        onMouseExited(restaurandoVidas,lbRestaurandoVidas);
        onMouseExited(escolhidosParaBrilhar,lbEscolhidosParaBrilhar);
        onMouseExited(vamosLouvar,lbVamosLouvar);
        onMouseExited(louveAoSenhor,lbLouveAoSenhor);
        onMouseExited(emComunhao,lbEmComunhao);
        onMouseExited(eleMeLevaAAdorar,lbEleMeLevaAAdorar);
        onMouseExited(eRecebereiPoder,lbERecebereiPoder);
        onMouseExited(eSoLouvar,lbESoLouvar);
    
        //4 aba Coletâneas 2
        
        onMouseExited(diasDePoder,lbDiasDePoder);
        onMouseExited(encontroJovensSomosTeus,lbEncontroJovensSomosTeus);
        onMouseExited(naTrilhaDaConquista,lbNaTrilhaDaConquista);
        onMouseExited(evangelismoIntegrado,lbEvangelismoIntegrado);
        onMouseExited(eHoraDeViver,lbEHoraDeViver);
        onMouseExited(escolhidoPorJesus,lbEscolhidoPorJesus);
        onMouseExited(impactoEsperanca,lbImpactoEsperanca);
        onMouseExited(colheita2006,lbColheita2006);
        onMouseExited(superacao,lbSuperacao);
        onMouseExited(novoSentidoQueroTeVer,lbNovoSentidoQueroTeVer);
        onMouseExited(melhoreOMundo,lbMelhoreOMundo);
        onMouseExited(naPresencaDeDeus,lbNaPresencaDeDeus);
        onMouseExited(musicoterapia,lbMusicoterapia);
        onMouseExited(mensageirosDaEsperanca,lbMensageirosDaEsperanca);
        onMouseExited(amigosDaEsperança,lbAmigosDaEsperança);
        onMouseExited(cristoVolteVolteJa,lbCristoVolteVolteJa);
        onMouseExited(familiaPorFamilias,lbFamiliaPorFamilias);
        onMouseExited(louvor2005,lbLouvor2005);
        onMouseExited(louvor2006,lbLouvor2006);
        onMouseExited(camporiAAMAR,lbCamporiAAMAR);
        onMouseExited(camporiACeAM,lbCamporiACeAM);
        onMouseExited(novaDescoberta,lbNovaDescoberta);
        onMouseExited(vidaPlena,lbVidaPlena);
        onMouseExited(evangelismoComEsperanca,lbEvangelismoComEsperanca);
        
        //Busca
        onMouseExited(txBusca,btBuscar,btAbrirHino);
    }
    
    private ObservableList<Musica> findItems() {
        ObservableList<Musica> itensEncontrados = FXCollections.observableArrayList();
        for (Musica itens : musicas) {
            if (itens.getNomeMusica().toUpperCase().contains(txBusca.getText().toUpperCase()) || itens.getNomeCD().toUpperCase().contains(txBusca.getText().toUpperCase())) {
                itensEncontrados.add(itens);
            }
        }
        return itensEncontrados;
    }
}