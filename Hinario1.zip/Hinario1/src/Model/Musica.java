/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author Patrick
 */
public class Musica {
    private StringProperty musica;
    private StringProperty cd;
    private StringProperty caminho;

    public Musica(String musica, String cd, String caminho) {
        this.musica = new SimpleStringProperty(musica);
        this.cd = new SimpleStringProperty(cd);;
        this.caminho = new SimpleStringProperty(caminho);;
    }

    public Musica() {
        this.musica = new SimpleStringProperty("");;
        this.cd = new SimpleStringProperty("");;
        this.caminho = new SimpleStringProperty("");;
    }

    public StringProperty getMusica() {
        return musica;
    }

    public void setMusica(String musica) {
        this.musica = new SimpleStringProperty(musica);
    }

    public StringProperty getCd() {
        return cd;
    }

    public void setCd(String cd) {
        this.cd = new SimpleStringProperty(cd);
    }

    public StringProperty getCaminho() {
        return caminho;
    }

    public void setCaminho(String caminho) {
        this.caminho = new SimpleStringProperty(caminho);
    }
    
    
    public String getNomeMusica() {
        return musica.get();
    }

    public void setNomeMusica(String nome) {
        this.musica.set(nome);
    }

    public String getNomeCD() {
        return cd.get();
    }

    public void setNomeCD(String nomeCD) {
        this.cd.set(nomeCD);
    }

    public String getCaminhoHino() {
        return caminho.get();
    }

    public void setCaminhoHino(String Caminho) {
        this.caminho.set(Caminho);
    }
    
}
