/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Util;

import hinario.Hinario;
import javafx.animation.FadeTransition;
import javafx.animation.ScaleTransition;
import javafx.geometry.Side;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;

/**
 *
 * @author Patrick
 */
public abstract class Effect {
    public void louvorNaoEncontrado(){
        OptionPane o = new OptionPane(OptionPane.ERROR_MESSAGE,"","Louvor não encontrado");
    }
    
    public void runtimeExec(String e){
        try{
            //System.out.println("Antes : "+e);
            Runtime.getRuntime().exec(e);
        }catch(Exception j){
            //System.out.println("Depois :"+ e);
            louvorNaoEncontrado();
            //System.out.println("Erro : "+ j.getMessage());
        }
    }
    
    public void aumentaImagem(ImageView e){
        ScaleTransition transition = new ScaleTransition(
                Duration.millis(50), e);
                transition.setToX(1.05);
                transition.setToY(1.05);
                transition.play();
    }
    
    public void diminuiImagem(ImageView e){
        ScaleTransition transition = new ScaleTransition(
            Duration.millis(50), e);
            transition.setToX(1.0);
            transition.setToY(1.0);
            transition.play();
    }
    
    public void onMouseClicked(ImageView e,String diretorio){
        e.setOnMouseClicked((MouseEvent j)->{
            runtimeExec(diretorio);
        });
    }
    
    public void onMouseClicked(String diretorio){
        try{
            Runtime.getRuntime().exec(diretorio);
        }catch(Exception j){
            louvorNaoEncontrado();
        }
    }
    
   private void initAparece(Node e) {
        Duration d = new Duration(500);
        FadeTransition fadeTransition = new FadeTransition();
        fadeTransition.setFromValue(0);
        fadeTransition.setToValue(1);
        fadeTransition.setDuration(d);
        fadeTransition.setNode(e);
        fadeTransition.play();
    }
    
    private void initDesaparece(Node e) {
        Duration d = new Duration(500);
        FadeTransition fadeTransition = new FadeTransition();
        fadeTransition.setFromValue(1);
        fadeTransition.setToValue(0);
        fadeTransition.setDuration(d);
        fadeTransition.setNode(e);
        fadeTransition.play();
    } 
    public void labelNitida(Label l){
        l.setOpacity(1.0);
    }
    
    public void labelTransparente(Label l){
        l.setOpacity(0.1);
    }
    
    public void buscaInvisivel(TextField e,Button a,Button b){
        e.setOpacity(0.01);
        a.setOpacity(0.01);
        a.setOpacity(0.01);
    }
    
    public void buscaVisivel(TextField e,Button a,Button b){
        e.setOpacity(1.0);
        a.setOpacity(1.0);
        a.setOpacity(1.0);
    }
    
    
    public void onMouseEntered(ImageView e){
        e.setOnMouseEntered((MouseEvent j)->{
            aumentaImagem(e);
        });
    }
    
    public void onMouseEntered(ImageView e,Label l){
        e.setOnMouseEntered((MouseEvent j)->{
            labelNitida(l);
            aumentaImagem(e);
        });
    }
    
    
    public void onMouseEntered(TextField e,Button a,Button b){
        e.setOnMouseEntered((MouseEvent j)->{
            buscaVisivel(e,a,b);
            initAparece(e);
            initAparece(a);
            initAparece(b);
        });
        
        a.setOnMouseEntered((MouseEvent j)->{
            buscaVisivel(e,a,b);
            initAparece(e);
            initAparece(a);
            initAparece(b);
        });
        
        b.setOnMouseEntered((MouseEvent j)->{
            buscaVisivel(e,a,b);
            initAparece(e);
            initAparece(a);
            initAparece(b);
        });
    }
    
    public void onMouseExited(ImageView e){
        e.setOnMouseExited((MouseEvent k)->{
            diminuiImagem(e);
        });
    }
    
    public void onMouseExited(ImageView e,Label l){
        e.setOnMouseExited((MouseEvent k)->{
            labelTransparente(l);
            diminuiImagem(e);
        });
    }
    
    public void onMouseExited(TextField e,Button a,Button b){
        e.setOnMouseExited((MouseEvent j)->{
            buscaInvisivel(e,a,b);
            initDesaparece(e);
            initDesaparece(a);
            initDesaparece(b);
        });
        
        a.setOnMouseExited((MouseEvent j)->{
            buscaInvisivel(e,a,b);
            initDesaparece(e);
            initDesaparece(a);
            initDesaparece(b);
        });
        
        b.setOnMouseExited((MouseEvent j)->{
            buscaInvisivel(e,a,b);
            initDesaparece(e);
            initDesaparece(a);
            initDesaparece(b);
        });
    }
    
    public void tabPaneSide(ImageView b,TabPane e,int a){
        b.setOnMouseClicked((MouseEvent j)->{
            if(a == 1){
                    e.setSide(Side.TOP);
            }else if(a == 2){
                e.setSide(Side.BOTTOM);
            }else if(a == 3){
                e.setSide(Side.LEFT);
            }else if(a == 4){
                e.setSide(Side.RIGHT);
            }
        });
    }
    
    public void mouseClickedAumentaDiminui(ImageView a,ImageView b,ImageView c,ImageView d,ImageView e,AnchorPane k){
        a.setOnMouseClicked((MouseEvent f)->{
            if(Hinario.stage.isFullScreen()){
                a.setImage(new Image("/Image/Sistema/AumentaSecundario.png"));
                b.setImage(new Image("/Image/Sistema/AumentaSecundario.png"));
                c.setImage(new Image("/Image/Sistema/AumentaSecundario.png"));
                d.setImage(new Image("/Image/Sistema/AumentaSecundario.png"));
                e.setImage(new Image("/Image/Sistema/AumentaSecundario.png"));
                Hinario.stage.setFullScreen(false);
            }else{
                a.setImage(new Image("/Image/Sistema/DiminuiSecundario.png"));
                b.setImage(new Image("/Image/Sistema/DiminuiSecundario.png"));
                c.setImage(new Image("/Image/Sistema/DiminuiSecundario.png"));
                d.setImage(new Image("/Image/Sistema/DiminuiSecundario.png"));
                e.setImage(new Image("/Image/Sistema/DiminuiSecundario.png"));
                Hinario.stage.setFullScreen(true);
            }
        });
        
        k.setOnKeyPressed((KeyEvent l)->{
            if(l.getCode() == KeyCode.F11){
                a.setImage(new Image("/Image/Sistema/DiminuiSecundario.png"));
                b.setImage(new Image("/Image/Sistema/DiminuiSecundario.png"));
                c.setImage(new Image("/Image/Sistema/DiminuiSecundario.png"));
                d.setImage(new Image("/Image/Sistema/DiminuiSecundario.png"));
                e.setImage(new Image("/Image/Sistema/DiminuiSecundario.png"));
                Hinario.stage.setFullScreen(true);
            }else if(l.getCode() == KeyCode.ESCAPE){
                a.setImage(new Image("/Image/Sistema/AumentaSecundario.png"));
                b.setImage(new Image("/Image/Sistema/AumentaSecundario.png"));
                c.setImage(new Image("/Image/Sistema/AumentaSecundario.png"));
                d.setImage(new Image("/Image/Sistema/AumentaSecundario.png"));
                e.setImage(new Image("/Image/Sistema/AumentaSecundario.png"));
            }
        });
    }
    
}
