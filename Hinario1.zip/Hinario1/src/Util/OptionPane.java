/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Util;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 *
 * @author Patrick
 */
public class OptionPane extends Application {
    private AnchorPane pane;
    private ImageView img;
    private Button btOk;
    private Label lbMensagem;
    private String titulo1;
    private String mensagem;
    private String img1;
    private static Stage stage;
    public final static String ERROR_MESSAGE = "/Image/Sistema/Erro.png" ;
    public final static String ATENCAO_MESSAGE = "/Image/Sistema/Atencao.png";
    
    public OptionPane(String imagem,String titulo, String mensagem){
        this.img1 = imagem;
        this.titulo1 = titulo;
        this.mensagem = mensagem;
        try{    
            start(new Stage());
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    
    @Override
    public void start(Stage stage) throws Exception {
        initComponents();
        initLayout();
        initAction();
        stage.getIcons().add(new Image(getClass().getResourceAsStream(img1)));
        stage.setScene(new Scene(pane));
        stage.setTitle(titulo1);
        stage.setResizable(false);
        stage.show();
        
        OptionPane.stage = stage;
    }
    
    public void initComponents(){
        pane = new AnchorPane();
        pane.setPrefSize(300, 70);
        
        img = new ImageView(new Image(img1));
        
        btOk = new Button("OK");
        
        lbMensagem = new Label();
        lbMensagem.setText(mensagem);
        
        pane.getChildren().addAll(img,btOk,lbMensagem);
    }
    
    public void initLayout(){
        img.setLayoutX(20);
        img.setLayoutY(10);
        img.setFitHeight(40);
        img.setFitWidth(40);
        
        btOk.setLayoutX(120);
        btOk.setLayoutY(65);
        btOk.setMinWidth(80);
        
        lbMensagem.setLayoutX(80);
        lbMensagem.setLayoutY(20);
        lbMensagem.setMaxHeight(10);
        lbMensagem.setMaxWidth(300);
        lbMensagem.setFont(new Font("Arial",18));
    }
    
    public void initAction(){
        btOk.setOnMouseClicked((MouseEvent e)->{
            fecha();
        });
        
        btOk.setOnKeyPressed((KeyEvent e)->{
            if(e.getCode() == KeyCode.ENTER){
                fecha();
            }
        });        
    }
    
    
    public Stage getStage(){
        return stage;
    }
    
    public void fecha(){
        OptionPane.stage.close();
    }
}