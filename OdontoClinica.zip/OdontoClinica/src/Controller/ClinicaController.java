/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent  ;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import jdbc.ConsultaDAO;
import jdbc.EstoqueDAO;
import static jdbc.EstoqueDAO.insereEstoque;
import jdbc.PacienteDAO;
import model.Consulta;
import model.Estoque;
import model.Paciente;

/**
 * FXML Controller class
 *
 * @author ThaiKarys
 */
public class ClinicaController implements Initializable {

    //tableviews
    @FXML private TableView <Consulta> consul;
    @FXML private TableView <Estoque> estoqueps;
    @FXML private TableView <Paciente> paci;
    
    //paciente
    @FXML private TableColumn <Paciente, String> sexotb;
    @FXML private TableColumn <Paciente, String> nome;
    @FXML private TableColumn <Paciente, String> cpf;
    @FXML private TableColumn <Paciente, String> city;
    @FXML private TableColumn <Paciente, String> bairro;
    @FXML private TableColumn <Paciente, String> rua;
    @FXML private TableColumn <Paciente, Integer> num;
    @FXML private TableColumn <Paciente, String> tel;
    @FXML private TextField ddpesquisap;
    
    //consulta
    @FXML private TableColumn <Consulta, Integer> idc;
    @FXML private TableColumn <Consulta, Integer> idp;
    @FXML private TableColumn <Consulta, String> pacm;
    @FXML private TableColumn <Consulta, String> data;
    @FXML private TableColumn <Consulta, String> hora;
    @FXML private TableColumn <Consulta, Double> valor;
    @FXML private TextField ddpesquisac;
    @FXML private ImageView imagcon;
    @FXML private Button attconsulta;
    
    //estoque
    @FXML private TableColumn <Estoque, String> nomess;
    @FXML private TableColumn <Estoque, Integer> codigo;
    @FXML private TableColumn <Estoque, String> marc;
    @FXML private TableColumn <Estoque, Integer> quantia;
    
    //tabs
    @FXML private TabPane clinica;
    @FXML private Tab ccc;
    @FXML private Tab cliente;
    @FXML private Tab estoque; 
    
    //botões
    @FXML private Button btcadpaciente; 
    @FXML private Button btcadconsulta;
    @FXML private Button btsair;
    @FXML private Button btsai; 
    @FXML private Button expac;
    @FXML private Button btexcluies;
    @FXML private Button btsaires;
    @FXML private Button btcades; 
    @FXML private Button btlimpae;
    @FXML private Button btexcluic;
    
    @FXML private Label nomepec; 
    @FXML private Label qntd;
    @FXML private Label cod;
    @FXML private Label marca;

    //estoque
    @FXML private TextField ddnome;
    @FXML private TextField ddpesquisae; 
    @FXML private TextField ddqntd;
    @FXML private TextField ddcod;
    @FXML private TextField ddmarca; 
    @FXML private Button btpesquisa; 
    @FXML private Button btexcluiest;
    
    @FXML private ImageView imgestoque;
    
    private static Consulta opcaoc;
    private static Paciente opcaop;
    private static Estoque opcaoe;
    
    private ObservableList <Estoque> estoques;
    private ObservableList <Consulta> consultas;
    private ObservableList <Paciente> pacientes;
    
  
    @FXML 
    public void LimpaCamposE(ActionEvent event){
        ddnome.setText("");
        ddcod.setText("");
        ddqntd.setText(""); 
        ddmarca.setText("");   
    }
    
    @FXML 
    private void deletaPaciente (ActionEvent event){
        if(ClinicaController.opcaop != null){
            PacienteDAO dao = new PacienteDAO ();
            dao.deletaPaciente(ClinicaController.opcaop); 
            
          //  Alert del=new Alert(Alert.AlertType.CONFIRMATION);
             //   del.setHeaderText("Paciente deletado com sucesso!");
            //    del.showAndWait();
                VisualizaPaciente();
            }else{
              //  Alert del=new Alert(Alert.AlertType.ERROR);
               // del.setHeaderText("Por favor, selecione um Paciente!");
                //del.showAndWait();
            }
            
        }
    
     @FXML 
    private void deletaConsulta (ActionEvent event){
        if(ClinicaController.opcaoc != null){
            ConsultaDAO daoc = new ConsultaDAO ();
            daoc.deletaConsulta(ClinicaController.opcaoc); 
            
         //  Alert dele=new Alert(Alert.AlertType.CONFIRMATION);
              //  dele.setHeaderText("Consulta deletada com sucesso!");
              //  dele.showAndWait();
                MostraConsulta();
            }else{
              //  Alert dele=new Alert(Alert.AlertType.ERROR);
              //  dele.setHeaderText("Por favor, selecione uma Consulta!");
               // dele.showAndWait();
            }
            
        }
    
    @FXML 
    private void deletaEstoque (ActionEvent event){
        if(ClinicaController.opcaoe != null){
            EstoqueDAO daoe = new EstoqueDAO();
            daoe.deletaEstoque(ClinicaController.opcaoe);
            

            MostraPeca();
        }else {
         //   Alert deletaes = new Alert(Alert.AlertType.ERROR);
          //    deletaes.setHeaderText("Por favor, selecione um Produto!");
           //   deletaes.showAndWait();
        }
    }
    
    //Sair Estoque
     @FXML
    public void SairStages(ActionEvent event){
       Stage stage = (Stage) btsaires.getScene().getWindow();
       stage.close(); 
    }
    
    //Sair Paciente
    @FXML
    public void SairStageCadp(ActionEvent event){
       Stage stage = (Stage) btsair.getScene().getWindow();
       stage.close(); 
    }
    
    //Sair Consulta
    @FXML
    public void SairStageCadc(ActionEvent event){
       Stage stage = (Stage) btsai.getScene().getWindow();
       stage.close(); 
       
    }
    
    @FXML
    public void CadPacientes() {
        PacientesController opens= new PacientesController();
        try {
            opens.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(PacientesController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @FXML
    public void CadConsultas() {
        ConsultasController opens= new ConsultasController();
        try {
            opens.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(ConsultasController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @FXML
    private void CadEstoque(ActionEvent event) {
        if(ddnome.getText().equals("") || ddcod.getText().equals("")||
            ddmarca.getText().equals("")|| ddqntd.getText().equals("")){
           
          // Alert c = new Alert(Alert.AlertType.WARNING);
               // c.setTitle("ATENÇÃO");
              //  c.setHeaderText("Campos vazios");
               // c.setContentText("Por favor, não deixe campos vazios");
               // c.showAndWait();
                
        }else{
           try{
               Estoque es = new Estoque (); 
               es.setNome(ddnome.getText());
               es.setCodigo(Integer.parseInt(ddcod.getText()));
               es.setMarca(ddmarca.getText());
               es.setQuantidade(Integer.parseInt(ddqntd.getText()));
               insereEstoque(es);
               MostraPeca();
               
            //   Alert alerta = new Alert(Alert.AlertType.INFORMATION);
               //     alerta.setTitle("VERIFICAÇÃO DE CADASTRO");
                 //   alerta.setHeaderText("Campos digitados corretamente");
                  //  alerta.setContentText("OK, Cadastro realizado");
                   // alerta.showAndWait();
               
           }catch(Exception e){
               System.out.println("erro ao cadastrar: " + e.getMessage());
                
           }
       }

    }
      

    @FXML
    public void MostraPeca (){
        nomess.setCellValueFactory(new PropertyValueFactory("nome"));
        codigo.setCellValueFactory(new PropertyValueFactory("codigo"));
        marc.setCellValueFactory(new PropertyValueFactory("marca"));
        quantia.setCellValueFactory(new PropertyValueFactory("quantidade"));
        EstoqueDAO dao = new EstoqueDAO(); 
        estoques = dao.getEstoque();
        estoqueps.setItems(estoques);  
        
    }
    
    @FXML
    public void VisualizaPaciente(){
        
        idp.setCellValueFactory(new PropertyValueFactory("idp"));
        nome.setCellValueFactory(new PropertyValueFactory("nome"));
        cpf.setCellValueFactory(new PropertyValueFactory("cpf"));
        city.setCellValueFactory(new PropertyValueFactory("cidade"));
        bairro.setCellValueFactory(new PropertyValueFactory("bairro"));
        rua.setCellValueFactory(new PropertyValueFactory("rua"));
        tel.setCellValueFactory(new PropertyValueFactory("telefone"));
        num.setCellValueFactory(new PropertyValueFactory("num"));
        sexotb.setCellValueFactory(new PropertyValueFactory("sexo"));
        PacienteDAO daop = new PacienteDAO(); 
        pacientes = daop.getPacientes();
        paci.setItems(pacientes); 
        
            
    }
    
    public void MostraConsulta (){
        idc.setCellValueFactory(new PropertyValueFactory("idc")); 
        pacm.setCellValueFactory(new PropertyValueFactory("paciente"));
        data.setCellValueFactory(c-> new ReadOnlyStringWrapper(c.getValue().getDataTable()));
        hora.setCellValueFactory(new PropertyValueFactory("hora"));
        valor.setCellValueFactory(new PropertyValueFactory("valor"));
        ConsultaDAO daoc = new ConsultaDAO(); 
        consultas = daoc.getConsulta();
        consul.setItems(consultas); 
        
    }

    public void pesquisaEstoque(){
      ObservableList<Estoque> es = FXCollections.observableArrayList();
        for(int x = 0; x < estoques.size(); x++){
            if (estoques.get(x).getNome().toUpperCase().contains(ddpesquisae.getText().toUpperCase())){
                es.add(estoques.get(x));
           }
        }
      estoqueps.setItems(es);
    }
    
    public void pesquisaConsulta(){
      ObservableList<Consulta> con = FXCollections.observableArrayList();
        for(int c = 0; c < consultas.size(); c++){
            if (consultas.get(c).getPaciente().toUpperCase().contains(ddpesquisac.getText().toUpperCase())){
                con.add(consultas.get(c));
           }
        }
        consul.setItems(con);
    }
    
    public void pesquisaPaciente(){
      ObservableList<Paciente> pac = FXCollections.observableArrayList();
        for(int p = 0; p < pacientes.size(); p++){
            if (pacientes.get(p).getNome().toUpperCase().contains(ddpesquisap.getText().toUpperCase())){
                pac.add(pacientes.get(p));
           }
        }
        paci.setItems(pac);
    }
    

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        MostraPeca();
        VisualizaPaciente();
        MostraConsulta();
           
        
         paci.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {

             @Override
             public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                 if(newValue !=null){
                    ClinicaController.opcaop = (Paciente) newValue;
                    
                 }else{
                     ClinicaController.opcaop = null;
                     
                 }
             }
         });
          consul.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
         @Override 
            public void changed (ObservableValue obeservable, Object oldValue, Object newValue){
                if(newValue !=null){
                ClinicaController.opcaoc = (Consulta) newValue;
              
                
            }else{
                ClinicaController.opcaoc = null; 
             }
            }
        });
          
          estoqueps.getSelectionModel().selectedItemProperty().addListener(new ChangeListener(){
              @Override
              public void changed (ObservableValue observable, Object oldValue, Object newValue){
                  if(newValue != null){
                      ClinicaController.opcaoe = (Estoque) newValue; 
                      
                  }else {
                      ClinicaController.opcaoe = null; 
                  }
              }
          });
          
          //Quando o mouse estiver na tabela vai efetuar o método de atualizar tabela
        paci.setOnMouseEntered((MouseEvent e)->{
              atualizaTabelaPaciente();  

          });
          
        ddpesquisae.setOnKeyReleased((KeyEvent e)->{
            pesquisaEstoque();    
        });  
        
        ddpesquisac.setOnKeyReleased((KeyEvent c)->{
            pesquisaConsulta();    
        }); 
        
        ddpesquisap.setOnKeyReleased((KeyEvent p)->{
            pesquisaPaciente();    
        }); 
          
    }

    //Atualiza a tabela 
    
    private void atualizaTabelaPaciente(){
        PacienteDAO daop = new PacienteDAO(); 
        ObservableList<Paciente> pacientes = daop.getPacientes();
        paci.setItems(pacientes); 
    }
    
    public void atualizaTabelaConsulta(){
        ConsultaDAO daoc = new ConsultaDAO ();
        ObservableList<Consulta> consultas = daoc.getConsulta();
        consul.setItems(consultas);
    }
    
  
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("Clinica.fxml"));
        Scene scene = new Scene(root);
        stage.setTitle("Visualizar Clinica");
        stage.setResizable(false); 
        stage.setScene(scene);
        stage.show();
    }
   
}
    
