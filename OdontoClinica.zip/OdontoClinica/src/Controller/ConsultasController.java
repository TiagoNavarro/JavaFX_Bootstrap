/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
//import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import jdbc.ConsultaDAO;
import model.Consulta;
import model.Paciente;

/**
 * FXML Controller class
 *
 * @author ThaiKarys
 */
public class ConsultasController implements Initializable {
    
    @FXML private TextField dpacm;
    @FXML private DatePicker ddata;
    @FXML private TextField dhora;
    @FXML private TextField dvalor;
    @FXML private TextField idConsulta;
    
    @FXML private Label pacm;
    @FXML private Label id;
    @FXML private Label data;
    @FXML private Label hora;
    @FXML private Label valor;
    @FXML private Label deff; 
    @FXML private ImageView ima; 
    
    @FXML private Button btcadc;
    @FXML private Button btex;
    @FXML private Button btlimpa; 
    
    
    ConsultaDAO cDao = new ConsultaDAO();
    
    @FXML 
    public void LimpaCampos(ActionEvent event){
        dpacm.setText("");
        dhora.setText("");
        dvalor.setText("");
        ddata.setValue(null);
    }
   
    
    @FXML
    private void CadConsulta(ActionEvent event) {
        if(dpacm.getText().equals("") || ddata.getValue().equals("")||
            dhora.getText().equals("")|| dvalor.getText().equals("")){
           
         //  Alert c = new Alert(Alert.AlertType.WARNING);
             //   c.setTitle("ATENÇÃO");
              //  c.setHeaderText("Campos vazios");
               // c.setContentText("Por favor, não deixe campos vazios");
                //c.showAndWait();
                
        }else{
           try{
               
               Consulta con = new Consulta (); 
               con.setPaciente(dpacm.getText());
               con.setData(ddata.getValue());
               con.setHora(dhora.getText());
               con.setValor(Double.parseDouble(dvalor.getText())); //converte

               cDao.insereConsulta(con); 
               
               
             //  Alert alertar = new Alert(Alert.AlertType.INFORMATION);
                  //  alertar.setTitle("VERIFICAÇÃO DE CADASTRO");
                 //   alertar.setHeaderText("CAMPOS DIGITADOS CORRETAMENTE");
                    //alertar.setContentText("SEU CADASTRO FOI REALIZADO COM EXITO!");
                  //  alertar.showAndWait();
               
           }catch(Exception e){
               System.out.println("Erro ao cadastrar uma consulta: " + e.getMessage());
                
           }
       }
    }
    
    
    @FXML
    public void SairStageCadp(ActionEvent event){
       Stage stage = (Stage) btex.getScene().getWindow();
       stage.close(); 
       
    }  
    
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("Consultas.fxml"));
        
        Scene scene = new Scene(root);
        stage.setTitle("Cadastrar Consultas");
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
