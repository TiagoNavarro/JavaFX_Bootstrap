/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author ThaiKarys
 */
public class LoginController implements Initializable {

     private static Object stage;
     
    @FXML private TabPane Table1;
    @FXML private Tab tbfuncionario;
    @FXML private Tab tbdentista;
    
    @FXML private Label login;
    @FXML private Label senha;
    @FXML private TextField digitalogin;
    @FXML private TextField digitasenha;
    
    @FXML private Label dlogind;
    @FXML private Label dsenhad;
    @FXML private TextField ddigitalogin;
    @FXML private TextField ddigitasenha;
    
    @FXML private Button btentrar;
    @FXML private Button btsair;
    @FXML private Button btentrar1;
    @FXML private Button btsair1;
    @FXML private ImageView clini;
    @FXML private ImageView imgorto;
    
    public static Stage StageCad;
    @FXML private AnchorPane ari; 
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        
    }   

    
    public void EntraClinica() {
        btentrar.setOnMouseClicked((MouseEvent ) -> {
        if (digitalogin.getText().equals("admin") && digitasenha.getText().equals("admin")) {
                try {
                ClinicaController abre = new ClinicaController();
                abre.start(new Stage());
		} catch (Exception ex) {
                Logger.getLogger(ClinicaController.class.getName()).log(Level.SEVERE, null, ex);
		}
                    } else {
		JOptionPane.showMessageDialog(null, "Login ou senha inválidos, tente novamente", "Erro", JOptionPane.ERROR_MESSAGE);
				}
        });
    
    
}
    
    public void EntraClinicaD() {
        btentrar1.setOnMouseClicked((MouseEvent ) -> {
        if (ddigitalogin.getText().equals("dentista") && ddigitasenha.getText().equals("dentista")) {
                try {
                PgDentistaController abre = new PgDentistaController();
                abre.start(new Stage());
		} catch (Exception ex) {
                Logger.getLogger(PgDentistaController.class.getName()).log(Level.SEVERE, null, ex);
		}
                    } else {
		JOptionPane.showMessageDialog(null, "Login ou senha inválidos, tente novamente", "Erro", JOptionPane.ERROR_MESSAGE);
				}
        });
    
    
}
     
   
    @FXML
    public void SairStageCad(ActionEvent event){
        btsair.setOnMouseClicked((MouseEvent ) ->{
        Platform.exit(); 
        
    });
    }
    
    @FXML
    public void Fecha(ActionEvent event){
        btsair1.setOnMouseClicked((MouseEvent ) ->{
        Platform.exit(); 
        
    });
    }
}

  
   
