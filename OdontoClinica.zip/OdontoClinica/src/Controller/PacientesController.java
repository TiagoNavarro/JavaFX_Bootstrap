/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import static java.lang.Integer.parseInt;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
//import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import static jdbc.PacienteDAO.inserePaciente;
import model.Paciente;
/**
 * FXML Controller class
 *
 * @author ThaiKarys
 */
public class PacientesController implements Initializable {

   private ObservableList<String> tpSexo = FXCollections.observableArrayList ("FEMININO","MASCULINO"); 

    @FXML private TextField dnome;
    @FXML private TextField dcpf;
    @FXML private TextField dcity;
    @FXML private TextField dbairro;
    @FXML private TextField drua;
    @FXML private TextField dnum;
    @FXML private TextField dtel;
    @FXML private TextField idPac;
    
    @FXML private Label id;
    @FXML private Label nome;
    @FXML private Label sexo;
    @FXML private Label def;
    @FXML private Label cpf;
    @FXML private Label city;
    @FXML private Label bairro;
    @FXML private Label rua;
    @FXML private Label num;
    @FXML private Label tel;
    
    @FXML private Button btcadp;
    @FXML private Button btexit;
    @FXML private Button btlimpa; 
    
    @FXML private ComboBox tipos; 
    
    @FXML private ImageView im; 
    
   public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("Pacientes.fxml"));
        
        Scene scene = new Scene(root);
        stage.setTitle("Cadastrar Pacientes");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
   
   @FXML 
    private void CadPaciente(ActionEvent event){
        if(dnome.getText().equals("") || dcpf.getText().equals("") || dcity.getText().equals("") ||
            dbairro.getText().equals("") || drua.getText().equals("") || dnum.getText().equals("") || 
            dtel.getText().equals("") || tipos.getValue() == null){
            
           // Alert al = new Alert (Alert.AlertType.WARNING);
          //  al.setTitle("Atenção!");
          //  al.setHeaderText("Os Campos Estão Vazios");
           // al.setContentText("Por favor, preencha os campos!");
           // al.showAndWait(); 
            
        }else {
            try {
                
                
                Paciente pac = new Paciente ();
                pac.setNome(dnome.getText());
                pac.setCpf(dcpf.getText()); 
                pac.setCidade(dcity.getText());
                pac.setBairro(dbairro.getText());
                pac.setRua(drua.getText());
                pac.setNum(parseInt(dnum.getText())); 
                pac.setTelefone(dtel.getText());
                pac.setSexo(tipos.getValue().toString());
                inserePaciente(pac);
                
             //  Alert mensagem = new Alert(Alert.AlertType.INFORMATION);
               //     mensagem.setTitle("VERIFICAÇÃO DE CADASTRO");
                //    mensagem.setContentText("OK, Cadastro realizado");
                //    mensagem.showAndWait();
                    
                 //   ClinicaController a = new ClinicaController();
                   // a.VisualizaPaciente();
           
            }catch (Exception e){
                System.out.println("Erro ao Cadastrar um paciente: " + e.getMessage());
            }
        }
    }
   
   @FXML 
    public void LimpaCamposP(ActionEvent event){
        dnome.setText("");
        dcpf.setText("");
        dcity.setText(""); 
        dbairro.setText("");
        drua.setText("");
        dnum.setText("");
        dtel.setText(""); 
        tipos.setValue("");
    }
   
   @FXML
    public void SairStageCadp(ActionEvent event){
       Stage stage = (Stage) btexit.getScene().getWindow();
       stage.close(); 
    }
    

   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       tipos.setItems(tpSexo);
       
       
       
    } 
    
    
    
}
