/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import jdbc.ConsultaDAO;
import jdbc.EstoqueDAO;
import static jdbc.EstoqueDAO.insereEstoque;
import static jdbc.OrcamentoDAO.enviaOrcamento;
import model.Consulta;
import model.Estoque;
import model.Orcamento;

/**
 * FXML Controller class
 *
 * @author Aluno
 */
public class PgDentistaController implements Initializable {
  
    @FXML private TableView <Consulta> consu;
    @FXML private TableView <Estoque> estoqueID;
   
    @FXML private TableColumn <Consulta, String> spacm;
    @FXML private TableColumn <Consulta, String> sdata;
    @FXML private TableColumn <Consulta, String> shora;
    @FXML private TableColumn <Consulta, Double> svalor;
    @FXML private TableColumn <Consulta, Integer> idcdentista; 
    
    @FXML private TabPane clinica;
    @FXML private Tab cons;
    @FXML private Tab estoque; 
    @FXML private Tab taborc; 
    
    @FXML private Button btcadconsulta;
    @FXML private Button btssair;
    @FXML private Button btexcluie;
    @FXML private Button btexcluic;
   
    @FXML private Label nomepec; 
    @FXML private Label qntd;
    @FXML private Label cod;
    @FXML private Label marca;
    
    @FXML private Button btsaires;
    @FXML private Button btcades;  
    
    //Estoque
    @FXML private TextField pesqest; 
    @FXML private TextField ddnome; 
    @FXML private TextField ddqntd;
    @FXML private TextField ddcod;
    @FXML private TextField ddmarca;
    @FXML private ImageView imgest;
    @FXML private Button btlimpae; 
    
    @FXML private TableColumn<Estoque, String> nomess;
    @FXML private TableColumn<Estoque, String> codigo;
    @FXML private TableColumn<Estoque, String>  marc;
    @FXML private TableColumn<Estoque, String> quantia;  
    
    //Consulta
    @FXML private Label ppacien; 
    @FXML private Label sorcvalor;
    @FXML private Label sdescricao;
    @FXML private Label stelefone;
    @FXML private Label sorcdata;
    @FXML private Label sorcamento;
    @FXML private Label estoquelb;
    @FXML private TextField dtpesqcon;
    @FXML private ImageView imgcon;
    
    //Orcamento
    @FXML private TextField dpaciente; 
    @FXML private TextField dvalor;
    @FXML private TextArea ddescricao;
    @FXML private TextField dtelefone;
    @FXML private DatePicker ddata;
    @FXML private ImageView imgorc;

    @FXML private Button btlimpao; 
    @FXML private Button envia;
    @FXML private Button sair;
    
    private static Consulta opcaoco;
    private static Estoque opcaoes; 
    
    private ObservableList <Consulta> consultas; 
    private ObservableList <Estoque> estoques; 
    
    
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("PgDentista.fxml"));
        Scene scene = new Scene(root);
        stage.setTitle("Tela de Acesso");
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML 
    public void LimpaCamposO(ActionEvent event){
        dpaciente.setText("");
        dvalor.setText("");
        ddescricao.setText(""); 
        dtelefone.setText("");
  
    }
    
    @FXML 
    public void LimpaCamposE(ActionEvent event){
        ddnome.setText("");
        ddcod.setText("");
        ddqntd.setText(""); 
        ddmarca.setText("");
    
    }
    
    @FXML
    public void CadastraConsultas() {
        btcadconsulta.setOnMouseClicked((MouseEvent ) -> {
            ConsultasController opens= new ConsultasController();
            try {
                opens.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(ConsultasController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

    }
    
    @FXML 
    private void deletaConsulta (ActionEvent event){
        if(PgDentistaController.opcaoco != null){
            ConsultaDAO daoc = new ConsultaDAO ();
            daoc.deletaConsulta(PgDentistaController.opcaoco); 
            
          //  Alert dele=new Alert(Alert.AlertType.CONFIRMATION);
           //     dele.setHeaderText("Consulta deletada com sucesso!");
              //  dele.showAndWait();
                MostraConsulta();
            }else{
              //  Alert dele=new Alert(Alert.AlertType.ERROR);
              //  dele.setHeaderText("Por favor, selecione uma Consulta!");
               // dele.showAndWait();
            }
            
        }
    
    @FXML 
    private void deletaEstoque (ActionEvent event){
        if(PgDentistaController.opcaoes != null){
            EstoqueDAO daoes = new EstoqueDAO();
            daoes.deletaEstoque(PgDentistaController.opcaoes);
            
           // Alert deletaes = new Alert (Alert.AlertType.CONFIRMATION);
           // deletaes.setHeaderText("Produto deletado com sucesso!");
            //deletaes.showAndWait();
            MostraPeca();
            
        }else {
          //  Alert deletaes = new Alert(Alert.AlertType.ERROR);
            //  deletaes.setHeaderText("Por favor, selecione um Produto!");
            //  deletaes.showAndWait();
        }
    }
    
    @FXML 
    private void CadOrcamento (ActionEvent event){
        if (dpaciente.getText().equals("") || 
          dvalor.getText().equals("") || 
          dtelefone.getText().equals("") || 
           ddata.getValue().equals("") || ddescricao.getText().equals("")){ 
            
          //  Alert alertorc = new Alert(Alert.AlertType.WARNING);
           //     alertorc.setTitle("Atenção!!");
             //   alertorc.setHeaderText("Seus Campos estão vazios");
             //   alertorc.setContentText("Por favor, preencha-os. ");
              //  alertorc.showAndWait(); 
        }else {
            try{
                 Orcamento orcamento = new Orcamento ();
                 orcamento.setNomep(dpaciente.getText());
                 orcamento.setValor(Double.parseDouble(dvalor.getText()));
                 orcamento.setTelefoneo(dtelefone.getText());
                 orcamento.setDatao(ddata.getValue());
                 orcamento.setDescricao(ddescricao.getText());
                 enviaOrcamento(orcamento);
                 
                // Alert mensagem = new Alert(Alert.AlertType.INFORMATION);
                //    mensagem.setTitle("VERIFICAÇÃO DE ENVIO");
                  //  mensagem.setContentText("OK, envio realizado");
                  //  mensagem.showAndWait();
                 
                
            }catch (Exception e){
                System.out.println("Erro ao Enviar: " + e.getMessage());
            }
        } 
 
    }
    
    @FXML
    private void CadEstoque(ActionEvent event) {
        if(ddnome.getText().equals("") || ddcod.getText().equals("")|| ddmarca.getText().equals("")|| ddqntd.getText().equals("")){
           
        //   Alert c = new Alert(Alert.AlertType.WARNING);
            //   c.setTitle("ATENÇÃO");
            //    c.setHeaderText("Campos vazios");
              //  c.setContentText("Por favor, não deixe campos vazios");
              //  c.showAndWait();
                
        }else{
           try{
               
               Estoque es = new Estoque (); 
               es.setNome(ddnome.getText());
               es.setCodigo(Integer.parseInt(ddcod.getText()));
               es.setMarca(ddmarca.getText());
               es.setQuantidade(Integer.parseInt(ddqntd.getText()));
               insereEstoque(es);  
               MostraPeca();
               
              // Alert alerta = new Alert(Alert.AlertType.INFORMATION);
                //    alerta.setTitle("VERIFICAÇÃO DE CADASTRO");
                 //   alerta.setHeaderText("Campos digitados corretamente");
               //     alerta.setContentText("OK, Cadastro realizado");
                 //   alerta.showAndWait();
               
           }catch(Exception e){
               System.out.println("erro ao cadastrar: " + e.getMessage());
                
           }
       }
    }
    
    public void MostraPeca (){
        nomess.setCellValueFactory(new PropertyValueFactory("nome"));
        codigo.setCellValueFactory(new PropertyValueFactory("codigo"));
        marc.setCellValueFactory(new PropertyValueFactory("marca"));
        quantia.setCellValueFactory(new PropertyValueFactory("quantidade"));
        EstoqueDAO dao = new EstoqueDAO(); 
        estoques = dao.getEstoque();
        estoqueID.setItems(estoques); 
        
        
    }
    
    public void MostraConsulta (){
        idcdentista.setCellValueFactory(new PropertyValueFactory("idc"));
        spacm.setCellValueFactory(new PropertyValueFactory("paciente"));
        sdata.setCellValueFactory(c-> new ReadOnlyStringWrapper(c.getValue().getDataTable()));
        shora.setCellValueFactory(new PropertyValueFactory("hora"));
        svalor.setCellValueFactory(new PropertyValueFactory("valor"));
        ConsultaDAO daoc = new ConsultaDAO(); 
        consultas = daoc.getConsulta();
        consu.setItems(consultas); 
        
        
    }
    
    
    @FXML
    public void SairEstoque(ActionEvent event){
       Stage stage = (Stage) btsaires.getScene().getWindow();
       stage.close(); 
    }
    
    @FXML
    public void SairOrcamento(ActionEvent event){
       Stage stage = (Stage) sair.getScene().getWindow();
       stage.close(); 
    }
    
    @FXML
    public void SairCad(ActionEvent event){
       Stage stage = (Stage) btssair.getScene().getWindow();
       stage.close(); 
    }
    
    public void atualizaTabelaConsulta (){
        ConsultaDAO daoc = new ConsultaDAO ();
        ObservableList<Consulta> consulta = daoc.getConsulta();
        consu.setItems(consulta);
    }    
    
    public void pesquisaConsulta (){
        ObservableList<Consulta> con = FXCollections.observableArrayList();
        for(int c = 0; c < consultas.size(); c++){
            if (consultas.get(c).getPaciente().toUpperCase().contains(dtpesqcon.getText().toUpperCase())){
                con.add(consultas.get(c));
           }
        }
        consu.setItems(con);
    }
    public void pesquisaEstoque(){
        ObservableList <Estoque> es = FXCollections.observableArrayList();
        for(int e = 0; e < estoques.size(); e++){
            if(estoques.get(e).getNome().toUpperCase().contains(pesqest.getText().toUpperCase())){
                es.add(estoques.get(e));
            }
        }
        estoqueID.setItems(es);
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       MostraPeca();
       MostraConsulta();
       
       consu.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
         @Override 
            public void changed (ObservableValue obeservable, Object oldValue, Object newValue){
                if(newValue !=null){
                PgDentistaController.opcaoco = (Consulta) newValue;
              
                
            }else{
                PgDentistaController.opcaoco = null; 
             }
            }
        });
       
       estoqueID.getSelectionModel().selectedItemProperty().addListener(new ChangeListener(){
              @Override
              public void changed (ObservableValue observable, Object oldValue, Object newValue){
                  if(newValue != null){
                      PgDentistaController.opcaoes = (Estoque) newValue; 
                      
                  }else {
                      PgDentistaController.opcaoes = null; 
                  }
              }
          });
       
       consu.setOnMouseClicked((MouseEvent c)->{
           atualizaTabelaConsulta();
       });
       
       dtpesqcon.setOnKeyReleased((KeyEvent p)->{
           pesquisaConsulta();
       });
       
       pesqest.setOnKeyReleased((KeyEvent e) ->{
           pesquisaEstoque(); 
       });       
    }    


    
}
