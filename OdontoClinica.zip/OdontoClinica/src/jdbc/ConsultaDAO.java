/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Consulta;

/**
 *
 * @author Aluno
 */
public class ConsultaDAO {
    static Connection c;
    
    public ConsultaDAO(){
        ConsultaDAO.c = ConnectionFactory.getConnection(); 
    }
    
    
    public static void insereConsulta (Consulta con){
        Connection c = ConnectionFactory.getConnection();
        String sql = "INSERT INTO consulta (paciente, datac, hora, valor)"
                + "VALUES (?, ?, ?, ?)"; 
         
        //converte
        Date data = Date.valueOf(con.getData());
        
        try {
            
         PreparedStatement  stmt = c.prepareStatement(sql);
           stmt.setString(1, con.getPaciente());
           stmt.setDate(2, data);
           stmt.setString(3, con.getHora());
           stmt.setDouble(4, con.getValor()); 
           stmt.execute();
           stmt.close();
           
        }catch (SQLException e) {
            e.printStackTrace();
            
        }      
    }
  
    public void deletaConsulta(Consulta con){
       String sql = "DELETE FROM consulta WHERE idc=?";
        try{
           PreparedStatement stmt = c.prepareStatement(sql);
           stmt.setInt(1, con.getIdc());
           stmt.execute();
           stmt.close();
       
        }catch (SQLException e) {
            e.printStackTrace(); 
        }
        
   }

        public ObservableList<Consulta> getConsulta(){
            Connection c = ConnectionFactory.getConnection();
        try{
            ObservableList<Consulta> consultas = FXCollections.observableArrayList();
            PreparedStatement stmt = this.c.prepareStatement("SELECT * FROM consulta");
            ResultSet result = stmt.executeQuery();
            
            while(result.next()){
                Consulta cons = new Consulta();
                cons.setPaciente(result.getString("paciente"));
                Date dt = result.getDate("datac");
                cons.setData(dt.toLocalDate());
                cons.setHora(result.getString("hora"));
                cons.setValor(result.getDouble("valor"));
                cons.setIdc(result.getInt("idc"));
                consultas.add(cons);
            }

            stmt.executeQuery();
            result.close();
            stmt.close();
            return consultas;
           
        }catch(SQLException e){
                throw new RuntimeException(e);
        }
    }
    
        
    private static void fechaConexao(){
        try{
            c.close();
            
        }catch (SQLException p){
            System.out.println(p.getMessage()); 
        }
    }
}




