/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Estoque;

/**
 *
 * @author Aluno
 */
public class EstoqueDAO {
    static Connection e;
    
    public EstoqueDAO(){
        EstoqueDAO.e = ConnectionFactory.getConnection(); 
    }
    
    public static void insereEstoque (Estoque es){
        Connection e = ConnectionFactory.getConnection(); 
        String sql = "INSERT INTO estoque (nome, codigo, marca, quantidade) "
                +"VALUES (?, ?, ?, ?);";
        
    try{ 
        PreparedStatement stt = e.prepareStatement (sql);
        stt.setString(1, es.getNome());
        stt.setInt(2, es.getCodigo());
        stt.setString(3, es.getMarca());
        stt.setInt(4, es.getQuantidade());
        stt.execute();
        stt.close();
        
        
    }catch (SQLException m){
        System.out.println(m.getMessage());
}
    
    }
    
    
    public void deletaEstoque (Estoque es){
        String sql = "DELETE FROM estoque WHERE codigo=?";
        try{
           PreparedStatement stt = e.prepareStatement(sql);
           stt.setInt(1, es.getCodigo());
           stt.execute();
           stt.close();
       
        }catch (SQLException e) {
            e.printStackTrace(); 
        }
    }
    
    public ObservableList<Estoque> getEstoque(){
         Connection es = ConnectionFactory.getConnection();
        try{
            ObservableList<Estoque> estoques = FXCollections.observableArrayList();
            PreparedStatement stt = this.e.prepareStatement("SELECT * FROM estoque");
            ResultSet res = stt.executeQuery();
            
            while(res.next()){
                Estoque l = new Estoque();
                l.setNome(res.getString("nome"));
                l.setCodigo(res.getInt("codigo"));
                l.setMarca(res.getString("marca"));
                l.setQuantidade(res.getInt("quantidade"));
                estoques.add(l);
            }

            stt.executeQuery();
            res.close();
            stt.close();
            return estoques;
           
        }catch(SQLException m){
                throw new RuntimeException(m);
        }
    }
  
    
     private static void fechaConexao(){
        try{
            e.close();
            
        }catch (SQLException p){
            System.out.println(p.getMessage()); 
        }
    }
     
    
}
