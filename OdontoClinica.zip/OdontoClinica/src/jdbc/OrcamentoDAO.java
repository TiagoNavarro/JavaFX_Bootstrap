/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import model.Orcamento;
import java.sql.PreparedStatement;
/**
 *
 * @author Aluno
 */
public class OrcamentoDAO {
    static Connection o; 
    
    public OrcamentoDAO(){
        OrcamentoDAO.o = ConnectionFactory.getConnection();
        
    }
    
    public static void enviaOrcamento(Orcamento orcamento){
        Connection o = ConnectionFactory.getConnection();
        String sql = "INSERT INTO orcamento (nome, valor, datao, telefone, descricao)"
                + "VALUES (?, ?, ?, ?, ?) ";
         
            Date data = Date.valueOf(orcamento.getDatao());
            
        try{
           
           PreparedStatement stmt = o.prepareStatement(sql);
           stmt.setString(1, orcamento.getNomep());
           stmt.setDouble (2, orcamento.getValor());
           stmt.setDate(3, data);
           stmt.setString(4, orcamento.getTelefoneo());
           stmt.setString (5, orcamento.getDescricao());
           stmt.execute();
           stmt.close();
            
        }catch (SQLException e){
            System.out.println(e.getMessage());
        }
        
    }
    
    private static void fechaConexaoO(){
        try{
            o.close();
            
        }catch (SQLException m){
            System.out.println(m.getMessage()); 
        }
    }
    
    
    
    
}
