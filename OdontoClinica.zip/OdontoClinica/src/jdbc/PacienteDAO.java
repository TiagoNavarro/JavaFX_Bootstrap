/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Paciente;

/**
 *
 * @author Aluno
 */
public class PacienteDAO {
    static Connection p; 
    
    public PacienteDAO (){
        PacienteDAO.p = ConnectionFactory.getConnection();
        
    }
    
    public static void inserePaciente (Paciente pac){
        Connection p = ConnectionFactory.getConnection(); 
        String sql = "INSERT INTO paciente (nome, cpf, cidade, bairro, rua, numero, telefone, sexo) "
                +"VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
    try{ 
        PreparedStatement stmt = p.prepareStatement (sql);
        stmt.setString(1, pac.getNome());
        stmt.setString(2, pac.getCpf());
        stmt.setString(3, pac.getCidade());
        stmt.setString(4, pac.getBairro());
        stmt.setString(5, pac.getRua());
        stmt.setInt(6, pac.getNum());
        stmt.setString(7, pac.getTelefone());
        stmt.setString(8, pac.getSexo());
        stmt.execute();
        stmt.close();
        
    }catch (SQLException e){
            System.out.println(e.getMessage());
        }
    
    }
    
    public void deletaPaciente(Paciente pac){
       String sql = "DELETE FROM paciente WHERE idp=?";
        try{
           PreparedStatement stmt = p.prepareStatement(sql);
           stmt.setInt(1, pac.getIdp());
           stmt.execute();
           stmt.close();
       
        }catch (SQLException e) {
            e.printStackTrace(); 
        }
        
   }
    
    
    public ObservableList<Paciente> getPacientes(){
            Connection p = ConnectionFactory.getConnection();
        try{
            ObservableList<Paciente> pacientes = FXCollections.observableArrayList();
            PreparedStatement stmt = this.p.prepareStatement("SELECT * FROM paciente");
            ResultSet resul = stmt.executeQuery();
            
            while(resul.next()){
                Paciente pa = new Paciente ();
                pa.setNome(resul.getString("nome"));
                pa.setCpf(resul.getString("cpf"));
                pa.setCidade(resul.getString("cidade"));
                pa.setBairro(resul.getString("bairro"));
                pa.setRua(resul.getString("rua"));
                pa.setNum(resul.getInt("numero"));
                pa.setTelefone(resul.getString("telefone"));
                pa.setSexo(resul.getString("sexo"));
                pa.setIdp(resul.getInt("idp"));
                pacientes.add(pa);
            }

            stmt.executeQuery();
            resul.close();
            stmt.close();
            return pacientes;
           
        }catch(SQLException m){
                throw new RuntimeException(m);
        
        }
    }
  
    private static void fechaConexao(){
        try{
            p.close();
            
        }catch (SQLException m){
            System.out.println(m.getMessage()); 
        }
    }
    
}
