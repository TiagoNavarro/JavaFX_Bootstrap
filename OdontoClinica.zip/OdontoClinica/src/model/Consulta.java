/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.time.LocalDate;

/**
 *
 * @author Aluno
 */
public class Consulta {
    private String paciente; 
    private LocalDate datac; 
    private String hora;
    private double valor; 
    private int idp; 

    
    
    public Consulta() {
        
    }

    public Consulta(String paciente, LocalDate data, String hora, double valor, int idp) {
        this.paciente = paciente;
        this.datac = data;
        this.hora = hora;
        this.valor = valor; 
        this.idp = idp; 
    }
    
    public int getIdc() {
        return idp;
    }

    public void setIdc(int idp) {
        this.idp = idp;
    }
    public String getPaciente() {
        return paciente;
    }

    public void setPaciente(String paciente) {
        this.paciente = paciente;
    }

    public LocalDate getData() {
        return datac;
    }
    
    public String getDataTable(){
        return this.datac.getDayOfMonth()+"/"+this.datac.getMonthValue()+"/"+this.datac.getYear();
    }

    public void setData(LocalDate datac) {
        this.datac = datac;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
   
    
}
