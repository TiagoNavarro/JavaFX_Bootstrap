/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Aluno
 */
public class Estoque {
    private String nome;
    private int codigo;
    private String marca;
    private int quantidade;
    
    public Estoque() {
        
    }

    public Estoque(String nome, int codigo, String marca, int quantidade) {
        this.nome = nome;
        this.codigo = codigo;
        this.marca = marca;
        this.quantidade = quantidade; 
    }
    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
   
}
