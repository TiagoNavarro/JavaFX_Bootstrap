/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.time.LocalDate;

/**
 *
 * @author Aluno
 */
public class Orcamento {
    private String nomep;
    private double valor;
    private LocalDate datao;
    private String telefoneo; 
    private String descricao; 

    public Orcamento(){
        
        
    }
    
    public Orcamento (String nomep, double valor, LocalDate datao, String telefoneo, String descricao){
        this.nomep = nomep;
        this.valor = valor;
        this.datao= datao;
        this.telefoneo = telefoneo;
        this.descricao = descricao; 
    }
    
    
    public String getNomep() {
        return nomep;
    }

    public void setNomep(String nomep) {
        this.nomep = nomep;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public LocalDate getDatao() {
        return datao;
    }

    public void setDatao(LocalDate datao) {
        this.datao = datao;
    }

    public String getTelefoneo() {
        return telefoneo;
    }

    public void setTelefoneo(String telefoneo) {
        this.telefoneo = telefoneo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    
    
    
}
