/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Aluno
 */
public class Paciente {
    private String nome;
    private String cpf;
    private String cidade;
    private String bairro;
    private String rua;
    private int num;
    private String sexo; 
    private String telefone; 
    private int idp; 

   
    public Paciente () {
    
    
}
    
    public Paciente (String nome, String cpf, String cidade , String bairro, String rua, int num , String telefone, String sexo, int idp) {
        this.nome = nome;
        this.cpf = cpf; 
        this.cidade = cidade;
        this.bairro = bairro;
        this.rua = rua ;
        this.num = num;
        this.telefone = telefone; 
        this.sexo = sexo; 
        this.idp = idp; 
    }
    
     public int getIdp() {
        return idp;
    }

    public void setIdp(int idp) {
        this.idp = idp;
    }
    
    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
    
    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
   
    
    
    
}
