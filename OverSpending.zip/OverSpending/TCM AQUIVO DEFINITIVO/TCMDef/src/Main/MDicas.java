/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import Controller.TelaDicasController;
import Model.Usuario;
import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author SARA
 */
public class MDicas extends Application {
    
    private static Stage stage;
    
    public static Stage getStage(){
        return MDicas.stage;
    }
    
    public static void setStage(Stage st){
        MDicas.stage = st;
    }
    
    public MDicas(Usuario u){
        TelaDicasController.setLogado(u);
    }
    
    @Override
    public void start(Stage primaryStage) throws IOException{
        
        Parent root = FXMLLoader.load(getClass().getResource("/View/TelaDica.fxml"));
        
        Scene scene = new Scene(root);
        
        primaryStage.setTitle("Dicas de Consumo");
        primaryStage.setScene(scene);
        primaryStage.show();
        
        stage = primaryStage;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
