/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import Controller.TelaEconomiaController;
import Model.Usuario;
import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author SARA
 */
public class MEconomia extends Application {
    
    private static Stage stage;
    
    public static Stage getStage(){
        return MEconomia.stage;
    }
    
    public static void setStage(Stage st){
        MEconomia.stage = st;
    }
    
    public MEconomia(Usuario u){
        TelaEconomiaController.setLogado(u);
    }
    
    @Override
    public void start(Stage primaryStage) throws IOException {
        
        Parent root = FXMLLoader.load(getClass().getResource("/View/TelaEconomia.fxml"));
        
        Scene scene = new Scene(root);
        
        primaryStage.setTitle("Relatórios de Economia");
        primaryStage.setScene(scene);
        primaryStage.show();
        
        MEconomia.stage = primaryStage;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
