package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {

    public static Connection getConnection() {

        Connection c = null;
        try {
            c = DriverManager.getConnection("jdbc:postgresql://localhost/adm", "postgres", "12345");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return c;
    }
}
