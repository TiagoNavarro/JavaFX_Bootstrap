package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Sóhorario;
import model.Adm;
import model.Observacao;

public class FuncionarioDAO {

    static Connection c;

    public static void insereFuncionario(Sóhorario fun) {
        Connection c = ConnectionFactory.getConnection();
        String sql = "INSERT INTO fun(entrada, saida, data)"
                + "VALUES(?,?,?);";
        try {
            PreparedStatement stmt = c.prepareStatement(sql);
            stmt.setString(1, fun.getEntrada());
            stmt.setString(2, fun.getSaida());
            stmt.setString(3,fun.getData());
            stmt.execute();
            stmt.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void insere_adm(Adm adm) {
        Connection c = ConnectionFactory.getConnection();
        String sql = "INSERT INTO adm(Nome, Idade, Sexo, Cpf, Naturalidade, Turno)"
                + "VALUES(?,?,?,?,?,?);";
        try {
            PreparedStatement stmt = c.prepareStatement(sql);
            stmt.setString(1, adm.getNome());
            stmt.setInt(2, adm.getIdade());
            stmt.setString(3, adm.getSexo());
            stmt.setInt(4, adm.getCPF());
            stmt.setString(5, adm.getNaturalidade());
            stmt.setString(6, adm.getTurno());
            stmt.execute();
            stmt.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
      public static void insere_obs(Observacao observacao) {
        Connection a;
        a = ConnectionFactory.getConnection();
        String sql = "INSERT INTO observacao (Digita, Data)"
                + "VALUES(?,?);";
        try {
            PreparedStatement stmt = a.prepareStatement(sql);
            stmt.setString(1, observacao.getObservacao());
            stmt.setString(2, observacao.getData());
            stmt.execute();
            stmt.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
      
    }
     
      public ObservableList<Observacao> get_obs(){
      try{
            c = ConnectionFactory.getConnection();
            ObservableList<Observacao> observacao = FXCollections.observableArrayList();
            PreparedStatement stmt = c.prepareStatement("SELECT * FROM observacao");
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Observacao a = new Observacao();
                a.setObservacao(rs.getString("digita"));
                a.setData(rs.getString("Data"));
                observacao.add(a);
            }
            
            rs.close();
            stmt.close();
            return observacao;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
      }
       public ObservableList<Adm> gettabela(){
      try{
            c = ConnectionFactory.getConnection();
            ObservableList<Adm> adm = FXCollections.observableArrayList();
            PreparedStatement stmt = c.prepareStatement("SELECT * FROM adm");
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Adm a = new Adm();
                a.setNome(rs.getString("nome"));
                a.setTurno(rs.getString("Turno"));
                a.setCPF(rs.getInt("CPF"));
                a.setIdade(rs.getInt("Idade"));
                a.setSexo(rs.getString("Sexo"));              
                adm.add(a);
            }
            
            rs.close();
            stmt.close();
            return adm;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
 public void deleta_obs(Observacao observacao){
        String sql = "DELETE FROM observacao WHERE Data=?";
        try{
            PreparedStatement stmt = c.prepareStatement(sql);
            stmt.setString(1,observacao.getData());
            stmt.execute();
            stmt.close();
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
    }
 public void deleta_FUN(Adm adm){
        String sql = "DELETE FROM adm WHERE id=?";
        try{
            PreparedStatement stmt = c.prepareStatement(sql);
            stmt.setInt(1,adm.getId());
            stmt.execute();
            stmt.close();
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
    }
    

    private static void fecharConexao() {
        try {
            c.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}


   
