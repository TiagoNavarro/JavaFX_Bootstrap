
package model;

public class Adm {
    
    private String nome,sexo, Turno, naturalidade ;
    private int idade;
    private int id;
    private int CPF;

    public Adm() {  
    }
public Adm( String nome,String turno, String naturalidade,int id, String sexo, int idade, int CPF ) {
        this.nome = nome;
       this.id = id;
        this.sexo = sexo;
        this.Turno = turno;
        this.naturalidade = naturalidade;
        this.idade = idade;
        this.CPF = CPF;
}

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

   
      public String getSexo() {
        return sexo;
    }

    public void setSexo(String feminino) {
        this.sexo = feminino;
    }

    public String getTurno() {
        return Turno;
    }

    public void setTurno(String Turno) {
        this.Turno = Turno;
    }

    public String getNaturalidade() {
        return naturalidade;
    }

    public void setNaturalidade(String naturalidade) {
        this.naturalidade = naturalidade;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public int getCPF() {
        return CPF;
    }

    public void setCPF(int CPF) {
        this.CPF = CPF;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}


