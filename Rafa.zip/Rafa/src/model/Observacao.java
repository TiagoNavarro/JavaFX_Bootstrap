
package model;

public class Observacao {
     private String observacao;
     private String data;
    public Observacao() {
    }
      public Observacao(String observacao, int id,String data) {
        this.observacao = observacao;
        this.data = data;
      }
    public String getObservacao() {
        return observacao;
    }
    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }
    public String getData() {
        return data;
    }
    public void setData(String data) {
        this.data = data;
    }  
}
