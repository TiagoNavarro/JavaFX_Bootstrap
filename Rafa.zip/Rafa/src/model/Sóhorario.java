package model;
public class Sóhorario {
    private int id;
    private String data;
    private String entrada;
    private String saida;

    public Sóhorario() {
    }
    
    public Sóhorario(int id, String entrada,String saida, String data) {
        this.id = id;
        this.entrada = entrada;
        this.saida = saida;
        this.data = data;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getEntrada() {
        return entrada;
    }
    public void setEntrada(String entrada) {
        this.entrada = entrada;
    }
    public String getSaida() {
        return saida;
    }
    public void setSaida(String saida) {
        this.saida = saida;
    }
    public String getData() {
        return data;
    }
    public void setData(String data) {
        this.data = data;
    }
}

    