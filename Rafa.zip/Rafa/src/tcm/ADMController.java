package tcm;

import static java.lang.Integer.parseInt;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import jdbc.FuncionarioDAO;
import model.Adm;

public class ADMController implements Initializable {

    private final ObservableList<String> turnocom = FXCollections.observableArrayList("Manhã", "Tarde", "Noite");
    private final ObservableList<String> estados = FXCollections.observableArrayList(" Acre (AC)", "Alagoas (AL)", "Amapá (AP)", "Amazonas (AM)", "Bahia (BA)", "Ceará (CE)", "Distrito Federal (DF)", "Espírito Santo (ES)", "Goiás (GO)", "Maranhão (MA)", "Mato Grosso (MT)", "Mato Grosso do Sul (MS)", "Minas Gerais (MG)", "Pará (PA)", "Paraíba (PB)", "Paraná (PR)", "Pernambuco (PE)", "Piauí (PI)", "Rio de Janeiro (RJ)", "Rio Grande do Norte (RN)", "Rio Grande do Sul (RS)", "Rondônia (RO)", "Roraima (RR)", "Santa Catarina (SC)", "São Paulo (SP)", "Sergipe (SE)", "Tocantins (TO)");
   
    @FXML
    private Label CADASTRO;
    @FXML
    private Label nome;
    @FXML
    private Label sexo;
    @FXML
    private Label idade;
    @FXML
    private Label cpf;
    @FXML
    private Label naturalidade;
    @FXML
    private Label turno;

    @FXML
    private Button bttsalvar;
    @FXML
    private Button btsair;
    @FXML
    private Button btprocurar;
    @FXML
    private Button excluir;
    @FXML
    private TextField cxnome;
    @FXML
    private TextField cxidade;
    @FXML
    private TextField cxcpf;
    @FXML
    private TextField cxnaturalidade;

    @FXML
    private ComboBox cxturno;
    @FXML
    private ComboBox cxestados;
    @FXML
    private TextField cxturno2;

    @FXML
    private RadioButton feminino;
    @FXML
    private RadioButton masculino;
    
    @FXML private TableView<Adm> tabela_relatorio;
    @FXML private TableColumn<Adm, String> coluna_nome;
    @FXML private TableColumn<Adm, String> coluna_sexo;
    @FXML private TableColumn<Adm, String> coluna_turno;
    @FXML private TableColumn<Adm, Integer> coluna_cpf;
    @FXML private TableColumn<Adm, Integer> coluna_idade;
    private static Adm selecionado;    
    

    @FXML
    public static Stage StageCad;

    public void start(Stage stage) throws Exception {

        Parent root = FXMLLoader.load(getClass().getResource("ADM.fxml"));

        Scene scene = new Scene(root);
        stage.setTitle("Tela de adm");
        stage.setScene(scene);
        stage.show();
        StageCad = stage;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cxturno.setItems(turnocom);
        cxestados.setItems(estados);
        Mostra_observaçoes();
        atualObservacoes();
        
        tabela_relatorio.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {

             @Override
             public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                 if(newValue !=null){
                    ADMController.selecionado = (Adm) newValue;
                 }else{
                     ADMController.selecionado = null;
                 }
             }
         });
            }
@FXML
    private void exclui_FUN(ActionEvent event){
            if(ADMController.selecionado != null){
                FuncionarioDAO dao = new FuncionarioDAO();
                dao.deleta_FUN(ADMController.selecionado);
                Alert a = new Alert(Alert.AlertType.CONFIRMATION);
                a.setHeaderText("Funcionario deletado com sucesso!");
                a.showAndWait();
                atualObservacoes();
            }else{
                Alert a = new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Por favor, selecione um funcioario!");
                a.showAndWait();
            }
    }
    @FXML
    public void radio(ActionEvent event) {
        final ToggleGroup rafa = new ToggleGroup();
        RadioButton r1 = new RadioButton("Feminino");
        feminino.setToggleGroup(rafa);
        feminino.setSelected(true);
        RadioButton r2 = new RadioButton("Masculino");
        masculino.setToggleGroup(rafa);

    }
    public void atualObservacoes(){
    FuncionarioDAO dao = new FuncionarioDAO();
        adm = dao.gettabela();
        tabela_relatorio.setItems(adm);
    }
    @FXML 
    public void Mostra_observaçoes(){
        coluna_nome.setCellValueFactory(new PropertyValueFactory("Nome"));
        coluna_idade.setCellValueFactory(new PropertyValueFactory("Idade"));
        coluna_turno.setCellValueFactory(new PropertyValueFactory("Turno"));
        coluna_cpf.setCellValueFactory(new PropertyValueFactory("CPF"));
        coluna_sexo.setCellValueFactory(new PropertyValueFactory("Sexo"));
        atualObservacoes();
        tabela_relatorio.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {

            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
            }
    
                });
                }
    ObservableList<Adm> adm = FXCollections.observableArrayList();
    public void iniciaBusca(){
    tabela_relatorio.setItems(adm);
    cxturno2.setOnKeyReleased((KeyEvent e)->{
            buscar();
    });
    }
    public void buscar(){
        ObservableList<Adm> adm2 = FXCollections.observableArrayList();        
        for(int x=0; x<adm.size();x++){
        if(adm.get(x).getNome().toUpperCase().contains(cxturno2.getText().toUpperCase())){
                adm2.add(adm.get(x));
            }
        }
        tabela_relatorio.setItems(adm2);
        }
    
    
    @FXML
    public void cadastrar_func(ActionEvent event) {
        try {
            Adm adm = new Adm();
            adm.setNome(cxnome.getText());
            adm.setIdade(parseInt(cxidade.getText()));
            adm.setCPF(parseInt(cxcpf.getText()));
            adm.setNaturalidade(cxestados.getValue().toString());
            adm.setTurno(cxturno.getValue().toString());
            if(masculino.isSelected()){
                adm.setSexo(masculino.getText());
            }else{
                 adm.setSexo(feminino.getText());  
            }
            FuncionarioDAO dao = new FuncionarioDAO();
            dao.insere_adm(adm);
            Alert a = new Alert(Alert.AlertType.INFORMATION);
            a.setTitle("VERIFICAÇÃO DE CADASTRO");
            a.setHeaderText("Campos digitados corretamente");
            a.setContentText("OK, Cadastro realizado");
            a.showAndWait();
            atualObservacoes();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("erro ao cadastrar: " + e.getMessage());

        }
    }

    @FXML
    public void Sair(ActionEvent t) {
        Stage stage = (Stage) btsair.getScene().getWindow();
        stage.close();

    }
}
