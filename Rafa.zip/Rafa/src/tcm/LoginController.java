package tcm;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class LoginController implements Initializable {

    @FXML
    private Label login;
    @FXML
    private Label senha;

    @FXML
    private Button btentrar;
    @FXML
    private Button btsair;

    @FXML
    private TextField cxlogin;

    @FXML
    private PasswordField cxsenha;

    @FXML
    private void ClicouCAD(ActionEvent event) {
        if (cxlogin.getText().equals("admin") && cxsenha.getText().equals("admin")) {
            btentrar.setOnMouseClicked((MouseEvent a) -> {
                ADMController abre = new ADMController();
                try {
                    abre.start(new Stage());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });

        } else if (cxlogin.getText().equals("usuario") && cxsenha.getText().equals("usuario")) {
            btentrar.setOnMouseClicked((MouseEvent a) -> {
                Tela_cadController abre = new Tela_cadController();
                try {
                    abre.start(new Stage());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        } else {
           Alert c = new Alert(Alert.AlertType.WARNING);
            c.setTitle("ATENÇÃO");
            c.setHeaderText("Login inválido");
            c.setContentText("Tente novamente");
            c.showAndWait();
        }
    }

    @FXML
    public void SairStageCad(ActionEvent event) {
       btsair.setOnMouseClicked((MouseEvent )->{
        Platform.exit();
       });
               }
    

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }
}
