package tcm;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import jdbc.FuncionarioDAO;
import static jdbc.FuncionarioDAO.insere_obs;
import model.Observacao;

public class ObservacaoController implements Initializable {
    @FXML
    private Label data;
    @FXML
    private Label deseja;
    @FXML
    private Label obs;
    @FXML
    private TextArea digita;
    @FXML
    private Button excluir;
    @FXML
    private Button voltar;
    @FXML
    private Button adicionar;
    @FXML
    private Button buttonsair;
    @FXML
    private DatePicker CXDATA;
    
    @FXML private TableView<Observacao> rafan;
    @FXML private TableColumn<Observacao, String> coluna_ob;
    @FXML private TableColumn<Observacao, String> coluna_aa;   
    @FXML private ObservableList<Observacao> funcionarios;
    @FXML private static Observacao selecionado;
    public static Stage rafa;

    public void start(Stage stage) throws Exception {

        Parent root = FXMLLoader.load(getClass().getResource("Observacao.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        rafa = stage;
    }
    @FXML
    private void VOLTAR() {
        voltar.setOnMouseClicked((MouseEvent a) -> {
            Tela_cadController abre = new Tela_cadController();
            try {
                abre.start(new Stage());
                rafa.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
@FXML
    private void Clicousalvar(ActionEvent event) {
            if(digita.getText().equals("")||CXDATA.getValue().toString().equals("") ){
            
           Alert al = new Alert (Alert.AlertType.WARNING);
           al.setTitle("Atenção!");
           al.setHeaderText("Os Campos Estão Vazios");
           al.setContentText("Por favor, preencha os campos!");
           al.showAndWait(); 
             
         }else {
            try {
                
                Observacao observacao = new Observacao ();
                observacao.setObservacao(digita.getText());
                observacao.setData(CXDATA.getValue().toString());
                insere_obs(observacao);
            
             Alert a = new Alert(Alert.AlertType.INFORMATION);
              a.setTitle("VERIFICAÇÃO DE CADASTRO");
              a.setHeaderText("Campos digitados corretamente");
              a.setContentText("OK, Cadastro realizado");
              a.showAndWait();
               Mostra_observaçoes();
               
            }catch (Exception e){
                System.out.println("Erro ao Cadastrar uma dica: " + e.getMessage());
            }    
        }
    }
    @FXML 
    public void Mostra_observaçoes(){
        coluna_ob.setCellValueFactory(new PropertyValueFactory("Digita"));
        coluna_aa.setCellValueFactory(new PropertyValueFactory("Data"));
        FuncionarioDAO dao = new FuncionarioDAO();
        ObservableList<Observacao> observacao = dao.get_obs();
        rafan.setItems(observacao);
        rafan.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {

            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
            }
    
                });
                }
     @FXML
    private void exclui_dica(ActionEvent event){
            if(ObservacaoController.selecionado != null){
                FuncionarioDAO dao = new FuncionarioDAO();
                dao.deleta_obs(ObservacaoController.selecionado);
                Alert a = new Alert(Alert.AlertType.CONFIRMATION);
                a.setHeaderText("Observação deletada com sucesso!");
                a.showAndWait();
                Mostra_observaçoes();
            }else{
               Alert a = new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Por favor, selecione uma observacao!");
                a.showAndWait();
            }
    }
    @FXML
    public void Sair(ActionEvent t) {
        Stage stage = (Stage) buttonsair.getScene().getWindow();
        stage.close();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Mostra_observaçoes();
        rafan.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {

             @Override
             public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                 if(newValue !=null){
                    ObservacaoController.selecionado = (Observacao) newValue;
                 }else{
                     ObservacaoController.selecionado = null;
                 }
             }
         });
    }
public void LimparCampos(ActionEvent event) {
        digita.setText("");
        CXDATA.setValue(null);
    }
}
