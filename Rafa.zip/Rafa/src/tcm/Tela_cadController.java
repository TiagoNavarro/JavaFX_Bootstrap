package tcm;

import static java.lang.Integer.parseInt;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import static jdbc.FuncionarioDAO.insereFuncionario;
import model.Adm;
import model.Sóhorario;

public class Tela_cadController implements Initializable {

    @FXML
    private Label cadastro;
    @FXML
    private Label codigo;
    @FXML
    private Label entrada;
    @FXML
    private Label saida;
    @FXML
    private Label DATA;
    @FXML
    private Label pesquisar;

    @FXML
    private Button btsalvar;
    @FXML
    private Button btbuscar;
    @FXML
    private Button btsair;
    @FXML
    private Button btlimpar;
    @FXML
    private Button btobservaçoes;

    @FXML
    private TextField dtcod;
    @FXML
    private TextField dtent;
    @FXML
    private TextField dtsai;
    @FXML
    private TextField dtbus;
    @FXML
    private DatePicker CXDATA;
 
    @FXML
  private ObservableList<Adm> funcionarios;
    @FXML
    private TableColumn<Adm, Integer> colunaID;
    @FXML
    private TableColumn<Adm, String> colunanome;
    
    @FXML
    private Tab tabcad;
    @FXML
    private Tab tabpesq;
    @FXML
    public static Stage rafa;

    public void start(Stage stage) throws Exception {

        Parent root = FXMLLoader.load(getClass().getResource("Tela_cad.fxml"));

        Scene scene = new Scene(root);
        stage.setTitle("Tela de cadastro");
        stage.setScene(scene);
        stage.show();
        rafa = stage;
    }

    @FXML
    private void ClicouCAD(ActionEvent event) {
        try {
            Sóhorario fun = new Sóhorario();
         fun.setData(CXDATA.getValue().toString());
            fun.setEntrada(dtent.getText());
            fun.setSaida(dtsai.getText());
            insereFuncionario(fun);

            Alert a = new Alert(Alert.AlertType.INFORMATION);
            a.setTitle("VERIFICAÇÃO DE CADASTRO");
            a.setHeaderText("Campos digitados corretamente");
            a.setContentText("OK, Cadastro realizado");
            a.showAndWait();
        } catch (Exception e) {
            System.out.println("erro ao cadastrar: " + e.getMessage());

        }
    }

    @FXML
    private void CLICOU() {
        btobservaçoes.setOnMouseClicked((MouseEvent a) -> {
            ObservacaoController abre = new ObservacaoController();
            try {
                abre.start(new Stage());
                rafa.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    @FXML
    public void Sair(ActionEvent t) {
        Stage stage = (Stage) btsair.getScene().getWindow();
        stage.close();

    }
       

    public void LimparCampos(ActionEvent event) {
        dtcod.setText("");
        dtent.setText("");
        dtsai.setText("");
        CXDATA.setValue(null);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }

}
