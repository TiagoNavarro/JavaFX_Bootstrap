/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Carro;
import Model.Cliente;
import Model.Devolver;
import Model.Reserva;
import Principal.AlteraCarroPrincipal;
import Principal.AlteraClientePrincipal;
import Principal.CadCarroPrincipal;
import Principal.CadClientePrincipal;
import Principal.ExcluirCarroPrincipal;
import Principal.ExcluirClientePrincipal;
import Principal.ReservaTotalPrincipal;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import jdbc.CarroDAO;
import jdbc.ClienteDAO;
import jdbc.DevolverDAO;
import jdbc.ReservaDAO;

/**
 * FXML Controller class
 *
 * @author patrick
 */
public class AdmController implements Initializable {

    private static Cliente sCliente;
    private static Carro sCarro;
    private static Reserva sReserva;
    private static Devolver sDevolver;
    
   @FXML TableView<Cliente> tbCliente;
   @FXML TableColumn<Cliente, String> cNome;
   @FXML TableColumn<Cliente, String> cCPF;
   @FXML TableColumn<Cliente, String> cEmail;
   @FXML TableColumn<Cliente, String> cTelefone;
   @FXML TableColumn<Cliente, String> cLogin;
   
   @FXML TableView<Carro> tbCarro;
   @FXML TableColumn<Carro, String> cModelo;
   @FXML TableColumn<Carro, String> cMarca;
   @FXML TableColumn<Carro, Integer> cAno;
   @FXML TableColumn<Carro, String> cPlaca;
   @FXML TableColumn<Carro, Double> cKm;
   
   @FXML TableView<Reserva> tbAgenda;
   @FXML TableColumn<Reserva, Integer> cId_reserva;
   @FXML TableColumn<Reserva, String> cPlacaAg;
   @FXML TableColumn<Reserva, String> cCpfAg;
   @FXML TableColumn<Reserva, String> cDestino;
   @FXML TableColumn<Reserva, String> cServico;
   @FXML TableColumn<Reserva, String> cData_reserva;
   @FXML TableColumn<Reserva, String> cHr_reserva;
   @FXML TableColumn<Reserva, String> cHr_retorno;
   
   @FXML TableView<Devolver> tbDev;
   @FXML TableColumn<Devolver, Integer> cId_dev;
   @FXML TableColumn<Devolver, Integer> cId_reservaDev;
   @FXML TableColumn<Devolver, String> cGastos;
   @FXML TableColumn<Devolver, String> cObs;
   @FXML TableColumn<Devolver, Double> cKm_d;
    
   ObservableList<Cliente> cliente = FXCollections.observableArrayList();
   ObservableList<Carro> carro = FXCollections.observableArrayList();
   ObservableList<Reserva> reserva = FXCollections.observableArrayList();
   ObservableList<Devolver> devolver = FXCollections.observableArrayList();
   
   public void cadCliente(){
       CadClientePrincipal abre = new CadClientePrincipal();
        try {
            abre.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(AdmController.class.getName()).log(Level.SEVERE, null, ex);
        }
   }
   
   public void verReservaTotal(){
       ReservaTotalPrincipal abre = new ReservaTotalPrincipal();
        try {
            abre.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(AdmController.class.getName()).log(Level.SEVERE, null, ex);
        }
   }
   
   public void cadCarro(){
       CadCarroPrincipal abre = new CadCarroPrincipal();
        try {
            abre.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(AdmController.class.getName()).log(Level.SEVERE, null, ex);
        }
   }
   
   public void alteraCarro(ActionEvent event) throws Exception {
        if(AdmController.sCarro!=null){
            System.out.println("Carro SELECIONADO");
            AlteraCarroPrincipal abre = new AlteraCarroPrincipal(AdmController.sCarro);
            abre.start(new Stage());
        }else{
            Alert c = new Alert(Alert.AlertType.WARNING);
            c.setTitle("ATENÇÃO");
            c.setHeaderText("Nada Selecionado");
            c.setContentText("Por favor, Selecione um Carro!");
            c.showAndWait();
        }
    }

    public void alteraCliente(ActionEvent event) throws Exception {
        if(AdmController.sCliente!=null){
            System.out.println("Cliente SELECIONADO");
            AlteraClientePrincipal abre = new AlteraClientePrincipal(AdmController.sCliente);
            abre.start(new Stage());
        }else{
            Alert c = new Alert(Alert.AlertType.WARNING);
            c.setTitle("ATENÇÃO");
            c.setHeaderText("Nada Selecionado");
            c.setContentText("Por favor, Selecione um Usuário!");
            c.showAndWait();
        }
    }
   
    @FXML
    private void deletaCarro() {
        if (AdmController.sCarro != null) {
            ExcluirCarroPrincipal abre = new ExcluirCarroPrincipal(AdmController.sCarro);
            try {
                abre.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(AdmController.class.getName()).log(Level.SEVERE, null, ex);
            }
           
        } else {
            Alert c = new Alert(Alert.AlertType.WARNING);
            c.setTitle("ATENÇÃO");
            c.setHeaderText("Nada Selecionado");
            c.setContentText("Por favor, Selecione um carro!");
            c.showAndWait();
        }
    }
     @FXML
    private void deletaCliente() {
        if (AdmController.sCliente != null) {
            ExcluirClientePrincipal abre = new ExcluirClientePrincipal(AdmController.sCliente);
            try {
                abre.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(AdmController.class.getName()).log(Level.SEVERE, null, ex);
            }
           
        } else {
            Alert c = new Alert(Alert.AlertType.WARNING);
            c.setTitle("ATENÇÃO");
            c.setHeaderText("Nada Selecionado");
            c.setContentText("Por favor, Selecione um Cliente!");
            c.showAndWait();
        }
    }
    @FXML
    private void cancelaReserva() {
        if (AdmController.sReserva != null) {
            ReservaDAO dao = new ReservaDAO();
            dao.deletaReserva(AdmController.sReserva);
            preencheTabelaAgenda();
            atualizaTabelaAgenda();
            Alert a = new Alert(Alert.AlertType.INFORMATION);
                a.setTitle("VERIFICAÇÃO DE EXCLUSÃO");
                a.setHeaderText("Campos excluido corretamente");
                a.setContentText("OK, Reserva Cancelada!");
                a.showAndWait();
        } else {
            Alert c = new Alert(Alert.AlertType.WARNING);
            c.setTitle("ATENÇÃO");
            c.setHeaderText("Nada Selecionado");
            c.setContentText("Por favor, Selecione uma Reserva!");
            c.showAndWait();
        }
    }
    
    public void atualizaTabelaCarro() {
        CarroDAO dao = new CarroDAO();
        carro = dao.retornaCarro();
        tbCarro.setItems(carro);        
        tbCarro.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                if (newValue != null) {
                    sCarro = (Carro) newValue;
                } else {
                    sCarro = null;
                }
            }
        });        
    }
    public void preencheTabelaCarro() {
        cModelo.setCellValueFactory(new PropertyValueFactory("modelo"));
        cMarca.setCellValueFactory(new PropertyValueFactory("marca"));
        cAno.setCellValueFactory(new PropertyValueFactory("ano"));
        cPlaca.setCellValueFactory(new PropertyValueFactory("placa"));
        cKm.setCellValueFactory(new PropertyValueFactory("km"));
        CarroDAO dao = new CarroDAO();
        carro = dao.retornaCarro();
        tbCarro.setItems(carro);
    }
    
    public void atualizaTabelaCliente() {
        ClienteDAO dao = new ClienteDAO();
        cliente = dao.retornaCliente();
        tbCliente.setItems(cliente);        
        tbCliente.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                if (newValue != null) {
                    sCliente = (Cliente) newValue;
                } else {
                    sCliente = null;
                }
            }
        });        
    }
    public void preencheTabelaCliente() {
        cNome.setCellValueFactory(new PropertyValueFactory("nome"));
        cCPF.setCellValueFactory(new PropertyValueFactory("cpf"));
        cEmail.setCellValueFactory(new PropertyValueFactory("email"));
        cTelefone.setCellValueFactory(new PropertyValueFactory("telefone"));
        cLogin.setCellValueFactory(new PropertyValueFactory("login"));        
        ClienteDAO dao = new ClienteDAO();
        cliente = dao.retornaCliente();
        tbCliente.setItems(cliente);
    }
    public void atualizaTabelaAgenda() {
        ReservaDAO dao = new ReservaDAO();
        reserva = dao.retornaReserva();
        tbAgenda.setItems(reserva);        
        tbAgenda.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                if (newValue != null) {
                    sReserva = (Reserva) newValue;
                } else {
                    sReserva = null;
                }
            }
        });        
    }
    public void preencheTabelaAgenda() {
        cId_reserva.setCellValueFactory(new PropertyValueFactory("id_reserva"));
        cPlacaAg.setCellValueFactory(new PropertyValueFactory("placa"));
        cCpfAg.setCellValueFactory(new PropertyValueFactory("cpf"));
        cDestino.setCellValueFactory(new PropertyValueFactory("destino"));
        cServico.setCellValueFactory(new PropertyValueFactory("servico"));
        cData_reserva.setCellValueFactory(new PropertyValueFactory("data_reserva"));
        cHr_reserva.setCellValueFactory(new PropertyValueFactory("hr_reserva"));        
        cHr_retorno.setCellValueFactory(new PropertyValueFactory("hr_retorno"));        
        ReservaDAO dao = new ReservaDAO();
        reserva = dao.retornaReserva();
        tbAgenda.setItems(reserva);
    }
    
    public void atualizaTabelaDev() {
        DevolverDAO dao = new DevolverDAO();
        devolver = dao.retornaDev();
        tbDev.setItems(devolver);        
        tbDev.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                if (newValue != null) {
                    sDevolver = (Devolver) newValue;
                } else {
                    sDevolver = null;
                }
            }
        });        
    }
    public void preencheTabelaDev() {
        cId_dev.setCellValueFactory(new PropertyValueFactory("id_devolve"));
        cId_reservaDev.setCellValueFactory(new PropertyValueFactory("id_reserva"));
        cGastos.setCellValueFactory(new PropertyValueFactory("gastos"));
        cObs.setCellValueFactory(new PropertyValueFactory("obs"));
        cKm_d.setCellValueFactory(new PropertyValueFactory("km_d"));
        DevolverDAO dao = new DevolverDAO();
        devolver = dao.retornaDev();
        tbDev.setItems(devolver);
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        preencheTabelaCliente();
        atualizaTabelaCliente();
        preencheTabelaCarro();
        atualizaTabelaCarro();
        preencheTabelaAgenda();
        atualizaTabelaAgenda();
        preencheTabelaDev();
        atualizaTabelaDev();
    }    
    
}
