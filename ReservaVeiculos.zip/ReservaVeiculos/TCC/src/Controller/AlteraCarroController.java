/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Carro;
import Principal.AlteraCarroPrincipal;
import static Principal.AlteraCarroPrincipal.sAlteraCarro;
import static java.lang.Double.parseDouble;
import static java.lang.Integer.parseInt;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import jdbc.CarroDAO;

/**
 * FXML Controller class
 *
 * @author patrick
 */
public class AlteraCarroController implements Initializable {

    @FXML private TextField cModelo;
    @FXML private TextField cAno;
    @FXML private TextField cMarca;
    @FXML private TextField cKm;
    @FXML private TextField cPlaca;
    
     public void alterar(){
   if(cModelo.getText().equals("")||cAno.getText().equals("")||cMarca.getText().equals("")||
      cPlaca.getText().equals("")||cKm.getText().equals("")){
        Alert c = new Alert(Alert.AlertType.ERROR);
        c.setTitle("ATENÇÃO");
        c.setHeaderText("Campos vazios");
        c.setContentText("Por favor, Preencha todos os Campos!!");
        c.showAndWait();      
        cModelo.setText(""); cMarca.setText(""); cAno.setText(""); 
        cPlaca.setText(""); cKm.setText("");  
   } else{
          try{
            CarroDAO dao = new CarroDAO();
            Carro c = new Carro();
          c.setModelo(cModelo.getText());     
          c.setMarca(cMarca.getText());
          c.setAno(parseInt(cAno.getText()));
          c.setKm(parseDouble(cKm.getText()));
          c.setPlaca(cPlaca.getText()); 
          dao.atualizaCarro(c);                
            Alert a = new Alert(Alert.AlertType.CONFIRMATION);
            a.setTitle("VERIFICAÇÃO");
            a.setContentText("Carro Alterado com Sucesso!!");
            a.showAndWait();
            sAlteraCarro.close();                
            }catch (Exception e){
                System.out.println("Erro Cadastro de Carro");
                e.printStackTrace();
            }
          }
     }
       
      public void completaCampos(){
         int an = AlteraCarroPrincipal.carro.getAno();
         String ano = String.valueOf(an);
         double k = AlteraCarroPrincipal.carro.getKm();
         String km = String.valueOf(k);
        
        cModelo.setText(AlteraCarroPrincipal.carro.getModelo());
        cMarca.setText(AlteraCarroPrincipal.carro.getMarca());
        cAno.setText(ano);
        cPlaca.setText(AlteraCarroPrincipal.carro.getPlaca());
        cKm.setText(km);
      }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        completaCampos();
    }    
    
}
