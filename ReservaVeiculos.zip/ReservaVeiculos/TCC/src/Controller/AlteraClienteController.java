/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Cliente;
import Principal.AlteraClientePrincipal;
import static Principal.AlteraClientePrincipal.cliente;
import static Principal.AlteraClientePrincipal.sAlteraCliente;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import jdbc.ClienteDAO;

/**
 * FXML Controller class
 *
 * @author patrick
 */
public class AlteraClienteController implements Initializable {

    @FXML TextField cNome;
    @FXML TextField cCPF;
    @FXML TextField cEmail;
    @FXML TextField cTelefone;
    @FXML TextField cLogin;
    @FXML PasswordField cSenha;
    @FXML PasswordField cVSenha;
    
    public void alterar(){
   if(cNome.getText().equals("")||cCPF.getText().equals("")||cEmail.getText().equals("")||cTelefone.getText().equals("")||
      cLogin.getText().equals("")||cSenha.getText().equals("")||cVSenha.getText().equals("")){
        Alert c = new Alert(Alert.AlertType.ERROR);
        c.setTitle("ATENÇÃO");
        c.setHeaderText("Campos vazios");
        c.setContentText("Por favor, Preencha todos os Campos!!");
        c.showAndWait();       
   } else{
            try{
                Cliente u = new Cliente();
                ClienteDAO dao = new ClienteDAO();
                u.setNome(cNome.getText());     
                u.setCpf(cliente.getCpf());
                u.setEmail(cEmail.getText());
                u.setTelefone(cTelefone.getText());                
                u.setLogin(cLogin.getText());
                if(cSenha.getText().equals(cVSenha.getText())){
                u.setSenha(cSenha.getText());
                dao.atualizaCliente(u);                
            Alert c = new Alert(Alert.AlertType.CONFIRMATION);
            c.setTitle("VERIFICAÇÃO");
            c.setContentText("Cliente Alterado com Sucesso!!");
            c.showAndWait();
            sAlteraCliente.close();
                }else{
                  Alert c = new Alert(Alert.AlertType.ERROR);
            c.setTitle("ATENÇÃO");
            c.setHeaderText("Campos Incorretos");
            c.setContentText("Por favor, Verifique a sua Senha!!");
            c.showAndWait();  
            cNome.setText(""); cCPF.setText(""); cEmail.setText(""); cTelefone.setText("");
            cLogin.setText(""); cSenha.setText(""); cVSenha.setText("");
                }
            }catch (Exception e){
                System.out.println("Erro Cadastro de User");
                e.printStackTrace();
            }
        }
    } 
    
     public void completaCampos(){
        cNome.setText(AlteraClientePrincipal.cliente.getNome());
        cCPF.setText(AlteraClientePrincipal.cliente.getCpf());
        cEmail.setText(AlteraClientePrincipal.cliente.getEmail());
        cTelefone.setText(AlteraClientePrincipal.cliente.getTelefone());
        cLogin.setText(AlteraClientePrincipal.cliente.getLogin());
        cSenha.setText(AlteraClientePrincipal.cliente.getSenha());
        cVSenha.setText(AlteraClientePrincipal.cliente.getSenha());
     }
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    completaCampos();
    }    
    
}
