/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Carro;
import static Principal.CadCarroPrincipal.sCadCarro;
import static java.lang.Double.parseDouble;
import static java.lang.Integer.parseInt;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import jdbc.CarroDAO;

/**
 * FXML Controller class
 *
 * @author patrick
 */
public class CadCarroController implements Initializable {

    @FXML private TextField cModelo;
    @FXML private TextField cAno;
    @FXML private TextField cMarca;
    @FXML private TextField cKm;
    @FXML private TextField cPlaca;
    
    
    
    public void cad(){
        int cont = 0;
        int v = 0;
        CarroDAO dao = new CarroDAO();
        ObservableList<Carro> car = dao.retornaCarro();
   if(cModelo.getText().equals("")||cAno.getText().equals("")||cMarca.getText().equals("")||
      cPlaca.getText().equals("")||cKm.getText().equals("")){
        Alert c = new Alert(Alert.AlertType.ERROR);
        c.setTitle("ATENÇÃO");
        c.setHeaderText("Campos vazios");
        c.setContentText("Por favor, Preencha todos os Campos!!");
        c.showAndWait();       
   } else{
            try{
                Carro c = new Carro();
                c.setModelo(cModelo.getText());     
                c.setMarca(cMarca.getText());
                c.setAno(parseInt(cAno.getText()));
                c.setKm(parseDouble(cKm.getText()));
                
                int y = car.size();               
                if(y==0){
                    c.setPlaca(cPlaca.getText()); 
                    dao.insereCarro(c);                
            Alert a = new Alert(Alert.AlertType.CONFIRMATION);
            a.setTitle("VERIFICAÇÃO");
            a.setContentText("Carro Registrado com Sucesso!!");
            a.showAndWait();
            sCadCarro.close();
                }else{
               for(int x = 0;x<car.size();x++){               
                if(car.get(x).getPlaca().equals(cPlaca.getText())) { 
                    Alert a = new Alert(Alert.AlertType.WARNING);
                    a.setTitle("VERIFICAÇÃO DE CADASTRO");
                    a.setHeaderText("Erro com a Placa");
                    a.setContentText("A Placa Digitada já Existe");
                    a.showAndWait(); 
                    v=1;
                    x=y+1; 
                      cModelo.setText(""); cMarca.setText(""); cAno.setText(""); 
            cPlaca.setText(""); cKm.setText("");         
                }else{
                 cont = 1;
                    } 
                    }
               if(cont>0&&v==0){
               c.setPlaca(cPlaca.getText()); 
                dao.insereCarro(c);                
            Alert a = new Alert(Alert.AlertType.CONFIRMATION);
            a.setTitle("VERIFICAÇÃO");
            a.setContentText("Carro Registrado com Sucesso!!");
            a.showAndWait();
            sCadCarro.close();
               }
                }
            }catch (Exception e){
                System.out.println("Erro Cadastro de Carro");
                e.printStackTrace();
            }
          }
       }
     
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    
    
}
