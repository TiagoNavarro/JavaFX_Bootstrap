/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Cliente;
import static Principal.CadClientePrincipal.sCadCliente;
import static java.lang.Double.parseDouble;
import static java.lang.Integer.parseInt;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import jdbc.ClienteDAO;

/**
 * FXML Controller class
 *
 * @author patrick
 */
public class CadClienteController implements Initializable {

   @FXML TextField cNome;
   @FXML TextField cCPF;
   @FXML TextField cEmail;
   @FXML TextField cTelefone;
   @FXML TextField cLogin;
   @FXML TextField cSenha;
   @FXML TextField cVSenha;
   
   public void cad(){
       int cont = 0;
        int v = 0;
        ClienteDAO dao = new ClienteDAO();
        ObservableList<Cliente> cl = dao.retornaCliente();
   if(cNome.getText().equals("")||cCPF.getText().equals("")||cEmail.getText().equals("")||cTelefone.getText().equals("")||
      cLogin.getText().equals("")||cSenha.getText().equals("")||cVSenha.getText().equals("")){
        Alert c = new Alert(Alert.AlertType.ERROR);
        c.setTitle("ATENÇÃO");
        c.setHeaderText("Campos vazios");
        c.setContentText("Por favor, Preencha todos os Campos!!");
        c.showAndWait();       
   } else{
            try{
                Cliente u = new Cliente();
                u.setNome(cNome.getText());     
              
                int y = cl.size();               
                if(y==0){
                    u.setCpf(cCPF.getText()); 
                    dao.insereCliente(u);                
            Alert a = new Alert(Alert.AlertType.CONFIRMATION);
            a.setTitle("VERIFICAÇÃO");
            a.setContentText("Cliente Cadastrado com Sucesso!!");
            a.showAndWait();
            sCadCliente.close();
                }else{
               for(int x = 0;x<cl.size();x++){              
                if(cl.get(x).getCpf().equals(cCPF.getText())) { 
                    Alert a = new Alert(Alert.AlertType.WARNING);
                    a.setTitle("VERIFICAÇÃO DE CADASTRO");
                    a.setHeaderText("Erro com o CPF");
                    a.setContentText("O CPF Digitado já Existe");
                    a.showAndWait(); 
                    v=1;
                    x=y+1; 
                cNome.setText(""); cCPF.setText(""); cEmail.setText("");
                cTelefone.setText(""); cLogin.setText(""); cSenha.setText("");
                cVSenha.setText("");
                }else{
                 cont = 1;
                    } 
                    }
                }
               if(cont>0&&v==0){
                u.setCpf(cCPF.getText()); 
                u.setEmail(cEmail.getText());
                u.setTelefone(cTelefone.getText());                
                u.setLogin(cLogin.getText());
                if(cSenha.getText().equals(cVSenha.getText())){
                u.setSenha(cSenha.getText());
                dao.insereCliente(u);                
            Alert c = new Alert(Alert.AlertType.CONFIRMATION);
            c.setTitle("VERIFICAÇÃO");
            c.setContentText("Usuário Cadastrado com Sucesso!!");
            c.showAndWait();
            sCadCliente.close();
                }else{
                  Alert c = new Alert(Alert.AlertType.ERROR);
            c.setTitle("ATENÇÃO");
            c.setHeaderText("Campos Incorretos");
            c.setContentText("Por favor, Verifique a sua Senha!!");
            c.showAndWait();  
            cNome.setText(""); cCPF.setText(""); cEmail.setText(""); cTelefone.setText("");
            cLogin.setText(""); cSenha.setText(""); cVSenha.setText("");
                }
               }
                
            }catch (Exception e){
                System.out.println("Erro Cadastro de User");
                e.printStackTrace();
            }
    }
   }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
