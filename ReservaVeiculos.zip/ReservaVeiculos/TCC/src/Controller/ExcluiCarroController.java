/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Carro;
import Principal.ExcluirCarroPrincipal;
import static Principal.ExcluirCarroPrincipal.sExcluirCarro;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import jdbc.CarroDAO;

/**
 * FXML Controller class
 *
 * @author patrick
 */
public class ExcluiCarroController implements Initializable {

    @FXML Label lbCarro;
    @FXML Label lbPlaca;
    
    public void sim(){
        CarroDAO dao = new CarroDAO();
        dao.deletaCarro(ExcluirCarroPrincipal.carro);
         Alert a = new Alert(Alert.AlertType.INFORMATION);
            a.setTitle("VERIFICAÇÃO DE EXCLUSÃO");
            a.setHeaderText("Campo selecionado corretamente");
            a.setContentText("OK, Carro Excluido!");
            a.showAndWait();
            sExcluirCarro.close();
    }
    public void nao(){
        sExcluirCarro.close();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        lbCarro.setText(ExcluirCarroPrincipal.carro.getModelo());
        lbPlaca.setText(ExcluirCarroPrincipal.carro.getPlaca());
    }    
    
}
