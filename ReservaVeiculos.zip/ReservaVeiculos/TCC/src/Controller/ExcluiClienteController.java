/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Principal.ExcluirClientePrincipal;
import static Principal.ExcluirClientePrincipal.sExcluirCliente;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import jdbc.ClienteDAO;

/**
 * FXML Controller class
 *
 * @author patrick
 */
public class ExcluiClienteController implements Initializable {

    @FXML Label lbCliente;
    @FXML Label lbCpf;
    
    public void sim(){
        ClienteDAO dao = new ClienteDAO();
        dao.deletaCliente(ExcluirClientePrincipal.cliente);
         Alert a = new Alert(Alert.AlertType.INFORMATION);
            a.setTitle("VERIFICAÇÃO DE EXCLUSÃO");
            a.setHeaderText("Campo selecionado corretamente");
            a.setContentText("OK, Cliente Excluido!");
            a.showAndWait();
            sExcluirCliente.close();
    }
    public void nao(){
        sExcluirCliente.close();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        lbCliente.setText(ExcluirClientePrincipal.cliente.getNome());
        lbCpf.setText(ExcluirClientePrincipal.cliente.getCpf());
    }    
    
}
