/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Cliente;
import Principal.AdmPrincipal;
import static Principal.LoginPrincipal.sLogin;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import jdbc.ClienteDAO;

/**
 * FXML Controller class
 *
 * @author patrick
 */
public class LoginController implements Initializable {

   @FXML TextField cLogin;
   @FXML PasswordField cSenha;
   
   public void sair(){
       sLogin.close();
   }
   
   public void entrar(){           
            if(cLogin.getText().equals("admin")&&cSenha.getText().equals("admin")){
                Alert a = new Alert(Alert.AlertType.CONFIRMATION);
                      a.setTitle("VERIFICAÇÃO DE LOGIN");
                      a.setHeaderText("Campos Digitados corretamente");
                      a.setContentText("Login e Senha Corretos");
                      a.showAndWait(); 
                AdmPrincipal abre = new AdmPrincipal();
                try {
                    abre.start(new Stage());
                } catch (Exception ex) {
                    Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
                    }     
                sLogin.close();
            }else{
            Alert a = new Alert(Alert.AlertType.ERROR);
            a.setTitle("VERIFICAÇÃO DE LOGIN");
            a.setHeaderText("Erro nos Campos Digitados");
            a.setContentText("Login e/ou Senha Incorretos");
            a.showAndWait();                         
            cLogin.setText(""); cSenha.setText("");
                }     
    }   
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
