/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Reserva;
import static Principal.ReservaTotalPrincipal.sReservaTotal;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import jdbc.ReservaDAO;

/**
 * FXML Controller class
 *
 * @author patrick
 */
public class ReservaTotalController implements Initializable {

    private static Reserva sReserva;
    
   @FXML TableView<Reserva> tbAgenda;
   @FXML TableColumn<Reserva, Integer> cId_reserva;
   @FXML TableColumn<Reserva, String> cPlacaAg;
   @FXML TableColumn<Reserva, String> cCpfAg;
   @FXML TableColumn<Reserva, String> cDestino;
   @FXML TableColumn<Reserva, String> cServico;
   @FXML TableColumn<Reserva, String> cData_reserva;
   @FXML TableColumn<Reserva, String> cHr_reserva;
   @FXML TableColumn<Reserva, String> cHr_retorno;
    
   public void fechar(){
       sReservaTotal.close();
   }
   
    ObservableList<Reserva> reserva = FXCollections.observableArrayList();
   public void atualizaTabelaAgenda() {
        ReservaDAO dao = new ReservaDAO();
        reserva = dao.retornaReservaTotal();
        tbAgenda.setItems(reserva);        
        tbAgenda.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                if (newValue != null) {
                    sReserva = (Reserva) newValue;
                } else {
                    sReserva = null;
                }
            }
        });        
    }
    public void preencheTabelaAgenda() {
        cId_reserva.setCellValueFactory(new PropertyValueFactory("id_reserva"));
        cPlacaAg.setCellValueFactory(new PropertyValueFactory("placa"));
        cCpfAg.setCellValueFactory(new PropertyValueFactory("cpf"));
        cDestino.setCellValueFactory(new PropertyValueFactory("destino"));
        cServico.setCellValueFactory(new PropertyValueFactory("servico"));
        cData_reserva.setCellValueFactory(new PropertyValueFactory("data_reserva"));
        cHr_reserva.setCellValueFactory(new PropertyValueFactory("hr_reserva"));        
        cHr_retorno.setCellValueFactory(new PropertyValueFactory("hr_retorno"));        
        ReservaDAO dao = new ReservaDAO();
        reserva = dao.retornaReservaTotal();
        tbAgenda.setItems(reserva);
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        atualizaTabelaAgenda();
        preencheTabelaAgenda();
    }    
    
}
