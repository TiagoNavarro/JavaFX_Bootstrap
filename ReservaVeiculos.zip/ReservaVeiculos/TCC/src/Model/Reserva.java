/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author patrick
 */
public class Reserva {
    private int id_reserva;
    private String placa;
    private String cpf;
    private String destino;
    private String servico;
    private String data_reserva;
    private String hr_reserva;
    private String hr_retorno;

    public Reserva() {
    }

    public Reserva(int id_reserva, String placa, String cpf, String destino, String servico, String data_reserva, String hr_reserva, String hr_retorno) {
        this.id_reserva = id_reserva;
        this.placa = placa;
        this.cpf = cpf;
        this.destino = destino;
        this.servico = servico;
        this.data_reserva = data_reserva;
        this.hr_reserva = hr_reserva;
        this.hr_retorno = hr_retorno;
    }

    public int getId_reserva() {
        return id_reserva;
    }

    public void setId_reserva(int id_reserva) {
        this.id_reserva = id_reserva;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public String getServico() {
        return servico;
    }

    public void setServico(String servico) {
        this.servico = servico;
    }

    public String getData_reserva() {
        return data_reserva;
    }

    public void setData_reserva(String data_reserva) {
        this.data_reserva = data_reserva;
    }

    public String getHr_reserva() {
        return hr_reserva;
    }

    public void setHr_reserva(String hr_reserva) {
        this.hr_reserva = hr_reserva;
    }

    public String getHr_retorno() {
        return hr_retorno;
    }

    public void setHr_retorno(String hr_retorno) {
        this.hr_retorno = hr_retorno;
    }
    
}
