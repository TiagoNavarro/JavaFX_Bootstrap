/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

import Model.Carro;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author patrick
 */
public class AlteraCarroPrincipal {
public static Stage sAlteraCarro;
public static Carro carro;

    public AlteraCarroPrincipal(){
    }

    public AlteraCarroPrincipal(Carro c) {
        AlteraCarroPrincipal.carro = c;
    }
    
    
    
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/View/alteraCarro.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Alterar Cliente");
        stage.show();
        sAlteraCarro=stage;
    }
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
