/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

import Model.Carro;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author patrick
 */
public class ExcluirCarroPrincipal {
public static Stage sExcluirCarro;
public static Carro carro;

    public ExcluirCarroPrincipal(){
    }

    public ExcluirCarroPrincipal(Carro c) {
        ExcluirCarroPrincipal.carro = c;
    }
    
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/View/excluiCarro.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Excluir");
        stage.show();
        sExcluirCarro=stage;
    }
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
