/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

import Model.Cliente;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author patrick
 */
public class ExcluirClientePrincipal {
public static Stage sExcluirCliente;
public static Cliente cliente;

    public ExcluirClientePrincipal(){
    }

    public ExcluirClientePrincipal(Cliente c) {
        ExcluirClientePrincipal.cliente = c;
    }
    
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/View/excluiCliente.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Excluir");
        stage.show();
        sExcluirCliente=stage;
    }
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
