/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

import Model.Carro;
import static java.lang.Double.parseDouble;
import static java.lang.Integer.parseInt;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author patrick
 */
public class CarroDAO {
    
        private Connection c = ConnectionFactory.getConnection();
    
    public void insereCarro(Carro ca){
    String sql = "INSERT INTO carro (modelo, marca, ano, placa, km) "
            +"VALUES (?,?,?,?,?);";
    PreparedStatement stmt ;
    try{
            stmt = c.prepareStatement(sql);            
            stmt.setString(1, ca.getModelo());            
            stmt.setString(2, ca.getMarca());                        
            stmt.setInt(3, ca.getAno());
            stmt.setString(4, ca.getPlaca());            
            stmt.setDouble(5, ca.getKm());
            stmt.execute(); 
            stmt.close();
        }catch(SQLException e){
            System.out.println("Deu Erro CarroDAO: "+e.getMessage());
        }
    }
    
     public void deletaCarro(Carro car){
        String sql = "DELETE FROM carro WHERE placa = ?";
        PreparedStatement stmt;
        try{
            stmt = c.prepareStatement(sql);
            stmt.setString(1, car.getPlaca());
            stmt.execute();
            stmt.close();
        }catch(SQLException e){
           System.out.println("Erro Deletar Carro: ");
               e.printStackTrace();
        }
    }
    
    public void atualizaCarro(Carro ca){
    String sql = "UPDATE carro SET modelo=?, marca=?, ano=?, km=? WHERE placa=?";
    PreparedStatement stmt ;
    try{
            stmt = c.prepareStatement(sql);   
            stmt.setString(1, ca.getModelo());            
            stmt.setString(2, ca.getMarca());                        
            stmt.setInt(3, ca.getAno());
            stmt.setDouble(4, ca.getKm());
            stmt.setString(5, ca.getPlaca());
            stmt.execute(); 
            stmt.close();
        }catch(SQLException e){
            System.out.println("Deu Erro CarroDAO: "+e.getMessage());
        }
    }
    
    public ObservableList<Carro> retornaCarro(){
        try{
            ObservableList<Carro> carro = FXCollections.observableArrayList();
            PreparedStatement stmt = this.c.prepareStatement("SELECT * FROM carro");
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Carro car = new Carro();
                car.setModelo(rs.getString("modelo"));
                car.setMarca(rs.getString("marca"));
                car.setAno(parseInt(rs.getString("ano")));
                car.setPlaca(rs.getString("placa"));
                car.setKm(parseDouble(rs.getString("km")));
            carro.add(car);
            }
            stmt.executeQuery();
            rs.close();
            stmt.close();
            return carro;
            }catch(SQLException e){
                throw new RuntimeException(e);
        }
    }
}
