/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

import Model.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author patrick
 */
public class ClienteDAO {
    
     private Connection c = ConnectionFactory.getConnection();
    
    public void insereCliente(Cliente cl){
    String sql = "INSERT INTO cliente (nome, cpf, email, telefone, login, senha) "
            +"VALUES (?,?,?,?,?,?);";
    PreparedStatement stmt ;
    try{
            stmt = c.prepareStatement(sql);            
            stmt.setString(1, cl.getNome());            
            stmt.setString(2, cl.getCpf());                        
            stmt.setString(3, cl.getEmail());
            stmt.setString(4, cl.getTelefone());            
            stmt.setString(5, cl.getLogin());
            stmt.setString(6, cl.getSenha());
            stmt.execute(); 
            stmt.close();
        }catch(SQLException e){
            System.out.println("Deu Erro UserDAO: "+e.getMessage());
        }
    }
    
    public void atualizaCliente(Cliente cl){
    String sql = "UPDATE cliente SET nome=?, email=?, telefone=?, login=?, senha=? WHERE cpf=?";
    PreparedStatement stmt ;
    try{
            stmt = c.prepareStatement(sql);   
            stmt.setString(1, cl.getNome());                                              
            stmt.setString(2, cl.getEmail());
            stmt.setString(3, cl.getTelefone());            
            stmt.setString(4, cl.getLogin());
            stmt.setString(5, cl.getSenha());
            stmt.setString(6, cl.getCpf());  
            stmt.execute(); 
            stmt.close();
        }catch(SQLException e){
            System.out.println("Deu Erro UserDAO: "+e.getMessage());
        }
    }
    
    public ObservableList<Cliente> retornaCliente(){
        try{
            ObservableList<Cliente> us = FXCollections.observableArrayList();
            PreparedStatement stmt = this.c.prepareStatement("SELECT * FROM cliente");
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Cliente u = new Cliente();
                u.setNome(rs.getString("nome"));
                u.setCpf(rs.getString("cpf"));
                u.setEmail(rs.getString("email"));
                u.setTelefone(rs.getString("telefone"));
                u.setLogin(rs.getString("login"));
                u.setSenha(rs.getString("senha"));         
            us.add(u);
            }
            stmt.executeQuery();
            rs.close();
            stmt.close();
            return us;
            }catch(SQLException e){
                throw new RuntimeException(e);
        }
    }
    
    public void deletaCliente(Cliente cl){
        String sql = "DELETE FROM cliente WHERE cpf = ?";
        PreparedStatement stmt;
        try{
            stmt = c.prepareStatement(sql);
            stmt.setString(1, cl.getCpf());
            stmt.execute();
            stmt.close();
        }catch(SQLException e){
           System.out.println("Erro Deletar Carro: ");
               e.printStackTrace();
        }
    }
    
}
