package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory{
    
    public static Connection getConnection(){     
     Connection c = null;
     try{
         c = DriverManager.getConnection("jdbc:postgresql://localhost/reservaveiculo", "postgres", "12345");
     }catch(SQLException e){
         System.out.println("Não Fumego: ConnectionFactory");
         e.printStackTrace();
     }
        
     return c;
    }  
}