/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

import Model.Devolver;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author patrick
 */
public class DevolverDAO {
    
    private Connection con = ConnectionFactory.getConnection();
    
     public void Cadastra(Devolver devolver) {
        String sql = "Insert into devolver (id_reserva, gastos, obs, km_d)"
                + " values (?,?,?,?) ";
        try {
            PreparedStatement st = con.prepareStatement(sql);
            Double km;
            Double km_a = devolver.getKm();
            Double km_d = devolver.getKm_d();
            km = km_d - km_a;
            
            st.setInt(1, devolver.getId_reserva());
            st.setString(2, devolver.getGastos());
            st.setString(3, devolver.getObs());
            st.setDouble(4, km);
            st.execute();
            con.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
     
     public ObservableList<Devolver> retornaDev(){
        String sql = "SELECT * FROM devolver";
        ObservableList<Devolver> d = FXCollections.observableArrayList();
        try{
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Devolver r = new Devolver();
                r.setId_devolve(rs.getInt("id_devolver"));
                r.setId_reserva(rs.getInt("id_reserva"));
                r.setGastos(rs.getString("gastos"));                
                r.setObs(rs.getString("obs"));
                r.setKm_d(rs.getDouble("km_d"));
                d.add(r);
            }
            return d;
        }catch(SQLException e){
            e.printStackTrace();
        }
        return null;
        }
}
