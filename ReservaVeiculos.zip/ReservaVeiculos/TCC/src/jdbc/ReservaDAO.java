/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

import Model.Reserva;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author patrick
 */
public class ReservaDAO {
    
         private Connection c = ConnectionFactory.getConnection();

    
    public ObservableList<Reserva> retornaReserva(){
        String sql = "SELECT * FROM reserva where devolucao = 0";
        ObservableList<Reserva> re = FXCollections.observableArrayList();
        try{
            PreparedStatement stmt = c.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Reserva r = new Reserva();
                r.setId_reserva(rs.getInt("id_reserva"));
                r.setPlaca(rs.getString("placa"));                
                r.setCpf(rs.getString("cpf"));
                r.setDestino(rs.getString("destino"));
                r.setServico(rs.getString("servico"));
                r.setData_reserva(rs.getString("data_reserva"));
                r.setHr_reserva(rs.getString("hr_reserva"));
                r.setHr_retorno(rs.getString("hr_retorno"));
                re.add(r);
            }
            return re;
        }catch(SQLException e){
            e.printStackTrace();
        }
        return null;
        }
    
    public ObservableList<Reserva> retornaReservaTotal(){
        String sql = "SELECT * FROM reserva";
        ObservableList<Reserva> re = FXCollections.observableArrayList();
        try{
            PreparedStatement stmt = c.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Reserva r = new Reserva();
                r.setId_reserva(rs.getInt("id_reserva"));
                r.setPlaca(rs.getString("placa"));                
                r.setCpf(rs.getString("cpf"));
                r.setDestino(rs.getString("destino"));
                r.setServico(rs.getString("servico"));
                r.setData_reserva(rs.getString("data_reserva"));
                r.setHr_reserva(rs.getString("hr_reserva"));
                r.setHr_retorno(rs.getString("hr_retorno"));
                re.add(r);
            }
            return re;
        }catch(SQLException e){
            e.printStackTrace();
        }
        return null;
        }
    
     public void deletaReserva(Reserva reserva){
        String sql = "DELETE FROM reserva WHERE id_reserva = ?";
        PreparedStatement stmt;
        try{
            stmt = c.prepareStatement(sql);
            stmt.setInt(1, reserva.getId_reserva());
            stmt.execute();
            stmt.close();
        }catch(SQLException e){
           System.out.println("Erro Deletar Reserva: ");
               e.printStackTrace();
        }
    }
    
}
