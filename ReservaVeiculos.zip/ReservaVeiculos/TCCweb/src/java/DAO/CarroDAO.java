/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import Model.Carro;
import jdbc_web.ConnectionFactory;

public class CarroDAO {

    private Connection con = ConnectionFactory.getConnection();

    public void Cadastra(Carro car) {
        String sql = "Insert into carro (modelo, marca, ano, placa, km)"
                + " values (?,?,?,?,?) ";
        try {
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, car.getModelo());
            st.setString(2, car.getMarca());
            st.setInt(3, car.getAno());
            st.setString(4, car.getPlaca());
            st.setDouble(5, car.getKm());
            st.execute();
            con.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    
         public void atualizaKm(String placa, Double km){
             String sql = "update carro set km=?  where placa = ? ";
             
             try{
                 PreparedStatement st = con.prepareStatement(sql);
                 st.setDouble(1, km);
                 st.setString(2, placa);                 
                 st.execute();
                 st.close();
             }catch(SQLException e){
                 throw new RuntimeException(e);
             }
         }
    
     public Carro pegaKm(String carro){
            String sql = "SELECT * FROM carro WHERE placa=?";
            try{
                PreparedStatement stmt = con.prepareStatement(sql);
                stmt.setString(1, carro);
                ResultSet rs = stmt.executeQuery();
                rs.next();
                Carro c = new Carro();
                c.setKm(rs.getDouble("km"));
                return c;
            } catch (Exception e){
                e.printStackTrace();
            }
            return null;
        }
    
        public ArrayList<Carro> retornaCarro() throws SQLException{
        String sql = "SELECT * FROM carro";
        ArrayList<Carro> car = new ArrayList<Carro>();
        try{
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Carro carro = new Carro();
                carro.setModelo(rs.getString("modelo"));
                carro.setMarca(rs.getString("marca"));                
                carro.setAno(rs.getInt("ano"));
                carro.setPlaca(rs.getString("placa"));
                carro.setKm(rs.getDouble("km"));
                car.add(carro);
            }
            return car;
        }catch(SQLException e){
            e.printStackTrace();
        }
        return null;
        }
        
        public Carro pegaPlaca(String placa){
            String sql = "SELECT * FROM carro WHERE placa=?";
            try{
                PreparedStatement stmt = con.prepareStatement(sql);
                stmt.setString(1, placa);
                ResultSet rs = stmt.executeQuery();
                rs.next();
                Carro car = new Carro();
                car.setModelo(rs.getString("modelo"));
                car.setMarca(rs.getString("marca"));
                car.setAno(rs.getInt("ano"));
                car.setPlaca(rs.getString("placa"));
                car.setKm(rs.getDouble("km"));
                return car;
            } catch (Exception e){
                e.printStackTrace();
            }
            return null;
        }
        
        public void remove(Carro car) {
        try {
            PreparedStatement st = con.prepareStatement("delete from carro where placa =?");
            st.setString(1, car.getPlaca());
            st.execute();
            st.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

         public void altera(Carro car){
             String sql = "update carro set marca = ?, modelo =?, ano=?, km=?  where placa = ? ";
             
             try{
                 PreparedStatement st = con.prepareStatement(sql);
                 st.setString(1, car.getModelo());
                 st.setString(2, car.getMarca());                 
                 st.setInt(3, car.getAno());
                 st.setString(4, car.getPlaca());
                 st.setDouble(5,car.getKm());
                 st.execute();
                 st.close();
             }catch(SQLException e){
                 throw new RuntimeException(e);
             }
         }
}