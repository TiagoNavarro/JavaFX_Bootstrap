package DAO;

import static java.lang.Integer.parseInt;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import Model.Cliente;
import jdbc_web.ConnectionFactory;

public class ClienteDAO {
    
    private final Connection con = ConnectionFactory.getConnection();
    
    public Cliente verLogin(String login,String senha){
        String sql = "select * from cliente where login=? and senha=? ";
      try{
        Cliente cl = new Cliente();
            try (PreparedStatement stmt = con.prepareStatement(sql)) {
                stmt.setString(1, login);
                stmt.setString(2, senha);
            try (ResultSet rs = stmt.executeQuery()) {
                while(rs.next()){
                    cl.setNome(rs.getString("nome"));
                    cl.setCpf(rs.getString("cpf"));
                    cl.setEmail(rs.getString("email"));
                    cl.setTelefone(rs.getString("telefone"));
                    cl.setLogin(rs.getString("login"));
                    cl.setSenha(rs.getString("senha"));
                    return cl;
                }
                stmt.executeQuery();
            }
            }
      } catch(Exception e){
          e.printStackTrace();
      }
      return null;
    } 
    
    
        public ArrayList<Cliente> retornaCliente() throws SQLException{
       
            String sql = "SELECT * FROM cliente";
        ArrayList<Cliente> cliente = new ArrayList<Cliente>();
        try{
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Cliente cl = new Cliente();
                cl.setNome(rs.getString("nome"));
                cl.setLogin(rs.getString("login"));
                cl.setSenha(rs.getString("senha"));
                cl.setCpf(rs.getString("cpf"));
                cl.setTelefone(rs.getString("Telefone"));
                cl.setEmail(rs.getString("email"));
                cliente.add(cl);
            }
            return cliente;
        }catch(SQLException e){
            e.printStackTrace();
            throw new RuntimeException(e);
        }
        }
                 
    }