/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Reserva;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import jdbc_web.ConnectionFactory;

/**
 *
 * @author patrick
 */
public class ReservaDAO {
     private final Connection con = ConnectionFactory.getConnection();
     
     public String pegaPlaca(int id){
            String sql = "SELECT placa FROM reserva WHERE id_reserva=?";
            try{
                PreparedStatement stmt = con.prepareStatement(sql);
                stmt.setInt(1, id);
                ResultSet rs = stmt.executeQuery();
                rs.next();
                String placa;
                Reserva re = new Reserva();
                re.setPlaca(rs.getString("placa"));
                placa = re.getPlaca();
                return placa;
            } catch (Exception e){
                e.printStackTrace();
            }
            return null;
        }     
     
     public void fezDevolucao(int id){
         String sql = "update reserva set devolucao=1 where id_reserva=?";
         try{
             PreparedStatement st = con.prepareStatement(sql);
             Reserva r = new Reserva();
             st.setInt(1, id);
             st.execute();
             con.close();
         }catch(SQLException e){
            throw new RuntimeException(e);
         }
     }
     
     public Reserva verReserva(String placa, String dt){
            String sql = "SELECT * FROM reserva WHERE placa=? and data_reserva=?";
            try{
                PreparedStatement stmt = con.prepareStatement(sql);
                stmt.setString(1, placa);
                stmt.setString(2, dt);
                ResultSet rs = stmt.executeQuery();
                rs.next();
                Reserva re = new Reserva();
                re.setId_reserva(rs.getInt("id_reserva"));
                return re;
            } catch (Exception e){
                e.printStackTrace();
            }
            return null;
        }
     
     public void fazerReserva(Reserva reserva) {

        String sql = "Insert into reserva (placa, cpf, destino, servico, data_reserva, hr_reserva, hr_retorno, devolucao)"
                + " values (?,?,?,?,?,?,?,?) ";

        try {
            PreparedStatement st = con.prepareStatement(sql);

            st.setString(1, reserva.getPlaca());
            st.setString(2, reserva.getCpf());
            st.setString(3, reserva.getDestino());
            st.setString(4, reserva.getServico());
            st.setString(5, reserva.getData_reserva());
            st.setString(6, reserva.getHr_reserva());
            st.setString(7, reserva.getHr_retorno());
            st.setInt(8, reserva.getDevolucao());
            st.execute();
            con.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
     
     public Reserva pegaReserva(String reserva){
            String sql = "SELECT * FROM reserva WHERE cpf=? and devolucao=0";
            try{
                PreparedStatement stmt = con.prepareStatement(sql);
                stmt.setString(1, reserva);
                ResultSet rs = stmt.executeQuery();
                rs.next();
                Reserva re = new Reserva();
                re.setId_reserva(rs.getInt("id_reserva"));
                re.setPlaca(rs.getString("placa"));
                re.setCpf(rs.getString("cpf"));
                re.setDestino(rs.getString("destino"));
                re.setServico(rs.getString("servico"));
                re.setData_reserva(rs.getString("data_reserva"));
                re.setHr_reserva(rs.getString("hr_reserva"));
                re.setHr_retorno(rs.getString("hr_retorno"));
                return re;
            } catch (Exception e){
                e.printStackTrace();
            }
            return null;
        }
   
     public ArrayList<Reserva> retornaReserva() throws SQLException{
        String sql = "SELECT * FROM reserva where devolucao=0";
        ArrayList<Reserva> re = new ArrayList<Reserva>();
        try{
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Reserva r = new Reserva();
                r.setId_reserva(rs.getInt("id_reserva"));
                r.setPlaca(rs.getString("placa"));                
                r.setCpf(rs.getString("cpf"));
                r.setDestino(rs.getString("destino"));
                r.setServico(rs.getString("servico"));
                r.setData_reserva(rs.getString("data_reserva"));
                r.setHr_reserva(rs.getString("hr_reserva"));
                r.setHr_retorno(rs.getString("hr_retorno"));
                re.add(r);
            }
            return re;
        }catch(SQLException e){
            e.printStackTrace();
        }
        return null;
        }
     
}
