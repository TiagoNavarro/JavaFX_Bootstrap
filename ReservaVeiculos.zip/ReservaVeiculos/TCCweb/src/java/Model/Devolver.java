/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author patrick
 */
public class Devolver {
    private int id_devolve;
    private int id_reserva;
    private String gastos;
    private String obs;
    private Double km;
    private Double km_d;

    public Devolver() {
    }

    public Devolver(int id_devolve, int id_reserva, String gastos, String obs, Double km, Double km_d) {
        this.id_devolve = id_devolve;
        this.id_reserva = id_reserva;
        this.gastos = gastos;
        this.obs = obs;
        this.km = km;
        this.km_d = km_d;
    }

    public int getId_devolve() {
        return id_devolve;
    }

    public void setId_devolve(int id_devolve) {
        this.id_devolve = id_devolve;
    }

    public int getId_reserva() {
        return id_reserva;
    }

    public void setId_reserva(int id_reserva) {
        this.id_reserva = id_reserva;
    }

    public String getGastos() {
        return gastos;
    }

    public void setGastos(String gastos) {
        this.gastos = gastos;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }

    public Double getKm() {
        return km;
    }

    public void setKm(Double km) {
        this.km = km;
    }
    
    public Double getKm_d() {
        return km_d;
    }

    public void setKm_d(Double km_d) {
        this.km_d = km_d;
    }
    
    
    
    
}
