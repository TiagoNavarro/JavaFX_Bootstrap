/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlet;

import DAO.ReservaDAO;
import Model.Reserva;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author patrick
 */
@WebServlet(name = "Fazer_Reserva", urlPatterns = {"/Fazer_Reserva"})
public class Fazer_Reserva extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ReservaDAO rdao = new ReservaDAO();   
        Reserva re = new Reserva();
        Reserva r = new Reserva();
        
        String placa = request.getParameter("nplaca"); 
        String data1 = request.getParameter("ndata_reserva");        
        LocalDate ld1 = LocalDate.parse(data1);
                int ano1 = ld1.getYear();
                int mes1 = ld1.getMonthValue();
                int dia1 = ld1.getDayOfMonth();
                String dt = dia1+"/"+mes1+"/"+ano1;   
                
        r = rdao.verReserva(placa, dt);
        
        if(r!=null){
            String mensagem = "Esse Carro já esta Reservado para este Dia.";
                request.setAttribute("mensagem", mensagem);
                RequestDispatcher rd = request.getRequestDispatcher("reserva_carro.jsp");
                rd.forward(request, response);
        }else{
            re.setPlaca(request.getParameter("nplaca"));
            re.setCpf(request.getParameter("ncpf"));
            re.setDestino(request.getParameter("ndestino"));
            re.setServico(request.getParameter("nservico"));
        
        String data = request.getParameter("ndata_reserva");        
        LocalDate ld = LocalDate.parse(data);
                int ano = ld.getYear();
                int mes = ld.getMonthValue();
                int dia = ld.getDayOfMonth();        
            re.setData_reserva(dia+"/"+mes+"/"+ano);   
                
            re.setHr_reserva(request.getParameter("nhr_reserva"));
            re.setHr_retorno(request.getParameter("nhr_retorno"));
            re.setDevolucao(0);
            rdao.fazerReserva(re);
             String reCarro = "Carro Reservado com Sucesso.";
                request.setAttribute("fazerReserva", reCarro);
                RequestDispatcher rd = request.getRequestDispatcher("agenda.jsp");
                rd.forward(request, response);
           
        }
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
