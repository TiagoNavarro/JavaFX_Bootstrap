package DAO;

import JDBC.Connection_MVC;
import Model.Mensagem;
import Model.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class Mensagem_DAO
{
    public static Connection conexao_BD;
    
    public static ResultSet r;
    
    public static PreparedStatement st;
    
    public Mensagem_DAO()
    {
        Mensagem_DAO.conexao_BD = Connection_MVC.getConnection();
    }
    
    public ObservableList<Mensagem> select_Mensagem()
    {
        try{
           
            ObservableList<Mensagem> Msn = FXCollections.observableArrayList();
            PreparedStatement stmt = this.conexao_BD.prepareStatement("SELECT * FROM Informacoes_Mensagem");
   
            ResultSet rs = stmt.executeQuery();
            
            r = rs;
            st = stmt;
            
            while(rs.next()){
 
                Mensagem mensagem = new Mensagem();
                
                mensagem.setId_mensagem(rs.getInt("id_mensagem"));
                mensagem.setNome_emissor(rs.getString("login_emissor"));
                mensagem.setNome_receptor(rs.getString("login_receptor"));
                mensagem.setData_envio(rs.getDate("data_envio").toLocalDate());
                mensagem.setConteudo_mensagem(rs.getString("conteudo_mensagem"));
                   
                Msn.add( mensagem );
                
            }
  
            stmt.executeQuery();
            
            return Msn;
            
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public void delete_Mensagem(Mensagem mensagem)
    {
        String sql = "DELETE FROM Mensagens WHERE id_mensagem = ?";
        try{
            PreparedStatement stmt = conexao_BD.prepareStatement(sql);
            stmt.setInt(1, mensagem.getId_mensagem());
            stmt.execute();
            stmt.close();
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
    }
    
}
