package DAO;

import JDBC.Connection_MVC;
import Model.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class Produto_DAO
{
    public static Connection conexao_BD;
    
    public static ResultSet r;
    
    public static PreparedStatement st;
    
    public Produto_DAO()
    {
        Produto_DAO.conexao_BD = Connection_MVC.getConnection();
    }
    
    public ObservableList<Produto> select_Produto()
    {
        try{
           
            ObservableList<Produto> Prod = FXCollections.observableArrayList();
            //PreparedStatement stmt = this.conexao_BD.prepareStatement("SELECT * FROM Produtos ORDER BY id_produto DESC");
            PreparedStatement stmt = this.conexao_BD.prepareStatement(
                "SELECT * FROM Informacoes_Produto" 
                );
            
            ResultSet rs = stmt.executeQuery();
            
            r = rs;
            st = stmt;
            
            while(rs.next()){
 
                Produto produto = new Produto();
                
                produto.setId_produto(rs.getInt("id_produto"));
                produto.setNome_produto(rs.getString("nome_produto"));
                produto.setId_vendedor(rs.getInt("id_vendedor"));
                produto.setVendedor_produto(rs.getString("login"));
                produto.setId_categoria(rs.getInt("id_categoria"));
                produto.setCategoria_produto(rs.getString("nome_categoria"));
                produto.setPreco_produto(rs.getFloat("preco_produto"));
                produto.setData_postagem(rs.getDate("data_postagem").toLocalDate());
                produto.setNumero_favoritos(rs.getInt("num_favoritos"));
                produto.setDescricao_produto(rs.getString("descricao_produto"));
                produto.setFoto_1(rs.getString("foto_1"));
                produto.setFoto_2(rs.getString("foto_2"));
                produto.setFoto_3(rs.getString("foto_3"));
                
                Prod.add( produto );
                
            }
  
            stmt.executeQuery();
            
            return Prod;
            
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public void deleta_Produto(int id_produto)
    {
        String sql_favoritos = "DELETE FROM Favoritos WHERE id_produto = ?";
        String sql_produtos = "DELETE FROM Produtos WHERE id_produto = ?";
        
        try{
            PreparedStatement stmt = conexao_BD.prepareStatement(sql_favoritos);
            stmt.setInt( 1, id_produto );
            stmt.execute();
            
            stmt = conexao_BD.prepareStatement(sql_produtos);
            stmt.setInt(1, id_produto );
            stmt.execute();
            
            stmt.close();
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
    }
    
}
