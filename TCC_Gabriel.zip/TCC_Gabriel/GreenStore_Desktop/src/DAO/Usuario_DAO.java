package DAO;

import JDBC.Connection_MVC;
import Model.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class Usuario_DAO
{
    public static Connection conexao_BD;
    
    public static ResultSet r;
    
    public static PreparedStatement st;
    
    public Usuario_DAO()
    {
        Usuario_DAO.conexao_BD = Connection_MVC.getConnection();
    }
    
    public ObservableList<Usuario> select_Usuario()
    {
        try{
           
            ObservableList<Usuario> User = FXCollections.observableArrayList();
            PreparedStatement stmt = this.conexao_BD.prepareStatement("SELECT * FROM Informacoes_Usuario");
            
            ResultSet rs = stmt.executeQuery();
            
            r = rs;
            st = stmt;
            
            while(rs.next()){
 
                Usuario usuario = new Usuario();
                
                usuario.setId_usuario(rs.getInt("id_usuario"));
                usuario.setLogin(rs.getString("login"));
                usuario.setNome(rs.getString("nome"));
                usuario.setEmail(rs.getString("email"));
                usuario.setTelefone(rs.getInt("telefone"));
                usuario.setData_nascimento(rs.getDate("data_nascimento").toLocalDate());
                
                usuario.setPais(rs.getString("nome_pais"));
                
                usuario.setEstado(rs.getString("nome_estado"));
                
                usuario.setPergunta_seguranca(rs.getString("pergunta_seguranca"));
                
                usuario.setResposta_seguranca(rs.getString("resposta_seguranca"));
                usuario.setFoto_perfil(rs.getString("foto_perfil"));
                   
                User.add(usuario);
            }
  
            stmt.executeQuery();
                 
            return User;
            
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public void deleta_Usuario(Usuario usuario)
    {
        String sql_usuario = "DELETE FROM Usuarios WHERE id_usuario = ?";
        String sql_mensagens = "DELETE FROM Mensagens WHERE id_emissor = ?";
        String sql_produtos = "DELETE FROM Produtos WHERE id_vendedor = ?";
        String sql_favoritos = "DELETE FROM Favoritos WHERE id_usuario = ?";
        
        try{
            
            PreparedStatement stmt = conexao_BD.prepareStatement(sql_favoritos);
            stmt.setInt(1, usuario.getId_usuario());
            stmt.execute();
            
            stmt = conexao_BD.prepareStatement(sql_mensagens);
            stmt.setInt(1, usuario.getId_usuario());
            stmt.execute();
            
            stmt = conexao_BD.prepareStatement(sql_produtos);
            stmt.setInt(1, usuario.getId_usuario());
            stmt.execute();
            
            stmt = conexao_BD.prepareStatement(sql_usuario);
            stmt.setInt(1, usuario.getId_usuario());
            stmt.execute();
            
            stmt.close();
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
    }
    
}
