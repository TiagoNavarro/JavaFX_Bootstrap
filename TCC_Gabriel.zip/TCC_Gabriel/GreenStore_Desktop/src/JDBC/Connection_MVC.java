package JDBC;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class Connection_MVC
{
    public static String senha_db;
    
    public static Connection getConnection()
    {
        validacao_PC();
        
        Connection conexao_BD_POSTGREE = null;
        
        try{
            conexao_BD_POSTGREE = DriverManager.getConnection("jdbc:postgresql://localhost/greenstore_db", "postgres", senha_db);
        }catch(SQLException ex){
            System.out.println("azul " + ex.getMessage());
        }
        
        return conexao_BD_POSTGREE;
    }
    
    public static void validacao_PC()
    {
        String retorno = null;

        try {

            retorno = InetAddress.getLocalHost().getHostName();
            
            System.out.print( retorno );
            
            if(retorno.equals("User-PC"))
            {
                senha_db = "12345";
            }else if(retorno.equals("Gabriel-PC"))
            {
                senha_db = "12345";
            }else{
                senha_db = "12345";
            }    

        } catch (UnknownHostException ex) {

            Logger.getLogger(Connection_MVC.class.getName()).log(Level.SEVERE, null, ex);

        }
    }
}
