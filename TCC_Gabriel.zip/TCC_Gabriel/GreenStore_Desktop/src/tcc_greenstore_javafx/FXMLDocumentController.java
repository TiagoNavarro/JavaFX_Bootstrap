package tcc_greenstore_javafx;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.ImageCursor;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class FXMLDocumentController implements Initializable
{   
    //TextFields
    @FXML private TextField tf_login;
    
    //PasswordFields
    @FXML private PasswordField pf_senha;

    //Buttons
    @FXML public Button btn_logar;
    @FXML private Button btn_cancelar;
    
    //Stage - Tela Login
    @FXML public static Stage Tela_Login;
    
    //Imagem do Cursor
    Image image = new Image("imagens/icon.png");
       
    @FXML
    private void logar(ActionEvent event) throws Exception
    {
        if(tf_login.getText().equals("admin") && pf_senha.getText().equals("12345")){
            
            Alert a=new Alert(Alert.AlertType.INFORMATION);
                a.setHeaderText("Login realizado com sucesso!");
                a.showAndWait();
            
            Tela_Login.close();    
                
            FXML_Principal_Controller Tela_Home = new FXML_Principal_Controller();

            Tela_Home.start(new Stage());
                
        }else{
            
            Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Erro ao se logar, login e/ou senha incorretos!");
                a.showAndWait();
            
        }
        
    }
    
    @FXML
    private void cancelar(ActionEvent event)
    {
        Tela_Login.close();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
        btn_logar.setCursor(new ImageCursor(image));
        btn_cancelar.setCursor(new ImageCursor(image));
        
        btn_logar.getStyleClass().add("Buttons");
        btn_cancelar.getStyleClass().add("Buttons");      
    }     
}
