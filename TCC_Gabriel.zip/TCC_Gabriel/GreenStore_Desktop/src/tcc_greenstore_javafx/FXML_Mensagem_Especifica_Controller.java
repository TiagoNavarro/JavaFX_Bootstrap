package tcc_greenstore_javafx;

import DAO.Mensagem_DAO;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.collections.ListChangeListener;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.ImageCursor;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author <Gabriel Mello de Oliveira
 */

public class FXML_Mensagem_Especifica_Controller implements Initializable {

    public static String nome_emissor;
    public static String nome_receptor;
    public static LocalDate data_envio;
    public static String conteudo_mensagem;
    
    //TextFields
    @FXML private TextField tf_nome_emissor;
    @FXML private TextField tf_nome_receptor;
    @FXML private DatePicker dp_data_envio;
    @FXML private TextArea ta_conteudo_mensagem;
    
    //Buttons
    @FXML private Button btn_deletar;
    @FXML private Button btn_voltar;
    
    //Imagem do Cursor
    Image image_icon = new Image("imagens/icon.png");
    
    //Stage - Tela Login
    @FXML public static Stage Tela_Mensagem_Especifica;
    
    @FXML
    public void Deleta_Mensagem(ActionEvent event)
    {
        if(FXML_Mensagens_Controller.Mensagem_Selecionada != null){
                Mensagem_DAO DAO = new Mensagem_DAO();
                DAO.delete_Mensagem(FXML_Mensagens_Controller.Mensagem_Selecionada);
                
                Alert a=new Alert(Alert.AlertType.INFORMATION);
                a.setHeaderText("Mensagem deletada com sucesso!");
                a.showAndWait();
                
                Tela_Mensagem_Especifica.close();
        }else{
                Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Erro ao deletar a mensagem!");
                a.showAndWait();
        }
    }
    
    public void Voltar(){
        
        Tela_Mensagem_Especifica.close();
        
    }
    
    public void Preenche_Campos(){
        
        try{
            
            tf_nome_emissor.setText( nome_emissor );
            tf_nome_receptor.setText( nome_receptor );
            dp_data_envio.setValue( data_envio );
            ta_conteudo_mensagem.setText( conteudo_mensagem );
        
        }catch(Exception ex){
            
            Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Erro ao carregar informações específicas da mensagem! " + ex);
                a.showAndWait();
            
        }
        
    }
    
    public void start(Stage stage) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("FXML_Mensagem_Especifica.fxml"));        
        Scene scene = new Scene(root);      
        stage.setScene(scene);
        
        stage.setTitle("GreenStore - Mensagem");
        stage.getIcons().add(new Image("imagens/icon.png"));
        
        scene.getStylesheets().add("CSS/fxml_login.css");
        
        stage.show();
        
        Tela_Mensagem_Especifica = stage;
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btn_deletar.setCursor(new ImageCursor(image_icon));      
        btn_deletar.getStyleClass().add("Buttons");
        
        btn_voltar.setCursor(new ImageCursor(image_icon));      
        btn_voltar.getStyleClass().add("Buttons");
        
        Preenche_Campos();
    }    
    
}
