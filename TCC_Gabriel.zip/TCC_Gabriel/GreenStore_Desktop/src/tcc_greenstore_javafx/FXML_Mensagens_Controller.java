package tcc_greenstore_javafx;

import DAO.Mensagem_DAO;
import Model.Mensagem;
import Model.Usuario;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.ImageCursor;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author <Gabriel Mello de Oliveira
 */

public class FXML_Mensagens_Controller implements Initializable {

    @FXML private TableView <Mensagem> Tabela;
    
    @FXML private TableColumn <Mensagem, Integer> coluna_id;
    @FXML private TableColumn <Usuario, String> coluna_emissor;
    @FXML private TableColumn <Usuario, String> coluna_receptor;
    @FXML private TableColumn <Mensagem, String> coluna_data_envio;
    
    @FXML private ObservableList <Mensagem> Mensagem_OBList;
    
    //TextField - Pesquisar
    @FXML private TextField tf_pesquisar;
    
    @FXML private Button btn_voltar;
    
    @FXML public static Mensagem Mensagem_Selecionada;
    
    //Imagem do Cursor
    Image image = new Image("imagens/icon.png");
    
    //Stage - Tela Login
    @FXML public static Stage Tela_Mensagens;
    
    public void Preencher_Tabela_Mensagens()
    {     
        try{
        
            coluna_id.setCellValueFactory(new PropertyValueFactory( "id_mensagem" ));
            coluna_emissor.setCellValueFactory(new PropertyValueFactory( "nome_emissor" ));        
            coluna_receptor.setCellValueFactory(new PropertyValueFactory( "nome_receptor" ));
            coluna_data_envio.setCellValueFactory(new PropertyValueFactory( "data_envio" ));          

            Mensagem_DAO DAO = new Mensagem_DAO();
            Mensagem_OBList = DAO.select_Mensagem();
            Tabela.setItems(Mensagem_OBList);
        
        }catch(Exception ex){
            
            Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Erro ao carregar informações do Banco de Dados! " + ex);
                a.showAndWait();
            
        }    
    }
    
    @FXML
    public void Tela_Mensagem_Especifica(ActionEvent action) throws Exception
    {
        if(FXML_Mensagens_Controller.Mensagem_Selecionada != null)
        {       
            FXML_Mensagem_Especifica_Controller.nome_emissor = Mensagem_Selecionada.getNome_emissor();
                    
            FXML_Mensagem_Especifica_Controller.nome_receptor = Mensagem_Selecionada.getNome_receptor();
                    
            FXML_Mensagem_Especifica_Controller.data_envio = Mensagem_Selecionada.getData_envio();
                    
            FXML_Mensagem_Especifica_Controller.conteudo_mensagem = Mensagem_Selecionada.getConteudo_mensagem();
                            
            FXML_Mensagem_Especifica_Controller Tela_Mensagem_Especifica = new FXML_Mensagem_Especifica_Controller();   
                       
            Tela_Mensagem_Especifica.start(new Stage());
            
        }else{
                Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Por favor, selecione uma mensagem!");
                a.showAndWait();
        }
    }
    
    @FXML public void Voltar() throws Exception{
        
        Tela_Mensagens.close();
                
    }
    
    @FXML
    public void Pesquisar()
    {
        ObservableList<Mensagem> mens = FXCollections.observableArrayList();
        
        for (Mensagem Mensagem_OBList1 : Mensagem_OBList) {
            if (String.valueOf( Mensagem_OBList1.getId_emissor() ).contains(tf_pesquisar.getText()) 
                    || String.valueOf( Mensagem_OBList1.getId_receptor() ).contains(tf_pesquisar.getText())) {
                mens.add(Mensagem_OBList1);
            }
        }
        Tabela.setItems(mens);        
    }
    
    public void start(Stage stage) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("FXML_Mensagens.fxml"));        
        Scene scene = new Scene(root);      
        stage.setScene(scene);
        
        stage.setTitle("GreenStore - Mensagens");
        stage.getIcons().add(new Image("imagens/icon.png"));
        
        scene.getStylesheets().add("CSS/fxml_login.css");
        
        stage.show();
        
        Tela_Mensagens = stage;
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btn_voltar.setCursor(new ImageCursor(image));      
        btn_voltar.getStyleClass().add("Buttons");
        
        Preencher_Tabela_Mensagens();
        
        Tabela.getSelectionModel().selectedItemProperty().addListener(new ChangeListener()
        {
             @Override
             public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                 if(newValue != null){
                    FXML_Mensagens_Controller.Mensagem_Selecionada = (Mensagem) newValue;
                 }else{
                    FXML_Mensagens_Controller.Mensagem_Selecionada = null;
                 }
             }
         });
        
        tf_pesquisar.setOnKeyReleased((KeyEvent e)->{
             Pesquisar();
        });
        
    }    
    
}
