package tcc_greenstore_javafx;

import DAO.Produto_DAO;
import DAO.Usuario_DAO;
import Model.Produto;
import Model.Usuario;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.net.URL;
import java.sql.Date;
import java.util.Calendar;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javafx.application.Application.STYLESHEET_MODENA;
import static javafx.application.Application.setUserAgentStylesheet;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.ImageCursor;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author <Gabriel Mello de Oliveira
 */

public class FXML_Principal_Controller implements Initializable {

    @FXML private Button btn_usuarios;
    @FXML private Button btn_produtos;
    @FXML private Button btn_mensagens;
    @FXML private Button btn_emitir_PDF;
    
    //Imagem do Cursor
    Image image = new Image("imagens/icon.png");
    
    //Stage - Tela Login
    @FXML public static Stage Tela_Principal;
    
    @FXML public void Emitir_PDF(ActionEvent event)  throws FileNotFoundException, DocumentException{
        
        try{
            
            //Emissão do PDF 
            Usuario_DAO DAO_User = new Usuario_DAO();
            ObservableList<Usuario> user = DAO_User.select_Usuario();

            Produto_DAO DAO_Prod = new Produto_DAO();
            ObservableList<Produto> prod = DAO_Prod.select_Produto();

            Document doc = new Document();

            PdfWriter.getInstance(doc, new FileOutputStream("C:\\Users\\User\\Desktop\\Relatorio.pdf"));

            doc.open();

            doc.add(new Paragraph("Informações Cadastradas - Usuários:" + "\n" + user)); 

            doc.add(new Paragraph("Informações Cadastradas - Produtos:" + "\n" + prod)); 

            doc.close();
            
            Alert a=new Alert(Alert.AlertType.INFORMATION);
                a.setHeaderText("PDF emitido com sucesso!");
                a.showAndWait();
        
        }catch(Exception ex){
            
            Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Erro ao emitir o PDF! - " + ex);
                a.showAndWait();
            
        }
    }
    
    public void start(Stage stage) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("FXML_Principal.fxml"));        
        Scene scene = new Scene(root);      
        stage.setScene(scene);
        
        stage.setTitle("GreenStore - Principal");
        stage.getIcons().add(new Image("imagens/icon.png"));
        
        scene.getStylesheets().add("fxml_principal.css");
        
        scene.getStylesheets().add("CSS/fxml_login.css");
 
        stage.show();
        
        Tela_Principal = stage;
    }
    
    @FXML public static Date dataparaGravar = new Date(Calendar.getInstance().getTimeInMillis());
    @FXML private Label txt_data_atual;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        btn_usuarios.setCursor(new ImageCursor(image));
        btn_produtos.setCursor(new ImageCursor(image));
        btn_mensagens.setCursor(new ImageCursor(image));
        btn_emitir_PDF.setCursor(new ImageCursor(image));
        
        txt_data_atual.setText( "Data: " + dataparaGravar.toString() );
        
        System.out.println( dataparaGravar );
        
        btn_usuarios.setOnMouseClicked(new EventHandler<MouseEvent>(){
            @Override
            public void handle(MouseEvent event) {
                
                MouseButton button = event.getButton();
                if(button==MouseButton.PRIMARY){
                    
                    FXML_Usuarios_Controller Tela_Usuarios = new FXML_Usuarios_Controller();
        
                    try {
                        Tela_Usuarios.start(new Stage());
                    } catch (Exception ex) {
                        Logger.getLogger(FXML_Principal_Controller.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                }else{}
                
            }                 
        });
        
        btn_produtos.setOnMouseClicked(new EventHandler<MouseEvent>(){
            @Override
            public void handle(MouseEvent event) {
                
                MouseButton button = event.getButton();
                if(button==MouseButton.PRIMARY){
                    
                    FXML_Produtos_Controller Tela_Produtos = new FXML_Produtos_Controller();
        
                    try {
                        Tela_Produtos.start(new Stage());
                    } catch (Exception ex) {
                        Logger.getLogger(FXML_Principal_Controller.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                }else{}
                
            }                 
        });
        
        btn_mensagens.setOnMouseClicked(new EventHandler<MouseEvent>(){
            @Override
            public void handle(MouseEvent event) {
                
                MouseButton button = event.getButton();
                if(button==MouseButton.PRIMARY){
                    
                    FXML_Mensagens_Controller Tela_Mensagens = new FXML_Mensagens_Controller();
        
                    try {
                        Tela_Mensagens.start(new Stage());
                    } catch (Exception ex) {
                        Logger.getLogger(FXML_Principal_Controller.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                }else{}
                
            }                 
        });       
        
    }    
    
}
