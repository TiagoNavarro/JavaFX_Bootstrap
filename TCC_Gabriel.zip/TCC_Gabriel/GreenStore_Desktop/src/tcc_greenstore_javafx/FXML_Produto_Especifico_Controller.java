package tcc_greenstore_javafx;

import DAO.Produto_DAO;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author <Gabriel Mello de Oliveira
 */

public class FXML_Produto_Especifico_Controller implements Initializable {

    public static String nome_produto;
    public static String nome_vendedor;
    public static Float preco_produto;
    public static LocalDate data_postagem;
    public static String categoria_produto;
    public static int numero_favoritos;
    public static String descricao_produto;
    public static String foto_1;
    public static String foto_2;
    public static String foto_3;
    
    //TextFields
    @FXML private TextField tf_nome_produto;
    @FXML private TextField tf_nome_vendedor;
    @FXML private TextField tf_preco_produto;
    @FXML private DatePicker dp_data_postagem;
    @FXML private TextField tf_categoria_produto;
    @FXML private TextField tf_numero_favoritos;
    @FXML private TextArea ta_descricao_produto;
    
    @FXML private Pagination pagination;
    
    @FXML ImageView imageview;
    
    //Buttons
    @FXML private Button btn_deletar;
    @FXML private Button btn_voltar;
    
    //Imagem do Cursor
    Image image = new Image("imagens/icon.png");
    
    //Stage - Tela Login
    @FXML public static Stage Tela_Produto_Especifico;
    
    @FXML
    public void Deleta_Produto(ActionEvent event)
    {
        if(FXML_Produtos_Controller.Produto_Selecionado != null){
                Produto_DAO DAO = new Produto_DAO();
                int id = FXML_Produtos_Controller.Produto_Selecionado.getId_produto();
                DAO.deleta_Produto(id);
                
                Alert a=new Alert(Alert.AlertType.INFORMATION);
                a.setHeaderText("Produto deletado com sucesso!");
                a.showAndWait();
                
                Tela_Produto_Especifico.close();
        }else{
                Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Erro ao deletar o produto!");
                a.showAndWait();
        }
    }
    
    public void Voltar(){
        
        Tela_Produto_Especifico.close();
        
    }
    
    public void Preencher_Campos(){
        
        try{
        
            tf_nome_produto.setText( nome_produto );
            tf_nome_vendedor.setText( nome_vendedor );
            tf_preco_produto.setText( String.valueOf( preco_produto ) );
            dp_data_postagem.setValue( data_postagem );
            tf_categoria_produto.setText( categoria_produto );
            tf_numero_favoritos.setText( String.valueOf( numero_favoritos ) );
            ta_descricao_produto.setText( descricao_produto );
        
        }catch(Exception ex){
            
            Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Erro ao carregar informações específicas do produto! " + ex);
                a.showAndWait();
            
        }
    }
    
    public void start(Stage stage) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("FXML_Produto_Especifico.fxml"));        
        Scene scene = new Scene(root);      
        stage.setScene(scene);
        
        stage.setTitle("GreenStore - Produtos");
        stage.getIcons().add(new Image("imagens/icon.png"));
        
        scene.getStylesheets().add("CSS/fxml_login.css");
        
        stage.show();
        
        Tela_Produto_Especifico = stage;
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        try{
            imageview.setImage(new Image( "file:///C:\\TCC\\GreenStore_Web\\web\\" +  foto_1 ));
        }catch(Exception ex){}
        
        Preencher_Campos();
        
        pagination.currentPageIndexProperty().addListener(new ChangeListener<Number>(){

            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                
                int pagina = pagination.getCurrentPageIndex() + 1;
                
                if( pagina == 1 ){
                    
                    try{
                        
                        imageview.setImage(new Image( "file:///C:\\TCC\\GreenStore_Web\\web\\" + foto_1));
                    
                    }catch(Exception ex){}
                    
                }else if( pagina == 2 ){
                    
                    try{
                        
                        imageview.setImage(new Image( "file:///C:\\TCC\\GreenStore_Web\\web\\" + foto_2 ));
                    
                    }catch(Exception ex){}
                    
                }else if( pagina == 3 ){
                    
                    try{
                        
                        imageview.setImage(new Image( "file:///C:\\TCC\\GreenStore_Web\\web\\" +  foto_3 ));
                    
                    }catch(Exception ex){}
                    
                }
                
            }
            
        });
        
    }    
    
}
