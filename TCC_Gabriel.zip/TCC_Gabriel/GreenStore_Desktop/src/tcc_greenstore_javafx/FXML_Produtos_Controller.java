package tcc_greenstore_javafx;

import DAO.Produto_DAO;
import Model.Produto;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.ImageCursor;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author <Gabriel Mello de Oliveira
 */

public class FXML_Produtos_Controller implements Initializable {

    @FXML private TableView <Produto> Tabela;
    
    @FXML private TableColumn <Produto, Integer> coluna_id;
    @FXML private TableColumn <Produto, String> coluna_produto;
    @FXML private TableColumn <Produto, String> coluna_vendedor;
    @FXML private TableColumn <Produto, String> coluna_data_postagem;
    @FXML private TableColumn <Produto, String> coluna_categoria;
    @FXML private TableColumn <Produto, String> coluna_preco;
    
    @FXML private ObservableList <Produto> Produto_OBList;
    
    //TextField - Pesquisar
    @FXML private TextField tf_pesquisar;
    
    @FXML private Button btn_voltar;
    
    @FXML public static Produto Produto_Selecionado;
    
    //Imagem do Cursor
    Image image = new Image("imagens/icon.png");
    
    //Stage - Tela Login
    @FXML public static Stage Tela_Produtos;
    
    @FXML public void Preenche_Tabela_Produtos(){
        
        try{
        
            coluna_id.setCellValueFactory(new PropertyValueFactory( "id_produto" ));
            coluna_produto.setCellValueFactory(new PropertyValueFactory( "nome_produto" ));        
            coluna_vendedor.setCellValueFactory(new PropertyValueFactory( "vendedor_produto" ));
            coluna_data_postagem.setCellValueFactory(new PropertyValueFactory( "data_postagem" ));
            coluna_categoria.setCellValueFactory(new PropertyValueFactory( "categoria_produto" ));
            coluna_preco.setCellValueFactory(new PropertyValueFactory( "preco_produto" ));

            Produto_DAO DAO = new Produto_DAO();
            Produto_OBList = DAO.select_Produto();
            Tabela.setItems(Produto_OBList);
        
        }catch(Exception ex){
            
            Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Erro ao carregar informações do Banco de Dados! " + ex);
                a.showAndWait();
            
        }       
    }
    
    @FXML
    public void Tela_Produto_Especifico(ActionEvent action) throws Exception
    {
        if(FXML_Produtos_Controller.Produto_Selecionado != null)
        {       
                            
            FXML_Produto_Especifico_Controller.nome_produto = Produto_Selecionado.getNome_produto();
            
            FXML_Produto_Especifico_Controller.nome_vendedor = String.valueOf( Produto_Selecionado.getVendedor_produto() );
            
            FXML_Produto_Especifico_Controller.preco_produto = Produto_Selecionado.getPreco_produto();
            
            FXML_Produto_Especifico_Controller.data_postagem = Produto_Selecionado.getData_postagem();
            
            FXML_Produto_Especifico_Controller.categoria_produto =  String.valueOf( Produto_Selecionado.getCategoria_produto() );
            
            FXML_Produto_Especifico_Controller.numero_favoritos = Produto_Selecionado.getNumero_favoritos();
            
            FXML_Produto_Especifico_Controller.descricao_produto = Produto_Selecionado.getDescricao_produto();
            
            FXML_Produto_Especifico_Controller.foto_1 = Produto_Selecionado.getFoto_1();
            
            FXML_Produto_Especifico_Controller.foto_2 = Produto_Selecionado.getFoto_2();
            
            FXML_Produto_Especifico_Controller.foto_3 = Produto_Selecionado.getFoto_3();
                            
            FXML_Produto_Especifico_Controller Tela_Produto_Especifico = new FXML_Produto_Especifico_Controller();   
                       
            Tela_Produto_Especifico.start(new Stage());
            
        }else{
                Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Por favor, selecione um produto!");
                a.showAndWait();
        }
    }
    
    @FXML public void Voltar() throws Exception{
        
       Tela_Produtos.close();
        
    }
    
    @FXML
    public void Pesquisar()
    {
        ObservableList<Produto> prod = FXCollections.observableArrayList();
        
        for (Produto Produto_OBList1 : Produto_OBList) {
            if (Produto_OBList1.getNome_produto().contains(tf_pesquisar.getText())) {
                prod.add(Produto_OBList1);
            }
        }
        Tabela.setItems(prod);        
    }
    
    public void start(Stage stage) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("FXML_Produtos.fxml"));        
        Scene scene = new Scene(root);      
        stage.setScene(scene);
        
        stage.setTitle("GreenStore - Produtos");
        stage.getIcons().add(new Image("imagens/icon.png"));
        
        scene.getStylesheets().add("CSS/fxml_login.css");
        
        stage.show();
        
        Tela_Produtos = stage;
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btn_voltar.setCursor(new ImageCursor(image));      
        btn_voltar.getStyleClass().add("Buttons");
        
        Preenche_Tabela_Produtos();
        
        Tabela.getSelectionModel().selectedItemProperty().addListener(new ChangeListener()
        {
             @Override
             public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                 if(newValue != null){
                    FXML_Produtos_Controller.Produto_Selecionado = (Produto) newValue;
                 }else{
                    FXML_Produtos_Controller.Produto_Selecionado = null;
                 }
             }
         });
        
        tf_pesquisar.setOnKeyReleased((KeyEvent e)->{
             Pesquisar();
        });
    }    
    
}
