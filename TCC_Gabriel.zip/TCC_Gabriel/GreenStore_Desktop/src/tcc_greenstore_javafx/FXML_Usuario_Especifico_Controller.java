package tcc_greenstore_javafx;

import DAO.Usuario_DAO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.ResourceBundle;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.ImageCursor;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.imageio.ImageIO;

/**
 * FXML Controller class
 *
 * @author <Gabriel Mello de Oliveira
 */

public class FXML_Usuario_Especifico_Controller implements Initializable {

    //Várias que recebem as informações do usuário selecionado
    public static int id_usuario;
    public static String login;
    public static String nome;
    public static String email;
    public static int telefone;
    public static LocalDate data_nascimento;
    public static String pais;
    public static String estado;
    public static String pergunta_seguranca;
    public static String resposta_seguranca;
    public static String foto_perfil;
    
    //ImageViews
    @FXML private ImageView img_foto_perfil;
    
    //TextFields
    @FXML private TextField tf_nome;
    @FXML private TextField tf_login;
    @FXML private TextField tf_email;
    @FXML private TextField tf_idade;
    @FXML private TextField tf_telefone;
    @FXML private TextField tf_pergunta_seguranca;
    @FXML private TextField tf_resposta_seguranca;
    
    @FXML private TextField tf_pais;
    @FXML private TextField tf_estado;
    
    //DataPickers
    @FXML private DatePicker dp_data_nascimento;
    
    //Buttons
    @FXML private Button btn_deletar;
    @FXML private Button btn_voltar;
    
    //Imagem do Cursor
    Image image_icon = new Image("imagens/icon.png");
    
    //Stage - Tela Login
    @FXML public static Stage Tela_Usuario_Especifico;
    
    @FXML
    public void Deleta_Usuario(ActionEvent event)
    {
        if(FXML_Usuarios_Controller.Usuario_Selecionado != null){
                Usuario_DAO DAO = new Usuario_DAO();
                DAO.deleta_Usuario(FXML_Usuarios_Controller.Usuario_Selecionado);
                
                Alert a=new Alert(Alert.AlertType.INFORMATION);
                a.setHeaderText("Usuário deletado com sucesso!");
                a.showAndWait();
                
                Tela_Usuario_Especifico.close();
        }else{
                Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Erro ao deletar o usuário!");
                a.showAndWait();
        }
    }
    
    public void Voltar(){
        
        Tela_Usuario_Especifico.close();
        
    }
    
    LocalDate Data_Atual = FXML_Principal_Controller.dataparaGravar.toLocalDate();;
    
    public void Preenche_Campos()
    {    
        try{    

            try{
                
                img_foto_perfil.setImage( new Image( "file:///C:\\TCC\\GreenStore_Web\\web\\" + foto_perfil ) );
                
            }catch(Exception ex){}
            
            tf_nome.setText( nome );

            tf_login.setText( login );

            tf_email.setText( email );
            
            tf_idade.setText( String.valueOf( Calculo_Idade(Data_Atual, data_nascimento) ) );

            tf_telefone.setText( String.valueOf( telefone ) );

            tf_pergunta_seguranca.setText( String.valueOf( pergunta_seguranca ) );

            tf_resposta_seguranca.setText( resposta_seguranca );

            dp_data_nascimento.setValue( data_nascimento );

            tf_pais.setText( pais );

            tf_estado.setText( estado );
        
        }catch(Exception ex){
       
            Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Erro ao carregar informações específicas do usuário! " + ex);
                a.showAndWait();
            
        }
    }
    
    public int Calculo_Idade(LocalDate data_atual, LocalDate data_nascimento){
        
        int ano_atual = data_atual.getYear(), ano_nasc = data_nascimento.getYear();
        int mes_atual = data_atual.getMonthValue(), mes_nasc = data_nascimento.getMonthValue();
        int dia_atual = data_atual.getDayOfMonth(), dia_nasc = data_nascimento.getDayOfMonth();
        
        int idade = ano_atual - ano_nasc;
        
        if( mes_nasc > mes_atual && dia_nasc > dia_atual )
        {    
                
            idade = idade - 1;
            
        }
        
        return idade;
    }
    
    public void start(Stage stage) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("FXML_Usuario_Especifico.fxml"));        
        Scene scene = new Scene(root);      
        stage.setScene(scene);
        
        stage.setTitle("GreenStore - " + login);
        stage.getIcons().add(new Image("imagens/icon.png"));
        
        scene.getStylesheets().add("CSS/fxml_login.css");
        
        stage.show();
        
        Tela_Usuario_Especifico = stage;
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {       
        btn_deletar.setCursor(new ImageCursor(image_icon));      
        btn_deletar.getStyleClass().add("Buttons");
        
        btn_voltar.setCursor(new ImageCursor(image_icon));      
        btn_voltar.getStyleClass().add("Buttons");
        
        Preenche_Campos();
    }    
    
}
