package tcc_greenstore_javafx;

import DAO.Usuario_DAO;
import Model.Usuario;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.ImageCursor;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author <Gabriel Mello de Oliveira
 */

public class FXML_Usuarios_Controller implements Initializable {

    @FXML private TableView <Usuario> Tabela;
    
    @FXML private TableColumn <Usuario, Integer> coluna_id;
    @FXML private TableColumn <Usuario, String> coluna_nome;
    @FXML private TableColumn <Usuario, String> coluna_login;
    @FXML private TableColumn <Usuario, String> coluna_email;
    
    @FXML private ObservableList <Usuario> Usuario_OBList;
    
    //TextField - Pesquisar
    @FXML private TextField tf_pesquisar;
    
    //Buttons
    @FXML private Button btn_voltar;
    
    @FXML public static Usuario Usuario_Selecionado;
    
    //Imagem do Cursor
    Image image = new Image("imagens/icon.png");
    
    //Stage - Tela Login
    @FXML public static Stage Tela_Usuarios;
    
    public void Preencher_Tabela_Usuarios()
    {
        try{
            
            coluna_id.setCellValueFactory(new PropertyValueFactory("id_usuario"));
            coluna_nome.setCellValueFactory(new PropertyValueFactory("nome"));        
            coluna_login.setCellValueFactory(new PropertyValueFactory("login"));
            coluna_email.setCellValueFactory(new PropertyValueFactory("email"));

            Usuario_DAO DAO = new Usuario_DAO();
            Usuario_OBList = DAO.select_Usuario();
            Tabela.setItems(Usuario_OBList); 
        
        }catch(Exception ex){
            
            Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Erro ao carregar informações do Banco de Dados! " + ex);
                a.showAndWait();
            
        }     
    }
    
    @FXML
    public void Tela_Usuario_Especifico(ActionEvent action) throws Exception
    {
        if(FXML_Usuarios_Controller.Usuario_Selecionado != null)
        {       
            FXML_Usuario_Especifico_Controller.id_usuario = Usuario_Selecionado.getId_usuario();
            FXML_Usuario_Especifico_Controller.login = Usuario_Selecionado.getLogin();
            FXML_Usuario_Especifico_Controller.nome = Usuario_Selecionado.getNome();
            FXML_Usuario_Especifico_Controller.email = Usuario_Selecionado.getEmail();
            FXML_Usuario_Especifico_Controller.telefone = Usuario_Selecionado.getTelefone();
            FXML_Usuario_Especifico_Controller.data_nascimento = Usuario_Selecionado.getData_nascimento();
            FXML_Usuario_Especifico_Controller.pais = Usuario_Selecionado.getPais();
            FXML_Usuario_Especifico_Controller.estado = Usuario_Selecionado.getEstado();
            FXML_Usuario_Especifico_Controller.pergunta_seguranca = Usuario_Selecionado.getPergunta_seguranca();
            FXML_Usuario_Especifico_Controller.resposta_seguranca = Usuario_Selecionado.getResposta_seguranca();
            FXML_Usuario_Especifico_Controller.foto_perfil = Usuario_Selecionado.getFoto_perfil();
                            
            FXML_Usuario_Especifico_Controller Tela_Usuario_Especifico = new FXML_Usuario_Especifico_Controller();   
                       
            Tela_Usuario_Especifico.start(new Stage());
            
        }else{
                Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Por favor, selecione um Usuário!");
                a.showAndWait();
        }
    }
    
    @FXML public void Voltar() throws Exception{
        
        Tela_Usuarios.close();
        
    }
    
    @FXML
    public void Pesquisar()
    {
        ObservableList<Usuario> user = FXCollections.observableArrayList();
        
        for (Usuario Usuario_OBList1 : Usuario_OBList) {
            if (Usuario_OBList1.getNome().contains(tf_pesquisar.getText())) {
                user.add(Usuario_OBList1);
            }
        }
        Tabela.setItems(user);        
    }
    
    public void start(Stage stage) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("FXML_Usuarios.fxml"));        
        Scene scene = new Scene(root);      
        stage.setScene(scene);
        
        stage.setTitle("GreenStore - Usuarios");
        stage.getIcons().add(new Image("imagens/icon.png"));
        
        scene.getStylesheets().add("CSS/fxml_login.css");
        
        stage.show();
        
        Tela_Usuarios = stage;
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btn_voltar.setCursor(new ImageCursor(image));
        
        Preencher_Tabela_Usuarios();
        
        Tabela.getSelectionModel().selectedItemProperty().addListener(new ChangeListener()
        {
             @Override
             public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                 if(newValue != null){
                    FXML_Usuarios_Controller.Usuario_Selecionado = (Usuario) newValue;
                 }else{
                    FXML_Usuarios_Controller.Usuario_Selecionado = null;
                 }
             }
         });
        
        tf_pesquisar.setOnKeyReleased((KeyEvent e)->{
             Pesquisar();
        });
    }    
    
}
