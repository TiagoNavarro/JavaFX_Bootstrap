package Testes;

import Model.Mensagem;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author User
 */
public class Test_Mensagens {
    
    public Test_Mensagens() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    
    @Test
    public void testeGet_SetEmissor(){
        String emissor = "emissor";
        Mensagem mensagem = new Mensagem();
        mensagem.setNome_emissor(emissor);
        
        String testa = "emissorteste";
        
        //trocar testa por emissor
        if(testa.equals(testa)){
            fail("Os valores são iguais, e devem ser trocados");
        }
    }
    
    @Test
    public void testeGet_SetReceptor(){
        String receptor = "azul";
        Mensagem mensagem = new Mensagem();
        mensagem.setNome_receptor(receptor);
        
        String testa = "receptorteste";
        
        //trocar testa por receptor
        if(testa.equals(testa)){
            fail("Os valores são iguais, e devem ser trocados");
        }
    }
    
    @Test
    public void testeGet_SetConteudo(){
        String conteudo_mensagem = "conteudo_mensagem";
        Mensagem mensagem = new Mensagem();
        mensagem.setConteudo_mensagem(conteudo_mensagem);
        
        String testa = "conteudo_mensagemteste";
        
        //trocar testa por conteudo_mensagem
        if(testa.equals(conteudo_mensagem)){
            fail("Os valores são iguais, e devem ser trocados");
        }
    }
    
}
