package DAO;

import JDBC.Connection_MVC;
import Model.Estado;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class Estado_DAO {
  
    public static Connection conexao_BD;
    
    public static ResultSet r;
    
    public static PreparedStatement st;
    
    public Estado_DAO()
    {
        Estado_DAO.conexao_BD = Connection_MVC.getConnection();
    }
    
    public ObservableList<Estado> select_Estado()
    {
        try{
           
            ObservableList<Estado> Estados = FXCollections.observableArrayList();
            PreparedStatement stmt = this.conexao_BD.prepareStatement(
                "SELECT * FROM Estados" 
                );
            
            ResultSet rs = stmt.executeQuery();
            
            r = rs;
            st = stmt;
            
            while(rs.next()){
 
                Estado estado = new Estado();
                
                estado.setId_pais(rs.getInt("id_pais"));
                
                estado.setId_estado(rs.getInt("id_estado"));
                        
                estado.setNome_estado(rs.getString("nome_estado"));
                
                Estados.add( estado );
                
            }
  
            stmt.executeQuery();
            
            return Estados;
            
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
}
