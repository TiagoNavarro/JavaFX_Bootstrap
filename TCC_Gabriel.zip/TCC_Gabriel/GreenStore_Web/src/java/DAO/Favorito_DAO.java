package DAO;

import JDBC.Connection_MVC;
import Model.Favorito;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class Favorito_DAO {
    
    public static Connection conexao_BD;
  
    public Favorito_DAO()
    {
        Favorito_DAO.conexao_BD = Connection_MVC.getConnection();
    }
    
    public ObservableList<Favorito> select_Favorito()
    {
        try{
           
            ObservableList<Favorito> Favoritos = FXCollections.observableArrayList();
            PreparedStatement stmt = this.conexao_BD.prepareStatement(
                "SELECT * FROM Favoritos" 
            );
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
 
                Favorito fav = new Favorito();
                
                fav.setId_usuario(rs.getInt("id_usuario"));
                fav.setId_produto(rs.getInt("id_produto"));
                
                Favoritos.add( fav );
                
            }
  
            stmt.executeQuery();
            
            return Favoritos;
            
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public int select_Favorito_especifico(int id_produto)
    {
        int numero_favoritos = 0;
        
        try{
           
            PreparedStatement stmt = this.conexao_BD.prepareStatement(
                "SELECT COUNT(id_produto) AS NF FROM Favoritos WHERE id_produto = ?" 
            );
            
            stmt.setInt(1, id_produto);
            
            ResultSet rs = stmt.executeQuery();
            
            rs.next();
            
            numero_favoritos = rs.getInt("NF");
            
            stmt.executeQuery();
            stmt.execute();
            stmt.close();

            }catch(SQLException e){
                System.out.println(e.getMessage());
            }
        return numero_favoritos;
    }
    
    public void insere_favorito(int id_usuario, int id_produto) throws SQLException{
        
        PreparedStatement stmt = this.conexao_BD.prepareStatement(
                "INSERT INTO Favoritos (id_usuario, id_produto) VALUES (?, ?)" 
        );
        
        try{
            stmt.setInt(1, id_usuario);
            stmt.setInt(2, id_produto);
            stmt.execute();
            stmt.close();
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("DELETA DAO");
            deleta_favorito(id_usuario, id_produto);
        }
        
    }
    
    public void deleta_favorito(int id_usuario, int id_produto) throws SQLException
    {
        PreparedStatement stmt = this.conexao_BD.prepareStatement(
                "DELETE FROM Favoritos WHERE id_usuario = ? AND id_produto = ?"
        );
        
        try{
            stmt.setInt(1, id_usuario);
            stmt.setInt(2, id_produto);
            stmt.execute();
            stmt.close();
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
    }
    
}
