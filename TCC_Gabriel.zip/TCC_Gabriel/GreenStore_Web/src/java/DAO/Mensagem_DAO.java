package DAO;

import JDBC.Connection_MVC;
import Model.Mensagem;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class Mensagem_DAO
{
    public static Connection conexao_BD;
    
    public Mensagem_DAO()
    {
        Mensagem_DAO.conexao_BD = Connection_MVC.getConnection();
    }
    
    public ObservableList<Mensagem> select_Mensagem()
    {
        try{
           
            ObservableList<Mensagem> Msn = FXCollections.observableArrayList();
            PreparedStatement stmt = this.conexao_BD.prepareStatement("SELECT * FROM Informacoes_Mensagem");
   
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
 
                Mensagem mensagem = new Mensagem();
                
                mensagem.setId_mensagem(rs.getInt("id_mensagem"));
                mensagem.setId_emissor(rs.getInt("id_emissor"));
                mensagem.setNome_emissor(rs.getString("login_emissor"));
                mensagem.setId_receptor(rs.getInt("id_receptor"));
                mensagem.setNome_receptor(rs.getString("login_receptor"));
                mensagem.setData_envio(rs.getDate("data_envio").toLocalDate());
                mensagem.setConteudo_mensagem(rs.getString("conteudo_mensagem"));
                mensagem.setMensagem_lida(rs.getBoolean("mensagem_lida"));
                   
                Msn.add( mensagem );
                
            }
  
            stmt.executeQuery();
            
            return Msn;
            
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public void delete_Mensagem(Mensagem mensagem)
    {
        String sql = "DELETE FROM Mensagens WHERE id_mensagem = ?";
        try{
            PreparedStatement stmt = conexao_BD.prepareStatement(sql);
            stmt.setInt(1, mensagem.getId_mensagem());
            stmt.execute();
            stmt.close();
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
    }
    
    public void insert_Mensagem(int id_emissor, int id_receptor, String conteudo_mensagem){
        
        String sql = "INSERT INTO Mensagens (id_emissor, id_receptor, conteudo_mensagem) VALUES (?, ?, ?)";
        
        try{
           
           PreparedStatement stat = conexao_BD.prepareStatement(sql);
           
           stat.setInt(1, id_emissor);
           stat.setInt(2, id_receptor);
           stat.setString(3, conteudo_mensagem);
           
           stat.execute();
           
       }catch(SQLException ex){
           System.out.println(ex.getMessage());
       }
        
    }
    
}
