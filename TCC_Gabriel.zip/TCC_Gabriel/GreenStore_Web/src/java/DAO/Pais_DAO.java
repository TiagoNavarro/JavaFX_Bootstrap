package DAO;

import JDBC.Connection_MVC;
import Model.Pais;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class Pais_DAO {
    
    public static Connection conexao_BD;
    
    public static ResultSet r;
    
    public static PreparedStatement st;
    
    public Pais_DAO()
    {
        Pais_DAO.conexao_BD = Connection_MVC.getConnection();
    }
    
    public ObservableList<Pais> select_Pais()
    {
        try{
           
            ObservableList<Pais> Paises = FXCollections.observableArrayList();
            PreparedStatement stmt = this.conexao_BD.prepareStatement(
                "SELECT * FROM Paises" 
                );
            
            ResultSet rs = stmt.executeQuery();
            
            r = rs;
            st = stmt;
            
            while(rs.next()){
 
                Pais pais = new Pais();
                
                pais.setId_pais(rs.getInt("id_pais"));
                        
                pais.setNome_pais(rs.getString("nome_pais"));
                
                Paises.add( pais );
                
            }
  
            stmt.executeQuery();
            
            return Paises;
            
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
}
