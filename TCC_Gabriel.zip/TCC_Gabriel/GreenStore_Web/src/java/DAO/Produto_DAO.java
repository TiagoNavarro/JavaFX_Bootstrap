package DAO;

import JDBC.Connection_MVC;
import Model.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class Produto_DAO
{
    public static Connection conexao_BD;
    
    public Produto_DAO()
    {
        Produto_DAO.conexao_BD = Connection_MVC.getConnection();
    }
    
    public ObservableList<Produto> select_Produto()
    {
        try{
           
            ObservableList<Produto> Prod = FXCollections.observableArrayList();
            PreparedStatement stmt = this.conexao_BD.prepareStatement(
                "SELECT * FROM Informacoes_Produto" 
            );
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
 
                Produto produto = new Produto();
                
                produto.setId_produto(rs.getInt("id_produto"));
                produto.setNome_produto(rs.getString("nome_produto"));
                produto.setId_vendedor(rs.getInt("id_vendedor"));
                produto.setVendedor_produto(rs.getString("login"));
                produto.setId_categoria(rs.getInt("id_categoria"));
                produto.setCategoria_produto(rs.getString("nome_categoria"));
                produto.setPreco_produto(rs.getFloat("preco_produto"));
                produto.setData_postagem(rs.getDate("data_postagem").toLocalDate());
                produto.setNumero_favoritos(rs.getInt("num_favoritos"));
                produto.setDescricao_produto(rs.getString("descricao_produto"));
                produto.setFoto_1(rs.getString("foto_1"));
                produto.setFoto_2(rs.getString("foto_2"));
                produto.setFoto_3(rs.getString("foto_3"));
                
                Prod.add( produto );
                
            }
  
            stmt.executeQuery();
            
            return Prod;
            
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public ObservableList<Produto> select_Produto_filtro(int id_categoria)
    {
        try{
           
            ObservableList<Produto> Prod = FXCollections.observableArrayList();
            
            PreparedStatement stmt = null;
               
            stmt = this.conexao_BD.prepareStatement(
                "SELECT * FROM Informacoes_Produto WHERE id_categoria = ?" 
            );

            stmt.setInt(1, id_categoria);
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
 
                Produto produto = new Produto();
                
                produto.setId_produto(rs.getInt("id_produto"));
                produto.setNome_produto(rs.getString("nome_produto"));
                produto.setId_vendedor(rs.getInt("id_vendedor"));
                produto.setVendedor_produto(rs.getString("login"));
                produto.setId_categoria(rs.getInt("id_categoria"));
                produto.setCategoria_produto(rs.getString("nome_categoria"));
                produto.setPreco_produto(rs.getFloat("preco_produto"));
                produto.setData_postagem(rs.getDate("data_postagem").toLocalDate());
                produto.setNumero_favoritos(rs.getInt("num_favoritos"));
                produto.setDescricao_produto(rs.getString("descricao_produto"));
                produto.setFoto_1(rs.getString("foto_1"));
                produto.setFoto_2(rs.getString("foto_2"));
                produto.setFoto_3(rs.getString("foto_3"));
                
                Prod.add( produto );
                
            }
  
            stmt.executeQuery();
            
            return Prod;
            
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public void favoritar_produto(int favoritos, int id_produto)
    {
        String sql = "UPDATE Produtos SET num_favoritos = ? WHERE id_produto = ?";
        try{
            PreparedStatement stmt = conexao_BD.prepareStatement(sql);
            stmt.setInt(1, favoritos);
            stmt.setInt(2, id_produto);
            stmt.execute();
            stmt.close();
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
    }
    
    public int numero_produtos()
    {
        int numero_produtos = 0;
        
        try{
           
            PreparedStatement stmt = this.conexao_BD.prepareStatement(
                "SELECT COUNT(id_produto) AS PROD FROM Produtos" 
            );
            
            ResultSet rs = stmt.executeQuery();
            
            rs.next();
            
            numero_produtos = rs.getInt("PROD");
            
            stmt.executeQuery();
            stmt.execute();
            stmt.close();

            }catch(SQLException e){
                System.out.println(e.getMessage());
            }
        return numero_produtos;
    }
    
    public void deleta_Produto(int id_produto)
    {
        String sql_favoritos = "DELETE FROM Favoritos WHERE id_produto = ?";
        String sql_produtos = "DELETE FROM Produtos WHERE id_produto = ?";
        
        try{
            PreparedStatement stmt = conexao_BD.prepareStatement(sql_favoritos);
            stmt.setInt( 1, id_produto );
            stmt.execute();
            
            stmt = conexao_BD.prepareStatement(sql_produtos);
            stmt.setInt(1, id_produto );
            stmt.execute();
            
            stmt.close();
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
    }
    
    public void insert_Produto(Produto produto){
       
       Connection c = Connection_MVC.getConnection();
       String sql = "INSERT INTO Produtos(nome_produto, id_vendedor, id_categoria, preco_produto, descricao_produto)" + 
                    " VALUES (?, ?, ?, ?, ?)"; 
        
       try{
           
           PreparedStatement stat = c.prepareStatement(sql);
           
           stat.setString(1, produto.getNome_produto());
           stat.setInt(2, produto.getId_vendedor());
           stat.setInt(3, produto.getId_categoria());
           stat.setFloat(4, produto.getPreco_produto());
           stat.setString(5, produto.getDescricao_produto());
           
           stat.execute();
           
       }catch(SQLException ex){
           System.out.println(ex.getMessage());
       }
       
    }
    
    public void update_fotos(int id, String foto_1, String foto_2, String foto_3)
    {
        String sql = null;
        
        if(foto_1 != null){
        
            sql = "UPDATE Produtos SET foto_1 = ? WHERE id_produto = ?";
            
            try{
            PreparedStatement stmt = conexao_BD.prepareStatement(sql);
            stmt.setString(1, foto_1);
            stmt.setInt(2, id);
            stmt.execute();
            stmt.close();
            }catch(SQLException e){
                throw new RuntimeException(e);
            }
            
        }else if(foto_2 != null){
            
            sql = "UPDATE Produtos SET foto_2 = ? WHERE id_produto = ?";
            
            try{
            PreparedStatement stmt = conexao_BD.prepareStatement(sql);
            stmt.setString(1, foto_2);
            stmt.setInt(2, id);
            stmt.execute();
            stmt.close();
            }catch(SQLException e){
                throw new RuntimeException(e);
            }
            
        }else if(foto_3 != null){
            
            sql = "UPDATE Produtos SET foto_3 = ? WHERE id_produto = ?";
            
            try{
            PreparedStatement stmt = conexao_BD.prepareStatement(sql);
            stmt.setString(1, foto_3);
            stmt.setInt(2, id);
            stmt.execute();
            stmt.close();
            }catch(SQLException e){
                throw new RuntimeException(e);
            }
            
        }
    }
        
        public void update_produto(Produto produto){
            
            String sql = "UPDATE Produtos SET nome_produto = ?, preco_produto = ?, descricao_produto = ?, id_categoria = ? WHERE id_produto = ?";

            try{
                PreparedStatement stmt = conexao_BD.prepareStatement(sql);
                stmt.setString(1, produto.getNome_produto());
                stmt.setFloat(2, produto.getPreco_produto());
                stmt.setString(3, produto.getDescricao_produto());
                stmt.setInt(4, produto.getId_categoria());
                stmt.setInt(5, produto.getId_produto());
                stmt.execute();
                stmt.close();
            }catch(SQLException e){
                throw new RuntimeException(e);
            }
        
        }
    
}
