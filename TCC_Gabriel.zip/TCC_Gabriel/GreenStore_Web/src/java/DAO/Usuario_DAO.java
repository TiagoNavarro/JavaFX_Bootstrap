package DAO;

import JDBC.Connection_MVC;
import Model.Usuario;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class Usuario_DAO {
    
    public static Connection conexao_BD;
    
    public Usuario_DAO()
    {
        Usuario_DAO.conexao_BD = Connection_MVC.getConnection();
    }
        
    public void insert_Usuario(Usuario usuario){
       
       Connection c = Connection_MVC.getConnection();
       String sql = "INSERT INTO Usuarios(login, senha, nome, email, data_nascimento, id_pergunta_seguranca, resposta_seguranca, id_pais, id_estado)" + 
                    " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"; 
        
       try{
           
           PreparedStatement stat = c.prepareStatement(sql);
           
           stat.setString(1, usuario.getLogin());
           stat.setString(2, usuario.getSenha());
           stat.setString(3, usuario.getNome());
           stat.setString(4, usuario.getEmail());
           stat.setDate(5, Date.valueOf(usuario.getData_nascimento())); //Date.valueOf( usuario.getData_nascimento() ));
           stat.setInt(6, usuario.getId_pergunta_seguranca());
           stat.setString(7, usuario.getResposta_seguranca());
           stat.setInt(8, usuario.getId_pais());
           stat.setInt(9, usuario.getId_estado());
           
           stat.execute();
           
       }catch(SQLException ex){
           System.out.println(ex.getMessage());
       }
       
    }
    
    public ObservableList<Usuario> select_Usuario()
    {
        try{
            
            ObservableList<Usuario> User = FXCollections.observableArrayList();
        
            PreparedStatement stmt = this.conexao_BD.prepareStatement("SELECT * FROM Informacoes_Usuario");
            
            ResultSet rs = stmt.executeQuery();
                        
            while(rs.next()){
 
                Usuario usuario = new Usuario();
                
                usuario.setId_usuario(rs.getInt("id_usuario"));
                usuario.setLogin(rs.getString("login"));
                usuario.setSenha(rs.getString("senha"));
                usuario.setNome(rs.getString("nome"));
                usuario.setEmail(rs.getString("email"));
                usuario.setTelefone(rs.getInt("telefone"));
                usuario.setData_nascimento(rs.getDate("data_nascimento").toLocalDate());
                
                usuario.setPais(rs.getString("nome_pais"));
                
                usuario.setEstado(rs.getString("nome_estado"));
                
                usuario.setPergunta_seguranca(rs.getString("pergunta_seguranca"));
                
                usuario.setResposta_seguranca(rs.getString("resposta_seguranca"));
                usuario.setFoto_perfil(rs.getString("foto_perfil"));
                   
                User.add(usuario);
            }
            
            stmt.executeQuery();
            
            return User;
     
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
        
    }
    
    public int numero_usuarios()
    {
        int numero_usuarios = 0;
        
        try{
           
            PreparedStatement stmt = this.conexao_BD.prepareStatement(
                "SELECT COUNT(id_usuario) AS USU FROM Usuarios" 
            );
            
            ResultSet rs = stmt.executeQuery();
            
            rs.next();
            
            numero_usuarios = rs.getInt("USU");
            
            stmt.executeQuery();
            stmt.execute();
            stmt.close();

            }catch(SQLException e){
                System.out.println(e.getMessage());
            }
        return numero_usuarios;
    }
    
    public void update_usuario(int id, String login, String nome, String email, int telefone){
        
        Connection c = Connection_MVC.getConnection();
       String sql = "UPDATE Usuarios SET login = ?, nome = ?, email = ?, telefone = ?" + 
                    " WHERE id_usuario = ?"; 
        
       try{
           
           PreparedStatement stat = c.prepareStatement(sql);
           
           stat.setString(1, login);
           stat.setString(2, nome);
           stat.setString(3, email);
           stat.setInt(4, telefone);
           stat.setInt(5, id);
           
           stat.execute();
           stat.close();
           
       }catch(SQLException ex){
           System.out.println(ex.getMessage());
       }
        
    }
    
    public void update_foto_perfil(int id, String foto){
        
        Connection c = Connection_MVC.getConnection();
       String sql = "UPDATE Usuarios SET foto_perfil = ?" + 
                    " WHERE id_usuario = ?"; 
        
       try{
           
           PreparedStatement stat = c.prepareStatement(sql);
           
           stat.setString(1, foto);
           stat.setInt(2, id);
           
           stat.execute();
           stat.close();
           
       }catch(SQLException ex){
           System.out.println(ex.getMessage());
       }
        
    }
    
    public void update_senha(String senha, int id_usuario){
        
        Connection c = Connection_MVC.getConnection();
        String sql = "UPDATE Usuarios SET senha = ?" + 
                    " WHERE id_usuario = ?"; 
        
       try{
           
           PreparedStatement stat = c.prepareStatement(sql);
           
           stat.setString(1, senha);
           stat.setInt(2, id_usuario);
           
           stat.execute();
           stat.close();
           
       }catch(SQLException ex){
           System.out.println(ex.getMessage());
       }
        
    }
    
}
