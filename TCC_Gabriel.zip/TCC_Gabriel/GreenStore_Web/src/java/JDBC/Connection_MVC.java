package JDBC;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class Connection_MVC {
    
    public static String driver = "org.postgresql.Driver";
    public static String caminho = "jdbc:postgresql://localhost/greenstore_db";
    public static String usuario = "postgres";
    public static String senha_db;
    
    public static Connection getConnection()
    {
        validacao_PC();
        
        Connection c = null;
        
        try{
            Class.forName(driver);
            c = DriverManager.getConnection(caminho, usuario, senha_db);
        }catch(SQLException e){
            System.out.println("INICIO DO ERRO");
            e.printStackTrace();
            System.out.println("FIM DO ERRO");
        }   catch(ClassNotFoundException e){
            System.out.println("INICIO DO ERRO");
            e.printStackTrace();
            System.out.println("FIM DO ERRO");
        }
        
        return c;
    }
    
    public static void validacao_PC()
    {
        String retorno = null;

        try {

            retorno = InetAddress.getLocalHost().getHostName();
            
            System.out.print( retorno );
            
            if(retorno.equals("User-PC"))
            {
                senha_db = "gabriel";
            }else if(retorno.equals("Gabriel-PC"))
            {
                senha_db = "gabriel";
            }else{
                senha_db = "aluno";
            }    

        } catch (UnknownHostException ex) {

            Logger.getLogger(Connection_MVC.class.getName()).log(Level.SEVERE, null, ex);

        }
    }
    
}
