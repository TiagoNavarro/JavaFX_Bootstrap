package Model;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class Favorito
{
    private int id_usuario;
    private int id_produto;

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public int getId_produto() {
        return id_produto;
    }

    public void setId_produto(int id_produto) {
        this.id_produto = id_produto;
    }
    
}
