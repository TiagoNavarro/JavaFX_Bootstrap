package Model;

import java.time.LocalDate;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class Mensagem
{
    private int id_mensagem;
    
    private String conteudo_mensagem;
    private int id_emissor;
    private int id_receptor;
    private LocalDate data_envio;
    
    private String nome_emissor;
    private String nome_receptor;
    
    private boolean mensagem_lida;

    public Mensagem(){}

    public int getId_mensagem() {
        return id_mensagem;
    }

    public void setId_mensagem(int id_mensagem) {
        this.id_mensagem = id_mensagem;
    }
    
    public String getConteudo_mensagem() {
        return conteudo_mensagem;
    }

    public void setConteudo_mensagem(String conteudo_mensagem) {
        this.conteudo_mensagem = conteudo_mensagem;
    }

    public int getId_emissor() {
        return id_emissor;
    }

    public void setId_emissor(int id_emissor) {
        this.id_emissor = id_emissor;
    }

    public int getId_receptor() {
        return id_receptor;
    }

    public void setId_receptor(int id_receptor) {
        this.id_receptor = id_receptor;
    }

    public LocalDate getData_envio() {
        return data_envio;
    }

    public void setData_envio(LocalDate data_envio) {
        this.data_envio = data_envio;
    }

    public String getNome_emissor() {
        return nome_emissor;
    }

    public void setNome_emissor(String nome_emissor) {
        this.nome_emissor = nome_emissor;
    }

    public String getNome_receptor() {
        return nome_receptor;
    }

    public void setNome_receptor(String nome_receptor) {
        this.nome_receptor = nome_receptor;
    }
    
    public boolean isMensagem_lida() {
        return mensagem_lida;
    }

    public void setMensagem_lida(boolean mensagem_lida) {
        this.mensagem_lida = mensagem_lida;
    }
    
}
