/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author User
 */
public class Pergunta_Seguranca {
    
    private int id_pergunta_seguranca;
    private String pergunta_seguranca;

    public int getId_pergunta_seguranca() {
        return id_pergunta_seguranca;
    }

    public void setId_pergunta_seguranca(int id_pergunta_seguranca) {
        this.id_pergunta_seguranca = id_pergunta_seguranca;
    }

    public String getPergunta_seguranca() {
        return pergunta_seguranca;
    }

    public void setPergunta_seguranca(String pergunta_seguranca) {
        this.pergunta_seguranca = pergunta_seguranca;
    }
    
    
    
}
