package Model;

import java.time.LocalDate;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class Usuario
{
    private int id_usuario;
    
    private String login;
    private String senha;
    
    private String nome;
    private String email;
    private int telefone;
    
    private LocalDate data_nascimento;
    
    private int id_pais;
    private int id_estado;
    
    private String pais;
    private String estado;
    
    private int id_pergunta_seguranca;
    
    private String pergunta_seguranca;
    private String resposta_seguranca;
    
    private String foto_perfil;
    
    public Usuario(){}

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    public LocalDate getData_nascimento() {
        return data_nascimento;
    }

    public void setData_nascimento(LocalDate data_nascimento) {
        this.data_nascimento = data_nascimento;
    }

    public int getId_pais() {
        return id_pais;
    }

    public void setId_pais(int id_pais) {
        this.id_pais = id_pais;
    }

    public int getId_estado() {
        return id_estado;
    }

    public void setId_estado(int id_estado) {
        this.id_estado = id_estado;
    }
    
    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getId_pergunta_seguranca() {
        return id_pergunta_seguranca;
    }

    public void setId_pergunta_seguranca(int id_pergunta_seguranca) {
        this.id_pergunta_seguranca = id_pergunta_seguranca;
    }
    
    public String getPergunta_seguranca() {
        return pergunta_seguranca;
    }

    public void setPergunta_seguranca(String pergunta_seguranca) {
        this.pergunta_seguranca = pergunta_seguranca;
    }

    public String getResposta_seguranca() {
        return resposta_seguranca;
    }

    public void setResposta_seguranca(String resposta_seguranca) {
        this.resposta_seguranca = resposta_seguranca;
    }

    public String getFoto_perfil() {
        return foto_perfil;
    }

    public void setFoto_perfil(String foto_perfil) {
        this.foto_perfil = foto_perfil;
    }
        
}
