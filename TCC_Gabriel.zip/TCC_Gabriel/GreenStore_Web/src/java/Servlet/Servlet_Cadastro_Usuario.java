package Servlet;

import DAO.Pais_DAO;
import DAO.Pergunta_Seguranca_DAO;
import DAO.Usuario_DAO;
import Model.Pais;
import Model.Pergunta_Seguranca;
import Model.Usuario;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.time.LocalDate;
import javafx.collections.ObservableList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class Servlet_Cadastro_Usuario extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
 
        try{
            String login = (String) request.getParameter("login_cadastro");           
            String senha = (String) request.getParameter("senha_cadastro"); 
            String r_senha = (String) request.getParameter("r_senha_cadastro");
            String nome = (String) request.getParameter("nome_cadastro");
            String email = (String) request.getParameter("email_cadastro");
            Date data_nascimento = Date.valueOf(request.getParameter("data_nascimento_cadastro"));
            String pergunta_seguranca = (String) request.getParameter("pergunta_seguranca_cadastro");
            String ps_2;
            String resposta_seguranca = (String) request.getParameter("resposta_seguranca_cadastro");
            String pais = (String) request.getParameter("pais_cadastro");
        
            int id_ps = 0;
            int id_pais = 0;
            
            if(senha.equals(r_senha)){
            
                Pergunta_Seguranca_DAO dao_ps = new Pergunta_Seguranca_DAO();
                
                ObservableList <Pergunta_Seguranca> lista_ps = dao_ps.select_Pergunta_Seguranca();
                
                for(Pergunta_Seguranca ps : lista_ps){
                    ps_2 = ps.getPergunta_seguranca();
                    if(ps_2.equals(pergunta_seguranca)){
                        id_ps = ps.getId_pergunta_seguranca();
                        
                        break;
                    }
                }
                
                Pais_DAO dao_pais = new Pais_DAO();
                
                ObservableList <Pais> lista_pais = dao_pais.select_Pais();
                
                for(Pais paises : lista_pais){
                    if(paises.getNome_pais().equals(pais)){
                        id_pais = paises.getId_pais();
                        
                        break;
                    }
                }
                
                Usuario usuario = new Usuario();

                usuario.setLogin(login);
                usuario.setEmail(email);
                usuario.setNome(nome);
                usuario.setSenha(senha);
                usuario.setId_pais(id_pais);
                usuario.setId_estado(1);
                usuario.setId_pergunta_seguranca(id_ps);
                usuario.setData_nascimento(data_nascimento.toLocalDate());
                usuario.setResposta_seguranca(resposta_seguranca);

                Usuario_DAO DAO = new Usuario_DAO();
                
                try{
                DAO.insert_Usuario(usuario);
                }catch(Exception ex){
                    System.out.println("Erro11: " + ex);
                }

                request.setAttribute("message", "Usuário cadastrado com sucesso!");
                request.setAttribute("css_class", "sucesso");
                
                RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
                rd.forward(request, response);
            
            }else{
                
                request.setAttribute("message", "Erro ao cadastrar usuário!");
                request.setAttribute("css_class", "erro");
                
                RequestDispatcher rd = request.getRequestDispatcher("cadastro_usuario.jsp");
                rd.forward(request, response);
                
            }
            
        }catch(Exception ex){
            System.out.println("Erro:" + ex);
        }    
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
