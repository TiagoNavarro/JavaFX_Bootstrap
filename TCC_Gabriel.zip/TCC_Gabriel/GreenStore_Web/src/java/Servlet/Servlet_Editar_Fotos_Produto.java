/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlet;

import DAO.Produto_DAO;
import DAO.Usuario_DAO;
import Model.Usuario_Logado;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.List;
import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 *
 * @author User
 */
public class Servlet_Editar_Fotos_Produto extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Servlet_Editar_Fotos_Produto() {
            super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		/*Obtem o caminho relatorio da pasta img*/
		String path = request.getServletContext().getRealPath("img")+ File.separator;
		
                System.out.println("OLA:" + path);
                
		File files = new File(path);
		response.setContentType("image/jpeg");
		
		/*Mostra o arquivo que está na pasta img onde foi realizado o upload*/
		for (String file : files.list()) {
			File f = new File(path + file);
			BufferedImage bi = ImageIO.read(f);
			OutputStream out = response.getOutputStream();
			ImageIO.write(bi, "jpg", out);
                        System.out.println(f);
			out.close();
                        System.out.println(out);
		}
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
            int foto = Integer.valueOf( request.getParameter("foto") );
            
		/*Identifica se o formulario é do tipo multipart/form-data*/
			try {
				
                            /*Faz o parse do request*/
				List<FileItem> multiparts = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);

                                int id = Servlet_Produto_Especifico.id_produto;
                               
				/*Escreve a o arquivo na pasta img*/
				for (FileItem item : multiparts) {
					if (!item.isFormField()) {
                                            
                                            Produto_DAO dao = new Produto_DAO();
                                            
                                            if(foto == 1){
                                                
						item.write(new File("C:\\TCC\\GreenStore_Web\\web\\imagens\\imagens_produtos\\produto_" + id + "_1.jpg"));
                                                
                                                String foto_1 = String.valueOf(new File("imagens\\imagens_produtos\\produto_" + id + "_1.jpg"));
                                             
                                                dao.update_fotos(id, foto_1, null, null);
                                                
                                            }else if(foto == 2){
                                                 
                                                item.write(new File("C:\\TCC\\GreenStore_Web\\web\\imagens\\imagens_produtos\\produto_" + id + "_2.jpg"));
                                                
                                                String foto_2 = String.valueOf(new File("imagens\\imagens_produtos\\produto_" + id + "_2.jpg"));
                                            
                                                dao.update_fotos(id, null, foto_2, null);
                                                
                                            }else if(foto == 3){    
                                                
                                                item.write(new File("C:\\TCC\\GreenStore_Web\\web\\imagens\\imagens_produtos\\produto_" + id + "_3.jpg"));
                                                
                                                String foto_3 = String.valueOf(new File("imagens\\imagens_produtos\\produto_" + id + "_3.jpg"));
                                            
                                                dao.update_fotos(id, null, null, foto_3);
                                                
                                            }    
                                                
                                                request.getRequestDispatcher("/meus_produtos.jsp").forward(request, response);
					}
				}

			} catch (Exception ex) {
                            
                            System.out.println("Erro: " + ex);
                            
		request.getRequestDispatcher("/editar_produto.jsp").forward(request, response);
			}


	}

}
