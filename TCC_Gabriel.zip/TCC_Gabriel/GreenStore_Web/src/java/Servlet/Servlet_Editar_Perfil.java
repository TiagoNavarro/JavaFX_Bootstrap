package Servlet;

import DAO.Usuario_DAO;
import Model.Usuario_Logado;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author User
 */

public class Servlet_Editar_Perfil extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String Login = (String) request.getParameter("login");
        String Nome = (String) request.getParameter("nome");
        String Email = (String) request.getParameter("email");
        int Telefone = Integer.valueOf(request.getParameter("telefone"));
        
        Usuario_DAO dao = new Usuario_DAO();
        
        String ip_logado = request.getRemoteAddr();
          
        int id_usuario_logado = 0;

        for(Usuario_Logado usu : Servlet_index.lista_ids){
            if(usu.getIp().equals(ip_logado)){

                id_usuario_logado = usu.getId();

                dao.update_usuario(id_usuario_logado, Login, Nome, Email, Telefone);
                
                request.getRequestDispatcher("perfil.jsp").forward(request, response);
                
                break;

            }
        }
        
        request.getRequestDispatcher("editar_perfil.jsp").forward(request, response);
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
