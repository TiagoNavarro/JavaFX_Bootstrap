package Servlet;

import DAO.Favorito_DAO;
import DAO.Produto_DAO;
import Model.Produto;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class Servlet_Favoritar extends HttpServlet {

    public static String login_usuario = Servlet_index.login_usuario;
    public static int id_usuario = Servlet_index.id_usuario;
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
       
        //Pega o id do produto
        Integer id_produto = Integer.parseInt(request.getParameter("param"));
        
        System.out.println("azul" + id_produto);
        System.out.println("verde" + id_usuario);
       
        //Pega as informações do produto com o id dele
        Favorito_DAO dao_favorito = new Favorito_DAO();
        
        dao_favorito.insere_favorito(id_usuario, id_produto);
        
        Produto_DAO dao_produto = new Produto_DAO();
        
        ObservableList <Produto> Lista_Produtos = dao_produto.select_Produto();
        
        for(Produto prod : Lista_Produtos){
            
            if(prod.getId_produto() == id_produto){
                
                //Adiciona total de favoritos do produto a Numero_favoritos
                int favoritos = dao_favorito.select_Favorito_especifico(id_produto);
                
                dao_produto.favoritar_produto(favoritos, id_produto);
                
                prod.getNumero_favoritos();
                
                PrintWriter out = response.getWriter();
                
                // escreve o texto
                /*out.println("<html>");
                out.println("<body>");
                out.println("Primeira servlet");
                out.println("<br>");
                out.println("Nome: " + prod.getNome_produto());
                out.println("<br>");
                out.println("Preço: " + prod.getPreco_produto());
                out.println("<br>");
                out.println("Favoritos: " + favoritos);
                out.println("<br>");
                out.println("id Usuario: " + id_usuario);
                out.println("<br>");
                out.println("Login Usuario: " + login_usuario);
                out.println("</body>");
                out.println("</html>");*/
                
                RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
                rd.forward(request, response);
               
                break;
            }
            
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(Servlet_Favoritar.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(Servlet_Favoritar.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
