package Servlet;

import DAO.Produto_DAO;
import DAO.Usuario_DAO;
import Model.Produto;
import Model.Usuario;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import javafx.collections.ObservableList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Aluno
 */
public class Servlet_Produto_Especifico extends HttpServlet {

    public static int id_produto;
    
    public static int id_vendedor;
    public static String nome_produto;
    public static String vendedor_produto;
    public static Float preco_produto;
    public static int num_favorito;
    public static String categoria_produto;
    public static LocalDate data_postagem;
    public static String descricao_produto;
        
    public static String foto_1;
    public static String foto_2;
    public static String foto_3;
    
    public static int telefone;
    public static String email;
    public static String pais;
    public static String estado;
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        //Pega o id do produto
        int id_prod = Integer.parseInt(request.getParameter("param"));
        
        int pagina_produto = Integer.parseInt(request.getParameter("pg_prod"));
        
        Produto_DAO dao_produto = new Produto_DAO();
        
        ObservableList <Produto> lista_produto = dao_produto.select_Produto();
        
        Usuario_DAO dao_usuario = new Usuario_DAO();
        
        ObservableList <Usuario> lista_usuarios = dao_usuario.select_Usuario();
        
        for(Produto prod : lista_produto){
            
            if(prod.getId_produto() == id_prod){
                
                id_produto = prod.getId_produto();
                
                nome_produto = prod.getNome_produto();
                vendedor_produto = prod.getVendedor_produto();
                preco_produto = prod.getPreco_produto();
                num_favorito = prod.getNumero_favoritos();
                categoria_produto = prod.getCategoria_produto();
                data_postagem = prod.getData_postagem();
                descricao_produto = prod.getDescricao_produto();

                foto_1 = prod.getFoto_1();
                foto_2 = prod.getFoto_2();
                foto_3 = prod.getFoto_3();
                
                id_vendedor = prod.getId_vendedor();
                
                for(Usuario usu : lista_usuarios){
                  
                    if(usu.getId_usuario() == id_vendedor){
                      
                        telefone = usu.getTelefone();
                        email = usu.getEmail();
                        pais = usu.getPais();
                        estado = usu.getEstado();
                        
                    }
                    
                }
                
                if(pagina_produto == 1){
                    RequestDispatcher rd = request.getRequestDispatcher("produto_especifico.jsp");
                    rd.forward(request, response);
                }else{
                    RequestDispatcher rd = request.getRequestDispatcher("meu_produto_especifico.jsp");
                    rd.forward(request, response);
                }
                
                break;
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
