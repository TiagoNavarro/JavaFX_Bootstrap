package Servlet;

import DAO.Usuario_DAO;
import Model.Usuario;
import Model.Usuario_Logado;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Inet4Address;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class Servlet_index extends HttpServlet {

    public static String login_usuario;
    public static int id_usuario;
    public static String ip_logado;
    
    public static ObservableList <Usuario_Logado> lista_ids = FXCollections.observableArrayList();;
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException {
        response.setContentType("text/html;charset=UTF-8");
        
            String email_login = (String) request.getParameter("email_login");
            String senha_login = (String) request.getParameter("senha_login");
            
            Usuario_DAO dao = new Usuario_DAO();
            ObservableList <Usuario> user = dao.select_Usuario();
            
            for(Usuario usu : user ){
                
                if( ( email_login.equals(usu.getLogin()) || email_login.equals(usu.getEmail()) ) && senha_login.equals( usu.getSenha() ) ){
                    
                    login_usuario = usu.getLogin();
                    id_usuario = usu.getId_usuario();
        
                    ip_logado = request.getRemoteAddr();
                    
                    id_usuario(request.getRemoteAddr());
                    
                    System.out.println("OLA: " + request.getRemoteAddr());
                    
                    request.setAttribute("message", "Login realizado com sucesso!");
                    request.setAttribute("css_class", "sucesso");
                    
                    RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
                    rd.forward(request, response);
                    
                    break;
                }
                
            }
            
            
            request.setAttribute("message", "Erro ao realizar o login!");
            request.setAttribute("css_class", "erro");
            
            RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
            rd.forward(request, response);
        
        }

    public void id_usuario(String i){
        
        String ip = i;
        Usuario_Logado user = new Usuario_Logado();
        user.setId(id_usuario);
        user.setIp(ip);
        user.setNome(login_usuario);
        lista_ids.add(user);
        
    }
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Servlet_index.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Servlet_index.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
