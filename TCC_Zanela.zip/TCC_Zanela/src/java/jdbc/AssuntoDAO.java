package jdbc;

import static java.lang.Integer.parseInt;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Assunto;

public class AssuntoDAO {
    static Connection c;
    
    public static void insereAssunto(Assunto assunto){
        c = ConnectionFactory.getConnection();
        
        String sql = "INSERT INTO assunto(nomeassunto,textoapresentacao) "
                + "VALUES (?,?);";
        try{
            PreparedStatement ppstt = c.prepareStatement(sql);
            ppstt.setString(1,assunto.getNomeAssunto());
            ppstt.setString(2,assunto.getTextoApresentacao());
            ppstt.execute();
            ppstt.close();
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
    
    public List<Assunto> getAssunto(){
        List<Assunto> assuntos = new ArrayList<Assunto>();
        String sql = "SELECT * FROM assunto;";
        c = ConnectionFactory.getConnection();
        try{
            PreparedStatement ppstt = c.prepareStatement(sql);
            ResultSet rs = ppstt.executeQuery();
            while(rs.next()){
                Assunto assunto = new Assunto();
                assunto.setIdAssunto(rs.getInt("idassunto"));
                assunto.setNomeAssunto(rs.getString("nomeassunto"));
                assunto.setTextoApresentacao(rs.getString("textoapresentacao"));
                assuntos.add(assunto);
            }
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        
        return assuntos;
    }
    
    public static Assunto detalheAssunto(int idAssunto){
        System.out.println("Entrou");
        Assunto assunto = new Assunto();
        System.out.println("Erro 0.1");
        String sql= "SELECT * FROM assunto WHERE idassunto = "+idAssunto;
        System.out.println("Erro 0.2");
        c = ConnectionFactory.getConnection();
        System.out.println("Erro 0.3");
        try{
            System.out.println("Erro 0.4");
            PreparedStatement ppstt = c.prepareStatement(sql);
            System.out.println("Erro 0.5");
            ResultSet rs = ppstt.executeQuery();
            System.out.println("Erro 0.6");
            while(rs.next()){
                System.out.println("Erro 0.7");
                assunto.setIdAssunto(rs.getInt("idassunto"));
                System.out.println("Erro 0.8");
                assunto.setNomeAssunto(rs.getString("nomeAssunto"));
                System.out.println("Erro 0.9");
                assunto.setTextoApresentacao(rs.getString("textoapresentacao"));
                System.out.println("Erro 0.10");
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return assunto;
    }
    
    public static void apagaAssunto(int idAssunto){
        c = ConnectionFactory.getConnection();
        String sql = "DELETE FROM assunto WHERE idassunto = "+idAssunto+"; ";
        try{
            PreparedStatement ppstt = c.prepareStatement(sql);
            ppstt.executeQuery();
            ppstt.close();
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }finally{
            fecharConexao();
        }
    }
    
    private static void fecharConexao(){
        try{
        c.close();
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
}
