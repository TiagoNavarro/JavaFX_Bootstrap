package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
    
    public static Connection getConnection(){
            Connection c = null;
        try{
            carregaDriver();
            c = DriverManager.getConnection("jdbc:postgresql://localhost/tcczanela", "postgres", "12345");
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }finally{
            System.out.println("Tentando");
        }
        return c;
    }
    
    private static void carregaDriver(){
        try{
            Class.forName("org.postgresql.Driver");
        }catch(ClassNotFoundException e){
            System.out.println(e.getMessage());
        }
    }
}
