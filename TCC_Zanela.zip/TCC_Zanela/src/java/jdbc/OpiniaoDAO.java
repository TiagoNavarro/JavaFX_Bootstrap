/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Opiniao;

/**
 *
 * @author Janela
 */
public class OpiniaoDAO {
    
    static Connection c;
    
    public static void insereOpiniao(Opiniao opiniao){
        c = ConnectionFactory.getConnection();
        
        String sql = "INSERT INTO opiniao(texto,idassunto,idusuario) "
                + "VALUES (?,?,?);";
        try{
            PreparedStatement ppstt = c.prepareStatement(sql);
            ppstt.setString(1,opiniao.getTexto());
            ppstt.setInt(2,opiniao.getIdAssunto());
            ppstt.setInt(3,opiniao.getIdUsuario());
            ppstt.execute();
            ppstt.close();
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
    
    public static List<Opiniao> getOpiniao(int idAssunto){
        List<Opiniao> opinioes = new ArrayList<Opiniao>();
        String sql = "SELECT * FROM opiniao WHERE idassunto = "+idAssunto+" "
                + "ORDER BY opiniao desc";
        c = ConnectionFactory.getConnection();
        try{
            PreparedStatement ppstt = c.prepareStatement(sql);
            ResultSet rs = ppstt.executeQuery();
            while(rs.next()){
                Opiniao opiniao=new Opiniao();
                opiniao.setIdOpiniao(rs.getInt("idopiniao"));
                opiniao.setTexto(rs.getString("texto"));
                opiniao.setIdAssunto(rs.getInt("idassunto"));
                opiniao.setIdUsuario(rs.getInt("idusuario"));
                opinioes.add(opiniao);
            }
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        
        return opinioes;
    }
    
    
    public static void apagaOpiniao(int idOpiniao){
        c = ConnectionFactory.getConnection();
        String sql = "DELETE FROM opiniao WHERE idopiniao = "+idOpiniao+"; ";
        try{
            PreparedStatement ppstt = c.prepareStatement(sql);
            ppstt.executeQuery();
            ppstt.close();
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }finally{
            fecharConexao();
        }
    }
    
    public static void apagaAssuntos(int idAssunto){
        c = ConnectionFactory.getConnection();
        String sql = "DELETE FROM opiniao WHERE idassunto = "+idAssunto+"; ";
        try{
            PreparedStatement ppstt = c.prepareStatement(sql);
            ppstt.executeQuery();
            ppstt.close();
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }finally{
            fecharConexao();
        }
    }
    
    private static void fecharConexao(){
        try{
        c.close();
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
}
