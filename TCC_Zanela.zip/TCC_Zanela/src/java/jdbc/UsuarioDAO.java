package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Usuario;

public class UsuarioDAO {
    static Connection c;
    
    public static boolean insereUsuario(Usuario usuario){
        c = ConnectionFactory.getConnection();
        
        String sql = "INSERT INTO usuario(nome,email,login,senha,classe) "
                + "VALUES (?,?,?,?,?);";
        try{
            PreparedStatement ppstt = c.prepareStatement(sql);
            ppstt.setString(1,usuario.getNome());
            ppstt.setString(2,usuario.getEmail());
            ppstt.setString(3,usuario.getLogin());
            ppstt.setString(4,usuario.getSenha());
            ppstt.setString(5,usuario.getClasse());
            ppstt.execute();
            ppstt.close();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public static List<Usuario> getUsuario(){
        List<Usuario> usuarios = new ArrayList<Usuario>();
        String sql = "SELECT * FROM usuario;";
        c = ConnectionFactory.getConnection();
        try{
            PreparedStatement ppstt = c.prepareStatement(sql);
            ResultSet rs = ppstt.executeQuery();
            while(rs.next()){
                Usuario usuario = new Usuario();
                usuario.setIdUsuario(rs.getInt("idusuario"));
                usuario.setClasse(rs.getString("classe"));
                usuario.setEmail(rs.getString("email"));
                usuario.setLogin(rs.getString("login"));
                usuario.setNome(rs.getString("nome"));
                usuario.setSenha(rs.getString("senha"));
                usuarios.add(usuario);
            }
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        
        return usuarios;
    }
    
    public Usuario getUsuario(String login, String senha){
        String sql = "SELECT * FROM usuario WHERE login = ? AND senha = ?";
        c = ConnectionFactory.getConnection();
        try{
            PreparedStatement ppstt = c.prepareStatement(sql);
            ppstt.setString(1,login);
            ppstt.setString(2,senha);
            ResultSet rs = ppstt.executeQuery();
            if(rs.next()){
                Usuario usuario = new Usuario();
                usuario.setIdUsuario(rs.getInt("idusuario"));
                usuario.setClasse(rs.getString("classe"));
                usuario.setEmail(rs.getString("email"));
                usuario.setLogin(rs.getString("login"));
                usuario.setNome(rs.getString("nome"));
                usuario.setSenha(rs.getString("senha"));
                
                return usuario;
            }
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        
        return null;
    }
    
    
    public static void apagaUsuario(int idusuario){
        c = ConnectionFactory.getConnection();
        String sql = "DELETE FROM usuario WHERE idusuario = "+idusuario+"; ";
        try{
            PreparedStatement ppstt = c.prepareStatement(sql);
            ppstt.executeQuery();
            ppstt.close();
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }finally{
            fecharConexao();
        }
    }
    
    private static void fecharConexao(){
        try{
        c.close();
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
}
