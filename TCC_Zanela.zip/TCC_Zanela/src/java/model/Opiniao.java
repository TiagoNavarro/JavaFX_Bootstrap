package model;
public class Opiniao {
    private int idOpiniao;
    private String nomeConta;
    private String texto;
    private int idAssunto;
    private int idUsuario;

    public Opiniao() {
    }

    public int getIdOpiniao() {
        return idOpiniao;
    }

    public void setIdOpiniao(int idOpiniao) {
        this.idOpiniao = idOpiniao;
    }

    public String getNomeConta() {
        return nomeConta;
    }

    public void setNomeConta(String nomeConta) {
        this.nomeConta = nomeConta;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public int getIdAssunto() {
        return idAssunto;
    }

    public void setIdAssunto(int idAssunto) {
        this.idAssunto = idAssunto;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }
}
