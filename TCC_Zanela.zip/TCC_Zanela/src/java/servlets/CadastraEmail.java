/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jdbc.UsuarioDAO;
import model.Usuario;

/**
 *
 * @author Janela
 */
public class CadastraEmail extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8"); 
        try (PrintWriter out = response.getWriter()) {
            Usuario usuario = new Usuario();
            String nome = request.getParameter("nNome");
            String email = request.getParameter("nEmail");
            String login = request.getParameter("nLogin");
            String senha = request.getParameter("nSenha");
            String confirma = request.getParameter("nConfirma");
            String Classe = request.getParameter("nClasse");
            if(senha.equals(confirma)){
                if(Classe.equals("1")){
                    usuario.setNome(nome);
                    usuario.setClasse("Administrador");
                    usuario.setEmail(email);
                    usuario.setLogin(login);
                    usuario.setSenha(senha);

                    
                    boolean b;
                    b = UsuarioDAO.insereUsuario(usuario);
                    if(b == false){
                        RequestDispatcher rd = request.getRequestDispatcher("NaoSalvo.html");
                        rd.forward(request, response);
                    }else{
                        RequestDispatcher rd = request.getRequestDispatcher("Salvo.html");
                        rd.forward(request, response);
                    }
                    
                    
                }else if(Classe.equals("2")){
                    usuario.setNome(nome);
                    usuario.setClasse("Não Administrador");
                    usuario.setEmail(email);
                    usuario.setLogin(login);
                    usuario.setSenha(senha);

                    UsuarioDAO.insereUsuario(usuario);
                    RequestDispatcher rd = request.getRequestDispatcher("Salvo.html");
                    rd.forward(request, response);
                }
                
            }else{
                RequestDispatcher rd = request.getRequestDispatcher("NaoSalvo.html");
                rd.forward(request, response);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

