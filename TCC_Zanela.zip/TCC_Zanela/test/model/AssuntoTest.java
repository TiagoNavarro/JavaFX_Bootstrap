/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Janela
 */
public class AssuntoTest {
    
    public AssuntoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getIdAssunto method, of class Assunto.
     */
    @Test
    public void testaGetESetNome(){
        String nomeAssunto = "nomeAssunto";
        Assunto assunto = new Assunto();
        assunto.setNomeAssunto(nomeAssunto);
        
        String testa = assunto.getNomeAssunto();
        assertEquals(testa,nomeAssunto);
    }
    
    @Test
    public void testaGetESetId(){
        int idAssunto = 80;
        Assunto assunto = new Assunto();
        assunto.setIdAssunto(idAssunto);
        
        int testa = assunto.getIdAssunto();
        assertEquals(testa,idAssunto);
    }
    
    @Test
    public void testaGetESetTexto(){
        /*
        Este método precisa dar resultados diferentes
        Caso os resultados seja iguais, dará erro.
        */
        String texto = "textoApresentacao 1";
        Assunto assunto = new Assunto();
        assunto.setTextoApresentacao(texto);
        
        String testa = "textoApresetacao 2";
        if(texto.equals(testa)){
            fail("os valores são iguais e devem ser trocados");
        }
    }
}
