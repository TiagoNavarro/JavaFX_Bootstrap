/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.Paragraph;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import static java.lang.Double.parseDouble;
import static java.lang.Integer.parseInt;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javax.swing.JOptionPane;
import jdbc.FuncionarioDAO;
import static jdbc.FuncionarioDAO.insereFuncionario;
import model.Funcionario;

/**
 *
 * @author Tiago
 */
public class TabelasController implements Initializable {
    
    private ObservableList<String> tipoContrato = FXCollections.observableArrayList("Efetivo","Temporário","Terceirizado");
    
    //COMBOBOX
    @FXML ComboBox cbBoxTipo;
    
    //CADASTRO
    @FXML private Label id;
    @FXML private Label nome;
    @FXML private Label cargo;
    @FXML private Label data;
    @FXML private Label salario;
    @FXML private Label telefone;
    
    
    @FXML private TextField digitaID;
    @FXML private TextField digitaNome;
    @FXML private TextField digitaCargo;
    @FXML private TextField digitaSalario;
    @FXML private TextField digitaTelefone;
    
    @FXML private Button btenviar;
    @FXML private Button btsair;
    @FXML private Button btlimpar;
    @FXML private Button btpdf;
    
    //DATA
    @FXML private DatePicker datanasc;
    
    //PESQUISA
    @FXML private Label pesquisa;
    @FXML private TextField digitaPesquisa;
    
    @FXML private Button btprocurar;
    @FXML private Button btexcluir;
    
    //TABELA
    @FXML TableView<Funcionario> TabelaID;
    @FXML TableColumn <Funcionario,Integer>colunaID;
    @FXML TableColumn <Funcionario,String>colunaNOME;
    @FXML TableColumn <Funcionario,String>colunaCARGO;
    @FXML TableColumn <Funcionario,String>colunaTIPO;
    @FXML TableColumn <Funcionario,String>colunaDATA;
    @FXML TableColumn <Funcionario,String>colunaSALARIO;
    @FXML TableColumn <Funcionario,String>colunaTELEFONE;
    
    private ObservableList<Funcionario> funcionarios;
    private static Funcionario selecionado;
    
    @FXML
    private void deletaFuncionario(ActionEvent event){
            if(TabelasController.selecionado !=null){
                FuncionarioDAO dao = new FuncionarioDAO();
                dao.deletaFuncionario(TabelasController.selecionado);
                Alert a=new Alert(Alert.AlertType.CONFIRMATION);
                a.setHeaderText("Funcionario deletado com sucesso!");
                a.showAndWait();
                preencheTabela();
            }else{
                Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Por favor, selecione um Funcionário!");
                a.showAndWait();
            }
    }
    
    @FXML
    private void ClicouCAD(ActionEvent event) {
        if(digitaNome.getText().equals("") || digitaCargo.getText().equals("") 
          || datanasc.getValue() == null || cbBoxTipo.getValue() == null 
          || digitaSalario.getText().equals("") || digitaTelefone.getText().equals("") ){
           
           Alert c = new Alert(Alert.AlertType.WARNING);
                c.setTitle("ATENÇÃO");
                c.setHeaderText("Campos vazios");
                c.setContentText("Por favor, não deixe campos vazios");
                c.showAndWait();
                
        }else{
           try{
               Funcionario fun = new Funcionario();
               fun.setNome(digitaNome.getText());
               fun.setCargo(digitaCargo.getText());
               fun.setSalario(parseDouble(digitaSalario.getText()));
               fun.setData(datanasc.getValue().toString());
               fun.setTipo(cbBoxTipo.getValue().toString());
               fun.setTelefone(parseInt(digitaTelefone.getText()));
               insereFuncionario(fun);     
               
               Alert a = new Alert(Alert.AlertType.INFORMATION);
                    a.setTitle("VERIFICAÇÃO DE CADASTRO");
                    a.setHeaderText("Campos digitados corretamente");
                    a.setContentText("OK, Cadastro realizado");
                    a.showAndWait();
                    clearForm();
                    preencheTabela();
           }catch(Exception e){
               System.out.println("erro ao cadastrar: " + e.getMessage());
                
           }
       }
    }
    private void clearForm() {
        digitaID.clear();
        digitaNome.clear();
        digitaCargo.clear();
        digitaSalario.clear();
        digitaTelefone.clear();
        datanasc.setValue(null);
        cbBoxTipo.setValue(null);
    }
    
    
    public void LimparCampos(ActionEvent event){
        digitaID.setText("");
        digitaNome.setText("");
        digitaCargo.setText("");
        digitaSalario.clear();
        digitaTelefone.clear();
        datanasc.setValue(null);
        cbBoxTipo.setValue(null);
    }
   
    public void preencheTabela(){
        //ASSOCIA OS CAMPOS DA TABLE VIEW COM OS CAMPOS DO BANCO DE DADOS
        colunaNOME.setCellValueFactory(new PropertyValueFactory("nome"));
        colunaCARGO.setCellValueFactory(new PropertyValueFactory("cargo"));
        colunaDATA.setCellValueFactory(new PropertyValueFactory("data"));
        colunaTIPO.setCellValueFactory(new PropertyValueFactory("tipo"));
        colunaSALARIO.setCellValueFactory(new PropertyValueFactory("salario"));
        colunaTELEFONE.setCellValueFactory(new PropertyValueFactory("telefone"));
        colunaID.setCellValueFactory(new PropertyValueFactory("idFunc"));
        //BUSCA DADOS NO BD E MOSTRA NA TABLE VIEW.
        //O OBJETO FUNCS RECEBE DO DAO OS ATRIBUTOS DO OBJETO 'F'
        //CRIADO NO FUNCIONARIODAO.
        FuncionarioDAO dao = new FuncionarioDAO();
        funcionarios = dao.getFuncs();
        TabelaID.setItems(funcionarios);
    }
    
    public void pesquisa(){
        ObservableList<Funcionario> funcs = FXCollections.observableArrayList();
        
        for(int x=0; x<funcionarios.size();x++){
            if(funcionarios.get(x).getNome().toUpperCase().contains(digitaPesquisa.getText().toUpperCase())){
                funcs.add(funcionarios.get(x));
            }
        }
        TabelaID.setItems(funcs);
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //COMBOBOX COM O ATRIBUTO QUE ELE VAI RECEBER
         cbBoxTipo.setItems(tipoContrato);
         preencheTabela();
         
         TabelaID.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {

             @Override
             public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                 if(newValue !=null){
                    TabelasController.selecionado = (Funcionario) newValue;
                 }else{
                     TabelasController.selecionado = null;
                 }
             }
         });
         
         digitaPesquisa.setOnKeyReleased((KeyEvent e)->{
             pesquisa();
         });
         
         btprocurar.setOnMouseClicked((MouseEvent e)->{
             if(e.getButton() == MouseButton.PRIMARY){
                 pesquisa();
             }
         });
    }    
    
    @FXML
    public void GeraPdf () throws FileNotFoundException, DocumentException{
        FuncionarioDAO dao = new FuncionarioDAO();
        ObservableList<Funcionario> funcSe = dao.getFuncs();
        
       Document doc = new Document();
       PdfWriter.getInstance(doc, new FileOutputStream("C:/Users/Tiago/Desktop/relatorio.pdf"));
       doc.open();
       doc.add(new Paragraph("Relatórios em PDF de usuários: "+"\n"+ funcSe)); 
       doc.close();
        
    }
    
}
