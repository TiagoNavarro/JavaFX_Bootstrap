/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;


/**
 *
 * @author Tiago
 */
public class Funcionario {
    private int idFunc;
    private String nome;
    private String cargo;
    private String tipo;
    private String data;
    private double salario;
    private int telefone;
    
    public Funcionario() {
    }
    
    public Funcionario(int idFunc, String nome, String cargo, String tipo, String data, double salario, int telefone) {
        this.idFunc = idFunc;
        this.nome = nome;
        this.cargo = cargo;
        this.tipo = tipo;
        this.data = data;
        this.salario = salario;
        this.telefone = telefone;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    
    public int getIdFunc() {
        return idFunc;
    }

    public void setIdFunc(int idFunc) {
        this.idFunc = idFunc;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "Usuários cadastrados:  " + "\n"+
                " nome: " + nome + "\n"+
                " cargo: " + cargo + "\n"+
                " tipo: " + tipo + "\n"+
                " data: " + data + "\n"+
                " salario: " + salario + "\n"+
                "\n";
    }
    
}