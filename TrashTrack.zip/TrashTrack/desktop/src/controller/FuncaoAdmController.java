/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
//import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.Dicas;
import jdbc.DicasDAO;
import static jdbc.DicasDAO.InsereDica;
import jdbc.LixoDAO;
import jdbc.PropostaDAO;
import jdbc.UsuarioDAO;
import model.Lixo;
import model.Proposta;
import model.Usuario;
/**
 * FXML Controller class
 *
 * @author Beatriz
 */
public class FuncaoAdmController implements Initializable {
    @FXML private Button btsair;
    @FXML private Button deletalixo;
    public static Lixo lixx;
    @FXML private Button atualizaLixo;
    @FXML private Button atualizaUsuario;
    @FXML private Button atualizaProp;
    //PROPOSTA
    @FXML private TableView <Proposta> tabProp;
    
    @FXML private TabPane funnAdmin;

    @FXML private Tab tabVisuProp;
    @FXML private Tab tabVisuGraficos;
    @FXML private Tab tabLixo;
    @FXML private Tab tabBV;
    @FXML private Tab tabUsu;

    @FXML private TableView <Lixo> tvLixo;
    @FXML private TableColumn <Lixo, Integer > colID;
    @FXML private TableColumn <Lixo, String > colEmaill;
    @FXML private TableColumn <Lixo, String > colEndereco;
    @FXML private TableColumn <Lixo, String > colBairro;
    @FXML private TableColumn <Lixo, String > colRua;
    @FXML private TableColumn <Lixo, String > colTipo; 
   
    
    //DICAS
    @FXML private Tab tabCadDicas;
    @FXML private TableView <Dicas> tvDicas;
    
    @FXML private TableColumn <Dicas, Integer > colCodigo;
    @FXML private TableColumn <Dicas, String> colDescricao;
    @FXML private TableColumn <Proposta, String> colEmail;
    @FXML private TableColumn <Dicas, Integer > colCodigo2;
    @FXML private TableColumn <Dicas, String> colDescricao2;
      
    @FXML private TextArea textDscricao;
    
    @FXML private TextField digitaPesquisa;
     
    @FXML private Label addnvdica;
    
    @FXML private Button btAddDICA;
    @FXML private Button btexcluiDICA;
    @FXML private Button btVisu;
     @FXML private Button btprocurar;
    
    private static Dicas opcaoDICA;
    private static Lixo opcaoLixo;
    private static Lixo selecionado;
    static Proposta selecionado2;
    private static Usuario opUsu;
    static Usuario selecionado3;
  private  ObservableList<Lixo> lixoLista;
    
    @FXML private Button geraPdf;
  
    //usuario
    @FXML private TableColumn <Usuario, Integer > colIDusu;
    @FXML private TableColumn <Usuario, String> colNome;
    @FXML private TableColumn <Usuario, String> colSobrenome;
    @FXML private TableColumn <Usuario, String > colEmailCad;
    @FXML private TableColumn <Usuario, String> colUsuario;
    @FXML private TableColumn <Usuario, String> colTele;
    @FXML private TableView <Usuario> tvUsuario;
    ObservableList<Usuario> ListaUsu;
    
    @FXML private Button delUsu;
    @FXML private TextField digitaUsu;
    
    
    public void start(Stage stageAdmin) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("FuncaoAdm.fxml"));
        
        Scene scene = new Scene(root);
        stageAdmin.setTitle("Administrador");
        stageAdmin.setScene(scene);
        stageAdmin.show();
        }
     
        @FXML
        public void Sair(ActionEvent t) {  
            Stage stage = (Stage) btsair.getScene().getWindow();  
            stage.close();  
            }  
        
        @FXML
        public void CadDicas(ActionEvent t) {  
            if(textDscricao.getText().equals("") ){
          /** Alert al = new Alert (Alert.AlertType.WARNING);
          al.setTitle("Atenção!");
           al.setHeaderText("Os Campos Estão Vazios");
          al.setContentText("Por favor, preencha os campos!");
           al.showAndWait(); */
             
         }else {
            try {
                Dicas dica = new Dicas ();
                dica.setDescricao(textDscricao.getText());
                InsereDica(dica);
            
        /**    Alert a = new Alert(Alert.AlertType.INFORMATION);
            a.setTitle("VERIFICAÇÃO DE CADASTRO");
            a.setHeaderText("Campos digitados corretamente");
            a.setContentText("OK, Cadastro realizado");
           a.showAndWait();*/
               MostraDicas();
               clearForm();
               
            }catch (Exception e){
                System.out.println("Erro ao Cadastrar uma dica: " + e.getMessage());
            }    
        }
    }
    
        
    public void MostraDicas(){
        colCodigo2.setCellValueFactory(new PropertyValueFactory("codigo"));
        colDescricao2.setCellValueFactory(new PropertyValueFactory("descricao"));
        DicasDAO dao = new DicasDAO();
        ObservableList<Dicas> dicas = dao.getDicas();
        tvDicas.setItems(dicas);
        tvDicas.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {

            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
               opcaoDICA = (Dicas) newValue;
            }
        });

    }
    
    public void MostraUsuario(){
        colIDusu.setCellValueFactory(new PropertyValueFactory("id"));
        colNome.setCellValueFactory(new PropertyValueFactory("nome"));
        colSobrenome.setCellValueFactory(new PropertyValueFactory("sobrenome"));
        colEmailCad.setCellValueFactory(new PropertyValueFactory("email"));
        colUsuario.setCellValueFactory(new PropertyValueFactory("usuario"));
        colTele.setCellValueFactory(new PropertyValueFactory("telefone"));
        UsuarioDAO dao = new UsuarioDAO();
        ObservableList<Usuario> usus = dao.consultaUsuario();
        tvUsuario.setItems(usus);
        
        tvUsuario.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {

            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
               opUsu = (Usuario) newValue;
            }
        });

    
    }


    public void MostraLixo(){
        colEmaill.setCellValueFactory(new PropertyValueFactory("email"));
        colEndereco.setCellValueFactory(new PropertyValueFactory("endereco"));
        colBairro.setCellValueFactory(new PropertyValueFactory("bairro"));
        colRua.setCellValueFactory(new PropertyValueFactory("rua"));
         LixoDAO dao = new LixoDAO();
         ObservableList<Lixo> lixos = dao.getLixo();
         tvLixo.setItems(lixos);
         
         tvLixo.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {

            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
               opcaoLixo = (Lixo) newValue;
            }
        });

    
    }

   
    @FXML
    public void grafico() {
        btVisu.setOnMouseClicked((MouseEvent b) -> {
            GraficoController opens= new GraficoController();
            try {
                opens.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(GraficoController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

    }
    public void clearForm(){
        textDscricao.clear();
    }
       
    @FXML
      private void atualizaTabelaUsuario(){
        UsuarioDAO usua = new UsuarioDAO(); 
        ObservableList<Usuario> usu = usua.consultaUsuario();
        tvUsuario.setItems(usu); 
    }
     
      @FXML
      private void atualizaTabelaPropostas(){
        PropostaDAO prop = new PropostaDAO(); 
        ObservableList<Proposta> pro = prop.getProposta();
        tabProp.setItems(pro); 
    }
    
    
    @FXML
      private void atualizaTabelaLixo(){
        LixoDAO lixo = new LixoDAO(); 
        ObservableList<Lixo> lix = lixo.getLixo();
        tvLixo.setItems(lix); 
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       MostraDicas();
       MostraProposta();
       MostraLixo();
       MostraUsuario();


       tvUsuario.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {

             @Override
             public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                 if(newValue !=null){
                    FuncaoAdmController.opUsu = (Usuario) newValue;
                 }else{
                     FuncaoAdmController.opUsu = null;
                 }
             }
         });
       
       tvLixo.getSelectionModel().selectedItemProperty().addListener(new ChangeListener(){
           @Override
           public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                 if(newValue !=null){
                    FuncaoAdmController.opcaoLixo = (Lixo) newValue;
                 }else{
                     FuncaoAdmController.opcaoLixo = null;
                     }
               }
       });
       
       tabProp.getSelectionModel().selectedItemProperty().addListener(new ChangeListener(){
           @Override
           public void changed(ObservableValue observable, Object oldValue, Object newValue){
               if(newValue != null){
                   FuncaoAdmController.selecionado2 = (Proposta) newValue;
                }else{
                   FuncaoAdmController.selecionado2 = null;
               }
           }
       });
       
    }
       
    @FXML
    private void deletaUsuario(ActionEvent event){
        if(FuncaoAdmController.opUsu !=null){
            UsuarioDAO dao = new UsuarioDAO();
            dao.deletaUsuario(FuncaoAdmController.opUsu);
                MostraUsuario();

            
            
        }
    }
    @FXML
    private void deletaDica(ActionEvent event){
            if(FuncaoAdmController.opcaoDICA !=null){
                DicasDAO dao = new DicasDAO();
                dao.deletaDica(FuncaoAdmController.opcaoDICA);
                MostraDicas();
              /**  Alert a=new Alert(Alert.AlertType.CONFIRMATION);
                a.setHeaderText("Dica deletada com sucesso!");
                a.showAndWait();
                MostraDicas();
            }else{
                Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Por favor, selecione uma Dica!");
                a.showAndWait();*/
            }
}
    @FXML
    private void deletaProposta(ActionEvent event){
            if(FuncaoAdmController.selecionado2 !=null){
                PropostaDAO dao3 = new PropostaDAO();
                dao3.deletaProposta(FuncaoAdmController.selecionado2);
                MostraProposta();
            /**    
                Alert a=new Alert(Alert.AlertType.CONFIRMATION);
                a.setHeaderText("Proposta deletada com sucesso!");
                a.showAndWait();
                
            }else{
                Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Por favor, selecione uma proposta!");
                a.showAndWait();*/
            }
    }
    public void MostraProposta(){
        
        colCodigo.setCellValueFactory(new PropertyValueFactory("codigo"));
        colDescricao.setCellValueFactory(new PropertyValueFactory("descricao"));
        colEmail.setCellValueFactory(new PropertyValueFactory("email"));
        PropostaDAO dao2 = new PropostaDAO();
        ObservableList<Proposta> proposta = dao2.getProposta();
        tabProp.setItems(proposta);
        tabProp.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
     @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
               selecionado2 = (Proposta) newValue;
            }
            
        });
               }
    @FXML
    private void deletaLixo(ActionEvent event){
            if(FuncaoAdmController.opcaoLixo !=null){
                LixoDAO dao = new LixoDAO();
                dao.deletaDica(FuncaoAdmController.opcaoLixo);
                MostraLixo();
            /**    Alert a=new Alert(Alert.AlertType.CONFIRMATION);
                a.setHeaderText("Local deletado com sucesso!");
                a.showAndWait();*/
            }else{
               /** Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Por favor, selecione um Local!");
                a.showAndWait();
            }*/
}
    }
    
     @FXML
    public  void GeraPdf () throws FileNotFoundException, DocumentException{
        LixoDAO dao = new LixoDAO();
         ObservableList<Lixo> lixos = dao.getLixo();
        
       Document doc = new Document();
       PdfWriter.getInstance(doc, new FileOutputStream("C:/Users/Tiago/Desktop/testar.pdf"));
       doc.open();
       doc.add(new Paragraph("Informações das Denúncias:"+"\n"+ lixos)); 
       doc.close();
        
        //user.getId();
    }
    
    }    

               
       
       
  
    
