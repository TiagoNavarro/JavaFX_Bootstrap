/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Proposta;

/**
 *
 * @author Aluno
 */
public class PropostaDAO {
    private Connection c;
    public PropostaDAO(){
    
}
    
        public ObservableList<Proposta> getProposta(){
            Connection p = ConnectionFactory.getConnection();
        try{
            ObservableList<Proposta> propo = FXCollections.observableArrayList();
            PreparedStatement stmt = p.prepareStatement("SELECT * FROM propostas");
            ResultSet resul = stmt.executeQuery();
            
            while(resul.next()){
                Proposta prop = new Proposta ();
                 prop.setCodigo(resul.getInt("id_proposta"));
                prop.setDescricao(resul.getString("descricao"));
                prop.setEmail(resul.getString("email"));
                propo.add(prop);
            }

            stmt.executeQuery();
            resul.close();
            stmt.close();
            return propo;
           
        }catch(SQLException m){
                throw new RuntimeException(m);
        
        }
    }
        public void deletaProposta(Proposta Proposta ){
             String sql = "DELETE FROM propostas WHERE id_proposta =?";
             Connection c = ConnectionFactory.getConnection();
        try{
            PreparedStatement stmt = c.prepareStatement(sql);
            stmt.setInt(1, Proposta.getCodigo());
            stmt.execute();
            stmt.close();
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
   
    }
    }
   
   

       

