/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import jdbc.ConnectionFactory;
import model.Usuario;

/**
 *
 * @author Aluno
 */
public class UsuarioDAO {
    static Connection u;
    
    public ObservableList <Usuario> consultaUsuario(){
        Connection u = ConnectionFactory.getConnection();
        try{
                ObservableList <Usuario> usuarios = FXCollections.observableArrayList(); 
                PreparedStatement stmt = u.prepareStatement("SELECT * FROM cadastro");
                ResultSet rs = stmt.executeQuery();
                while(rs.next()){
                    Usuario usu = new Usuario();
                    usu.setId(rs.getLong("id"));
                    usu.setNome(rs.getString("nome"));
                    usu.setSobrenome(rs.getString("sobrenome"));
                    usu.setEmail(rs.getString("email"));
                    usu.setTelefone(rs.getString("telefone"));
                    usu.setUsuario(rs.getString("usuario"));
                    usu.setSenha(rs.getString("senha"));
                    
                    usuarios.add(usu);
                }
                stmt.executeQuery();
                rs.close();
                stmt.close();
            return usuarios;
            }catch (SQLException e){
                throw new RuntimeException(e);
            }
        }

    
    
    public void deletaUsuario(Usuario usu ){
             String sql = "DELETE FROM cadastro WHERE id =?";
             Connection c = ConnectionFactory.getConnection();
        try{
            PreparedStatement stmt = c.prepareStatement(sql);
            stmt.setLong(1, usu.getId());
            stmt.execute();
            stmt.close();
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
   
    }
    

}
