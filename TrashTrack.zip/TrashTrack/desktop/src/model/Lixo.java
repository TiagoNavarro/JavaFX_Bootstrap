/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;


/**
 *
 * @author Beatriz
 */
public class Lixo {
   private String bairro;
   private String rua;
   private String tipoLixo;
   private int id;
   private String endereco;
   private String email;

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Lixo() {
    }



    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

   
    public String getTipoLixo() {
        return tipoLixo;
    }

    public void setTipoLixo(String tipoLixo) {
        this.tipoLixo = tipoLixo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Lixo(String bairro, String rua, String tipoLixo, String endereco, String email) {
        this.bairro = bairro;
        this.rua = rua;
        this.tipoLixo = tipoLixo;
        this.endereco = endereco;
        this.email = email;
    }

    @Override
    public String toString() {
        return "Denúncias:  " + "\n"+
                " endereco=" + endereco + "\n"+
                " bairro=" + bairro + "\n"+
                " rua=" + rua + "\n"+
                " email=" + email + "\n"+
                "\n";
    }
    

   
}
