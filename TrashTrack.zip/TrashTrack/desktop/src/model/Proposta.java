/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Aluno
 */
public class Proposta {
     private String descricao;
     private int codigo;
     private String email;

    public Proposta(String descricao, int codigo, String email) {
        this.descricao = descricao;
        this.codigo = codigo;
        this.email = email;
    }
     
    public Proposta(){
        
    }
     

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
     
    /**
     * @return the Descricao
     */
    public String getDescricao() {
        return descricao;
    }

    /**
     * @param Descricao the Descricao to set
     */
    public void setDescricao(String Descricao) {
        this.descricao = Descricao;
    }

    /**
     * @return the ID
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @param ID the ID to set
     */
    public void setCodigo(int Codigo) {
        this.codigo = Codigo;
    }

    
}
