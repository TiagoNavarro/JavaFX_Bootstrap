/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jdbc.ConnectionFactory;
import model.Denuncias;
/**
 *
 * @author Aluno
 */
public class DenunciasDAO {
    static Connection u;
    
     
    public DenunciasDAO() throws ClassNotFoundException{
     DenunciasDAO.u = ConnectionFactory.getConnection();
    }
   
    public static void InserirDenuncias (Denuncias den) throws ClassNotFoundException{
      Connection u = ConnectionFactory.getConnection(); 
        String sql = "INSERT INTO denuncias(email,endereco,bairro,rua, tipo_lixo) "
                + "VALUES(?,?,?,?,?)";
        
              try{ 
                PreparedStatement stmt = u.prepareStatement (sql);
                stmt.setString(1, den.getEmail());
                stmt.setString(4, den.getEndereco());
                stmt.setString(2, den.getBairro());
                stmt.setString(3, den.getRua());
                stmt.setString(5, den.getTipoLixo());
                stmt.execute();
                stmt.close();

        
         }catch (SQLException p){
            System.out.println(p.getMessage());
        }
 }
}
