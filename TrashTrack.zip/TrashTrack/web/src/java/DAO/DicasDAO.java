/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jdbc.ConnectionFactory;
import model.Dicas;

/**
 *
 * @author Aluno
 */
public class DicasDAO {
  static Connection d;
    
     public DicasDAO() throws ClassNotFoundException {
        try{
            this.d = new ConnectionFactory().getConnection();
            
        }catch (ClassNotFoundException e){
            System.out.println(e.getMessage());
        } 
    }  
    
 
    public List <Dicas> consultaDicas(){
            try{
                List <Dicas> dic = new ArrayList<Dicas>(); 
                PreparedStatement stmt = this.d.prepareStatement("SELECT * FROM dicas");
                ResultSet rs = stmt.executeQuery();
                while(rs.next()){
                    Dicas dica= new Dicas ();
                    dica.setCodigo(rs.getInt("codigo"));
                    dica.setDescricao(rs.getString("descricao"));
                    
                    
                    dic.add(dica);
                }
                rs.close();
                stmt.close();
            return dic;
            }catch (SQLException e){
                throw new RuntimeException(e);
            }
        }

    

}
