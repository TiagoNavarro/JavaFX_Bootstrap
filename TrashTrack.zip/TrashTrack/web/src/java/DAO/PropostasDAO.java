/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jdbc.ConnectionFactory;
import model.Propostas;
import model.Propostas;

/**
 *
 * @author Aluno
 */
public class PropostasDAO {
     static Connection u;
    
     
    public PropostasDAO() throws ClassNotFoundException{
     PropostasDAO.u = ConnectionFactory.getConnection();
    }
   
    public static void InsereProposta (Propostas pro) throws ClassNotFoundException{
      Connection u = ConnectionFactory.getConnection(); 
        String sql = "INSERT INTO propostas(descricao,email) "
                + "VALUES(?,?)";
        
              try{ 
                PreparedStatement stmt = u.prepareStatement (sql);
                stmt.setString(1, pro.getDescricao());
                stmt.setString(2, pro.getEmail());
                stmt.execute();
                stmt.close();

        
         }catch (SQLException p){
            System.out.println(p.getMessage());
        }
 }


    

}
