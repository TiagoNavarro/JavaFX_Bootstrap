/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Aluno
 */
public class Denuncias {
    private String usuario;
    private String endereco;
    private String bairro;
    private String rua;
    private String tipoLixo;
    private int id_denuncia;
    private String email;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public String getTipoLixo() {
        return tipoLixo;
    }

    public void setTipoLixo(String tipoLixo) {
        this.tipoLixo = tipoLixo;
    }

    public int getId_denuncia() {
        return id_denuncia;
    }

    public void setId_denuncia(int id_denuncia) {
        this.id_denuncia = id_denuncia;
    }

    public Denuncias() {
    }

    
    public Denuncias(String usuario, String endereco, String bairro,String email, String rua, String tipoLixo, int id_denuncia) {
        this.usuario = usuario;
        this.endereco = endereco;
        this.bairro = bairro;
        this.rua = rua;
        this.tipoLixo = tipoLixo;
        this.id_denuncia = id_denuncia;
        this.email = email;
    }
    
    
    
    
    
}
