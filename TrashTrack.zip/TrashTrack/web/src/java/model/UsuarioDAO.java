/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jdbc.ConnectionFactory;
import model.Usuario;

/**
 *
 * @author Aluno
 */
public class UsuarioDAO {
    static Connection u;
    
     public UsuarioDAO() throws ClassNotFoundException {
        try{
            this.u = new ConnectionFactory().getConnection();
            
        }catch (ClassNotFoundException e){
            System.out.println(e.getMessage());
        } 
    }  
    public static void InsereUsuario (Usuario usu) throws ClassNotFoundException{
      Connection u = jdbc.ConnectionFactory.getConnection(); 
        String sql = "INSERT INTO cadastro(nome, sobrenome, email, telefone, usuario, senha) "
                + "VALUES(?,?,?,?,?,?)";
        
              try{ 
                PreparedStatement stmt = u.prepareStatement (sql);
                stmt.setString(1, usu.getNome());
                stmt.setString(2, usu.getSobrenome());
                stmt.setString(3, usu.getEmail());
                stmt.setString(4, usu.getTelefone());
                stmt.setString(5, usu.getUsuario());
                stmt.setString(6, usu.getSenha());

                
                stmt.execute();
                stmt.close();

        
         }catch (SQLException p){
            System.out.println(p.getMessage());
        }
 }

    public List <Usuario> consultaUsuario(){
            try{
                List <Usuario> usuarios = new ArrayList<Usuario>(); 
                PreparedStatement stmt = this.u.prepareStatement("SELECT * FROM cadastro");
                ResultSet rs = stmt.executeQuery();
                while(rs.next()){
                    Usuario usu = new Usuario();
                    usu.setId(rs.getLong("id"));
                    usu.setNome(rs.getString("nome"));
                    usu.setSobrenome(rs.getString("sobrenome"));
                    usu.setEmail(rs.getString("email"));
                    usu.setTelefone(rs.getString("telefone"));
                    usu.setUsuario(rs.getString("usuario"));
                    usu.setSenha(rs.getString("senha"));
                    
                    usuarios.add(usu);
                }
                rs.close();
                stmt.close();
            return usuarios;
            }catch (SQLException e){
                throw new RuntimeException(e);
            }
        }

    
    public Usuario getUsuario(String usuario, String senha) throws ClassNotFoundException, SQLException{
        String sql= "SELECT * FROM cadastro WHERE usuario=?, senha = ?";
        u = ConnectionFactory.getConnection();
        
        try{
            PreparedStatement stmt = u.prepareStatement(sql);
            stmt.setString(1, usuario);
            stmt.setString(2, senha);
            ResultSet rs = stmt.executeQuery();
            if(rs.next()){
               Usuario usu= new Usuario();
                    usu.setId(rs.getLong("id"));
                    usu.setNome(rs.getString("nome"));
                    usu.setSobrenome(rs.getString("sobrenome"));
                    usu.setEmail(rs.getString("email"));
                    usu.setTelefone(rs.getString("telefone"));
                    usu.setUsuario(rs.getString("usuario"));
                    usu.setSenha(rs.getString("senha"));
                    
                   return usu;
                }
        }catch (SQLException e){
            System.out.println(e.getMessage());

        }
        return null;
    }

}
