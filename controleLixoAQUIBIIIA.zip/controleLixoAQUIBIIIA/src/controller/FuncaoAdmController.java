/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.Dicas;
import jdbc.DicasDAO;
import static jdbc.DicasDAO.InsereDica;
import jdbc.LixoDAO;
import jdbc.PropostaDAO;
import model.Lixo;
import model.Proposta;
/**
 * FXML Controller class
 *
 * @author Beatriz
 */
public class FuncaoAdmController implements Initializable {
    @FXML private Button btsair;
    @FXML private Button deletalixo;
    //PROPOSTA
    @FXML private TableView tabProp;
    
    @FXML private TabPane funnAdmin;

    @FXML private Tab tabVisuProp;
    @FXML private Tab tabVisuGraficos;
    @FXML private Tab tabLixo;
    @FXML private Tab tabBV;

    @FXML private TableView <Lixo> tvLixo;
    @FXML private TableColumn <Lixo, Integer > colID;
    @FXML private TableColumn <Lixo, String > colNome;
    @FXML private TableColumn <Lixo, String > colBairro;
    @FXML private TableColumn <Lixo, String > colRua;
    @FXML private TableColumn <Lixo, LocalDate > colData;
  
    
    
    
    //DICAS
    @FXML private Tab tabCadDicas;
    @FXML private TableView <Dicas> tvDicas;
    
    @FXML private TableColumn <Dicas, Integer > colCodigo;
    @FXML private TableColumn <Dicas, String> colDescricao;
    
    @FXML private TableColumn <Dicas, Integer > colCodigo2;
    @FXML private TableColumn <Dicas, String> colDescricao2;
      
    @FXML private TextArea textDscricao;
    
    @FXML private TextField digitaPesquisa;
     
    @FXML private Label addnvdica;
    
    @FXML private Button btAddDICA;
    @FXML private Button btexcluiDICA;
    @FXML private Button btVisu;
     @FXML private Button btprocurar;
    
    private static Dicas opcaoDICA;
    private static Lixo opcaoLixo;
    private static Lixo selecionado;
    static Proposta selecionado2;
    ObservableList<Lixo> lixoLista;
    
    @FXML private ImageView b;
    public void start(Stage stageAdmin) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("FuncaoAdm.fxml"));
        
        Scene scene = new Scene(root);
        stageAdmin.setTitle("Administrador");
        stageAdmin.setScene(scene);
        stageAdmin.show();
        }
     
        @FXML
        public void Sair(ActionEvent t) {  
            Stage stage = (Stage) btsair.getScene().getWindow();  
            stage.close();  
            }  
        
        @FXML
        public void CadDicas(ActionEvent t) {  
            if(textDscricao.getText().equals("") ){
           Alert al = new Alert (Alert.AlertType.WARNING);
          al.setTitle("Atenção!");
           al.setHeaderText("Os Campos Estão Vazios");
          al.setContentText("Por favor, preencha os campos!");
           al.showAndWait(); 
             
         }else {
            try {
                Dicas dica = new Dicas ();
                dica.setDescricao(textDscricao.getText());
                InsereDica(dica);
            
            Alert a = new Alert(Alert.AlertType.INFORMATION);
            a.setTitle("VERIFICAÇÃO DE CADASTRO");
            a.setHeaderText("Campos digitados corretamente");
            a.setContentText("OK, Cadastro realizado");
           a.showAndWait();
               MostraDicas();
               clearForm();
               
            }catch (Exception e){
                System.out.println("Erro ao Cadastrar uma dica: " + e.getMessage());
            }    
        }
    }
    
        
    public void MostraDicas(){
        colCodigo2.setCellValueFactory(new PropertyValueFactory("codigo"));
        colDescricao2.setCellValueFactory(new PropertyValueFactory("descricao"));
        DicasDAO dao = new DicasDAO();
        ObservableList<Dicas> dicas = dao.getDicas();
        tvDicas.setItems(dicas);
        tvDicas.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {

            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
               opcaoDICA = (Dicas) newValue;
            }
        });

    }
    
   
    @FXML
    public void grafico() {
        btVisu.setOnMouseClicked((MouseEvent b) -> {
            GraficoController opens= new GraficoController();
            try {
                opens.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(GraficoController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

    }
    public void clearForm(){
        textDscricao.clear();
    }
    
    
    
     public void preencheTabelaLixo(){
     colID.setCellValueFactory(new PropertyValueFactory("id"));
     colNome.setCellValueFactory(new PropertyValueFactory("nome"));
     colBairro.setCellValueFactory(new PropertyValueFactory("bairro"));
     colRua.setCellValueFactory(new PropertyValueFactory("rua"));
     colData.setCellValueFactory(new PropertyValueFactory("data"));
     tvLixo.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
     @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
               opcaoLixo = (Lixo) newValue;
            }
            
        });
     LixoDAO lixo = new LixoDAO();
    //ObservableList<Lixo> liixo = lixo.getLixo();   
        LixoDAO lix = new LixoDAO();
        lixoLista = lix.getLixo();
        tvLixo.setItems(lixoLista);
         atualizaTabelaLixo();
    
    
     }
      private void atualizaTabelaLixo(){
        LixoDAO lixo = new LixoDAO(); 
        ObservableList<Lixo> lix = lixo.getLixo();
        tvLixo.setItems(lix); 
    }
      
      
    public void pesquisa(){
        ObservableList<Lixo> lixol = FXCollections.observableArrayList();
        for(int x=0; x<lixoLista.size();x++){
            if(lixoLista.get(x).getNome().toUpperCase().contains(digitaPesquisa.getText().toUpperCase())){
                lixol.add(lixoLista.get(x));
            }
        }
        tvLixo.setItems(lixol);
        
    }
    
        
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       MostraDicas();
       preencheTabelaLixo();
       MostraProposta();
        
       tvLixo.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {

             @Override
             public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                 if(newValue !=null){
                    FuncaoAdmController.selecionado = (Lixo) newValue;
                 }else{
                     FuncaoAdmController.selecionado = null;
                 }
             }
         });
         
         digitaPesquisa.setOnKeyReleased((KeyEvent e)->{
             pesquisa();
         });
         
         btprocurar.setOnMouseClicked((MouseEvent e)->{
             if(e.getButton() == MouseButton.PRIMARY){
                 pesquisa();
             }
         });
    }    
    @FXML
    private void deletaDica(ActionEvent event){
            if(FuncaoAdmController.opcaoDICA !=null){
                DicasDAO dao = new DicasDAO();
                dao.deletaDica(FuncaoAdmController.opcaoDICA);
                Alert a=new Alert(Alert.AlertType.CONFIRMATION);
                a.setHeaderText("Dica deletada com sucesso!");
                a.showAndWait();
                MostraDicas();
            }else{
                Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Por favor, selecione uma Dica!");
                a.showAndWait();
            }
}
    @FXML
    private void deletaProposta(ActionEvent event){
            if(FuncaoAdmController.selecionado2 !=null){
                PropostaDAO dao3 = new PropostaDAO();
                dao3.deletaProposta(FuncaoAdmController.selecionado2);
                
                Alert a=new Alert(Alert.AlertType.CONFIRMATION);
                a.setHeaderText("Proposta deletada com sucesso!");
                a.showAndWait();
                MostraProposta();
            }else{
                Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Por favor, selecione uma proposta!");
                a.showAndWait();
            }
    }
    public void MostraProposta(){
        
        colCodigo.setCellValueFactory(new PropertyValueFactory("codigo"));
        colDescricao.setCellValueFactory(new PropertyValueFactory("descricao"));
        PropostaDAO dao2 = new PropostaDAO();
        ObservableList<Proposta> proposta = dao2.getProposta();
        tabProp.setItems(proposta);
        tabProp.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
     @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
               selecionado2 = (Proposta) newValue;
            }
            
        });
}
    @FXML
    private void deletaLixo(ActionEvent event){
            if(FuncaoAdmController.opcaoLixo !=null){
                LixoDAO dao = new LixoDAO();
                dao.deletaDica(FuncaoAdmController.opcaoLixo);
                Alert a=new Alert(Alert.AlertType.CONFIRMATION);
                a.setHeaderText("Local deletado com sucesso!");
                a.showAndWait();
                preencheTabelaLixo();
            }else{
                Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Por favor, selecione um Local!");
                a.showAndWait();
            }
}
}
       
       
  
    
