package controller;

import static controller.FuncaoAdmController.selecionado2;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
//import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import jdbc.DicasDAO;
import static jdbc.LixoDAO.InsereLocal;
import jdbc.PropostaDAO;
import static jdbc.PropostaDAO.insereProposta;
import model.Dicas;
import model.Lixo;
import model.Proposta;



public class FuncaoUsuController implements Initializable {
    
     @FXML private Button btVisu;
    @FXML private Button btenvia;
    @FXML private Button btsair;
    @FXML private Button btadicionar;
    @FXML private Button btexcluir;
    
    @FXML private TextArea txtproposta;
     @FXML private TextField digiPesquisa;
    
    @FXML private TabPane funnUSU;
    
    @FXML private Tab tabCadProp;
    @FXML private Tab tabVisuGraficos;
    @FXML private Tab tabVisuDicas;
    @FXML private Tab tabCadLixo;

    
   @FXML TableView<Proposta> tabelaProposta;
    
    @FXML TableColumn <Proposta,Integer>colunaID;
    @FXML TableColumn <Proposta,String>colunaDescricao;
    
    @FXML private TextField nome;
    @FXML private TextField bairro;
    @FXML private TextField rua;
    @FXML private DatePicker data;
    @FXML private ImageView b; 
    private static Proposta opcaoProposta;
    @FXML private TableView <Dicas> tvDicas;
    
    @FXML private TableColumn <Dicas, Integer > colCodigo2;
    @FXML private TableColumn <Dicas, String> colDescricao2;
    
    
    
   
      @FXML
        public void CadProposta(ActionEvent t) {  
            if(txtproposta.getText().equals("") ){
            
           Alert al = new Alert (Alert.AlertType.WARNING);
           al.setTitle("Atenção!");
           al.setHeaderText("Os Campos Estão Vazios");
           al.setContentText("Por favor, preencha os campos!");
           al.showAndWait(); 
             
         }else {
            try {
                
                Proposta proposta = new Proposta ();
                proposta.setDescricao(txtproposta.getText());
                insereProposta(proposta);
            
            Alert a = new Alert(Alert.AlertType.INFORMATION);
             a.setTitle("VERIFICAÇÃO DE CADASTRO");
              a.setHeaderText("Campos digitados corretamente");
               a.setContentText("OK, Cadastro realizado");
               a.showAndWait();
                MostraProposta();
                clearForm();
            }catch (Exception e){
                System.out.println("Erro ao Cadastrar uma proposta: " + e.getMessage());
               
            }    
        }
    }
    
    public void start(Stage usu) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FuncaoUsu.fxml"));
        Scene scene = new Scene(root);
        usu.setTitle("Usuário");
        usu.setScene(scene);
        usu.show();
    }
    
    
    public void MostraProposta(){
        
        colunaID.setCellValueFactory(new PropertyValueFactory("codigo"));
        colunaDescricao.setCellValueFactory(new PropertyValueFactory("descricao"));
        PropostaDAO dao = new PropostaDAO();
        ObservableList<Proposta> proposta = dao.getProposta();
        tabelaProposta.setItems(proposta);
        tabelaProposta.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
     @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
               selecionado2 = (Proposta) newValue;
            }
            
        });
    
    }
    
    public void clearForm(){
        txtproposta.clear();
    }
    
     @FXML public void Lixo(){
         if(nome.getText().equals("")||
            bairro.getText().equals("")||
            rua.getText().equals("")||
            data.getValue().equals("")){
               
             Alert alertli = new Alert(Alert.AlertType.WARNING);
                alertli.setTitle("Atenção!!");
                alertli.setHeaderText("Seus Campos estão vazios");
                alertli.setContentText("Por favor, preencha-os. ");
                alertli.showAndWait();
           
             }else {
            try{
                 Lixo lixo = new Lixo();
                 lixo.setNome(nome.getText());
                 lixo.setBairro(bairro.getText());
                 lixo.setRua(rua.getText());
                 lixo.setData(data.getValue());
                 InsereLocal(lixo);
                 
                  Alert mensagem = new Alert(Alert.AlertType.INFORMATION);
                    mensagem.setTitle("VERIFICAÇÃO DE ENVIO");
                    mensagem.setContentText("OK, envio realizado");
                    mensagem.showAndWait();
                
                  }catch (Exception e){
                System.out.println("Erro ao Enviar: " + e.getMessage());
            }
         }
     }
         @FXML
        public void Sair(ActionEvent t) {  
            Stage stage = (Stage) btsair.getScene().getWindow();  
            stage.close();  
        
     }
    @Override
    public void initialize(URL location, ResourceBundle resources) {
    MostraProposta();
    MostraDicas();
    }
public void MostraDicas(){
        colCodigo2.setCellValueFactory(new PropertyValueFactory("codigo"));
        colDescricao2.setCellValueFactory(new PropertyValueFactory("descricao"));
        DicasDAO dao = new DicasDAO();
        ObservableList<Dicas> dicas = dao.getDicas();
        tvDicas.setItems(dicas);
        

    }
@FXML
    private void deletaProposta(ActionEvent event){
            if(FuncaoAdmController.selecionado2 !=null){
                PropostaDAO dao3 = new PropostaDAO();
                dao3.deletaProposta(FuncaoAdmController.selecionado2);
                
                Alert a=new Alert(Alert.AlertType.CONFIRMATION);
                a.setHeaderText("Proposta deletada com sucesso!");
                a.showAndWait();
                MostraProposta();
            }else{
                Alert a=new Alert(Alert.AlertType.ERROR);
                a.setHeaderText("Por favor, selecione uma proposta!");
                a.showAndWait();
            }
    }
    @FXML
    public void grafico() {
        btVisu.setOnMouseClicked((MouseEvent b) -> {
            GraficoController opens= new GraficoController();
            try {
                opens.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(GraficoController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

    }
}