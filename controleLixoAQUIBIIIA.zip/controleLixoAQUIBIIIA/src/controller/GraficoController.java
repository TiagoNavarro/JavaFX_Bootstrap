/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;
/**
 * 

 * @author Beatriz
 */
public class GraficoController extends Application {
    final static String janeiro = "Janeiro";
    final static String favereiro = "Fevereiro";
    final static String marco = "Março";
    final static String abril = "Abril";
    final static String maio = "Maio";
    final static String junho = "Junho";
    final static String julho= "Julho";
    final static String agosto = "Agosto";
    final static String setembro = "Setembro";
    final static String outubro = "Outubro";
    final static String novembro = "Novembro";
    final static String dezembro = "Dezembro";
 
    @Override public void start(Stage stage) {
        stage.setTitle("Ano");
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        final BarChart<String,Number> bc = 
            
                
        new BarChart<String,Number>(xAxis,yAxis);
        bc.setTitle("Quantidade de lixo produzido no ano");
        xAxis.setLabel("Mês");       
        yAxis.setLabel("Toneladas");
 
        XYChart.Series series1 = new XYChart.Series();
        series1.setName("2013");       
        series1.getData().add(new XYChart.Data(janeiro, 25601.34));
        series1.getData().add(new XYChart.Data(favereiro, 20148.82));
        series1.getData().add(new XYChart.Data(marco, 10000));
        series1.getData().add(new XYChart.Data(abril, 35407.15));
        series1.getData().add(new XYChart.Data(maio, 12000));
        series1.getData().add(new XYChart.Data(junho, 22000));
        series1.getData().add(new XYChart.Data(julho, 7000));
        series1.getData().add(new XYChart.Data(agosto, 8000));
        series1.getData().add(new XYChart.Data(setembro, 13000));
        series1.getData().add(new XYChart.Data(outubro, 16500));
        series1.getData().add(new XYChart.Data(novembro, 19900));
        series1.getData().add(new XYChart.Data(dezembro, 40000));
        
        XYChart.Series series2 = new XYChart.Series();
        series2.setName("2014");
        series2.getData().add(new XYChart.Data(janeiro, 57401.85));
        series2.getData().add(new XYChart.Data(favereiro, 41941.19));
        series2.getData().add(new XYChart.Data(marco, 45263.37));
        series2.getData().add(new XYChart.Data(abril, 11732.16));
        series2.getData().add(new XYChart.Data(maio, 14845.27));  
        series2.getData().add(new XYChart.Data(junho, 7777));
        series2.getData().add(new XYChart.Data(julho, 16753.12));
        series2.getData().add(new XYChart.Data(agosto, 10567));
        series2.getData().add(new XYChart.Data(setembro, 13466));
        series2.getData().add(new XYChart.Data(outubro, 34227));
        series2.getData().add(new XYChart.Data(novembro, 36777));
        series2.getData().add(new XYChart.Data(dezembro, 39455));
        
        XYChart.Series series3 = new XYChart.Series();
        series3.setName("2015");
        series3.getData().add(new XYChart.Data(janeiro, 45000.65));
        series3.getData().add(new XYChart.Data(favereiro, 44835.76));
        series3.getData().add(new XYChart.Data(marco, 18722.18));
        series3.getData().add(new XYChart.Data(abril, 17557.31));
        series3.getData().add(new XYChart.Data(maio, 9263.68)); 
        series3.getData().add(new XYChart.Data(junho, 16777));
        series3.getData().add(new XYChart.Data(julho, 14555));
        series3.getData().add(new XYChart.Data(agosto, 23444));
        series3.getData().add(new XYChart.Data(setembro, 22333));
        series3.getData().add(new XYChart.Data(outubro, 10999));
        series3.getData().add(new XYChart.Data(novembro, 19888));
        series3.getData().add(new XYChart.Data(dezembro, 29877.99));
        
        Scene scene  = new Scene(bc,800,600);
        bc.getData().addAll(series1, series2, series3);
        stage.setScene(scene);
        stage.show();
    }
 
   
    }
    

    