
package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javax.swing.JOptionPane;


public class TelaAdminController implements Initializable {
    @FXML private Label admsenha;
    @FXML private Label admusu;
    
    @FXML private Button btentrar;
    @FXML private Button btsair;
    
     @FXML private TextField adm;
     @FXML private PasswordField senha;
     
     @FXML private ImageView logo;
 
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    

    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("TelaAdmin.fxml"));
        
        Scene scene = new Scene(root);
        stage.setTitle("Administrador");
        stage.setScene(scene);
        stage.show();
    }
    
     public void Entrar() {
        btentrar.setOnMouseClicked((MouseEvent a) -> {
            
        if (adm.getText().equals("admin") && senha.getText().equals("admin")) {
            FuncaoAdmController abre = new FuncaoAdmController();
                try {
                abre.start(new Stage());
		} catch (Exception ex) {
                Logger.getLogger(FuncaoAdmController.class.getName()).log(Level.SEVERE, null, ex);
		}
                    } else {
		JOptionPane.showMessageDialog(null, "Login ou senha inválidos, tente novamente", "Erro", JOptionPane.ERROR_MESSAGE);
                			}
        }); 
        
}
     @FXML
        public void Sair(ActionEvent t) {  
            Stage stage = (Stage) btsair.getScene().getWindow();  
            stage.close();  
        }  
    
    }
    
    

