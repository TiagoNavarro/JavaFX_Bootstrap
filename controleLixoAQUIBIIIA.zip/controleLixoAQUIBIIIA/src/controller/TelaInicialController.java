
package controller;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class TelaInicialController implements Initializable {
    @FXML private Label bv;
    @FXML private Label seleOP;
   
     @FXML private ImageView logo;
     
    @FXML private Button btadm;
    @FXML private Button btusu;
    @FXML private Button btsair;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
      
    }  
    
      @FXML
    public void Administrador() {
        btadm.setOnMouseClicked((MouseEvent b) -> {
            TelaAdminController opens= new TelaAdminController();
            try {
                opens.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(TelaAdminController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

    }
        
      @FXML
    public void Usuario() {
        btusu.setOnMouseClicked((MouseEvent b) -> {
            TelaUsuController opens= new TelaUsuController();
            try {
                opens.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(TelaUsuController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

    }
     @FXML
     public void Sair(ActionEvent event){
       btsair.setOnMouseClicked((MouseEvent )->{
        Platform.exit();
       });
               }
}

