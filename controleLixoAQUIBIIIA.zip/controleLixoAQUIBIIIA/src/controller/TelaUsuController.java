
package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
//import javafx.scene.control.Alert;
//import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Tab;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javax.swing.JOptionPane;



public class TelaUsuController implements Initializable {
   
    @FXML private Label loginUSU;
    @FXML private Label loginSENHA;
    
    
    @FXML private Button btentrar;
    @FXML private Button btsair;
  
     
     //ENTRAR
     @FXML private TextField usuario1;
     @FXML private PasswordField senha1;
     
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
    }    
    
    public void start(Stage stage) throws IOException {
    Parent root = FXMLLoader.load(getClass().getResource("TelaUsu.fxml"));
        
        Scene scene = new Scene(root);
        stage.setTitle("Usuario");
        stage.setScene(scene);
        stage.show();
    }
    
   
               

      
       public void Entrar() {
        btentrar.setOnMouseClicked((MouseEvent a) -> {
            
        if (usuario1.getText().equals("usuario") && senha1.getText().equals("12345")) {
            try {
                FuncaoUsuController abre = new FuncaoUsuController();
                abre.start(new Stage());  
		} catch (Exception ex) {
                Logger.getLogger(FuncaoUsuController.class.getName()).log(Level.SEVERE, null, ex);
		}
                    } else {
		JOptionPane.showMessageDialog(null, "Login ou senha inválidos, tente novamente", "Erro", JOptionPane.ERROR_MESSAGE);
				}
                                
        });
        
}
     
     @FXML
        public void Sair(ActionEvent t) {  
            Stage stage = (Stage) btsair.getScene().getWindow();  
            stage.close();  
        }  
      
        
      
     
       private void clearForm(){
        senha1.clear();
        usuario1.clear();

    }
    
      
}


  



       
