
package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
     public static Connection getConnection(){
        Connection e = null; 
        try{
            e = DriverManager.getConnection("jdbc:postgresql://localhost/controleLixo","postgres", "12345"); 
        } catch (SQLException p){
            System.out.println(p.getMessage());
        }
        return e; 
    }
    }
