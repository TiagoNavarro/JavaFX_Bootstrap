/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Dicas;

/**
 *
 * @author Aluno
 */
public class DicasDAO {
    static Connection e;
    private static Connection c;
public DicasDAO(){
   DicasDAO.c = ConnectionFactory.getConnection();
    }
    public void deletaDica (Dicas dicas ){
        DicasDAO.c = ConnectionFactory.getConnection();
        String sql = "DELETE FROM dicas WHERE codigo=?";
        try{
            PreparedStatement stmt = c.prepareStatement(sql);
            stmt.setInt(1, dicas.getCodigo());
            stmt.execute();
            stmt.close();
        }catch(SQLException e){
            
        }
    }    
        
    
    
    public static void InsereDica (Dicas dica){
      Connection e = ConnectionFactory.getConnection(); 
        String sql = "INSERT INTO dicas(descricao) "
                + "VALUES(?)";
        
              try{ 
        PreparedStatement stmt = e.prepareStatement (sql);
        stmt.setString(1, dica.getDescricao());
        stmt.execute();
        stmt.close();
        
        
         }catch (SQLException p){
            System.out.println(p.getMessage());
        }
 }
        public ObservableList<Dicas> getDicas(){
            Connection p = ConnectionFactory.getConnection();
        try{
            ObservableList<Dicas> dica = FXCollections.observableArrayList();
            PreparedStatement stmt = p.prepareStatement("SELECT * FROM dicas");
            ResultSet resul = stmt.executeQuery();
            
            while(resul.next()){
                Dicas di = new Dicas ();
                di.setCodigo(resul.getInt("codigo"));
                di.setDescricao(resul.getString("descricao"));
                dica.add(di);
            }

            stmt.executeQuery();
            resul.close();
            stmt.close();
            return dica;
           
        }catch(SQLException m){
                throw new RuntimeException(m);
        
        }
                
        }
        
}           
