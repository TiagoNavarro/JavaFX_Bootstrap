/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Dicas;
import model.Lixo;

/**
 *
 * @author Beatriz
 */
public class LixoDAO {
    private static Connection c;   

    public LixoDAO(){
    LixoDAO.c = ConnectionFactory.getConnection();
    }
    
     public static void InsereLocal (Lixo lixo){
      Connection c = ConnectionFactory.getConnection(); 
        String sql = "INSERT INTO lixo(nome,bairro,rua,data)"
                + "VALUES(?,?,?,?)";
        
        Date data = Date.valueOf(lixo.getData());
              try{ 
        PreparedStatement stmt = c.prepareStatement (sql);
        stmt.setString(1, lixo.getNome());
        stmt.setString(2, lixo.getBairro());
        stmt.setString(3, lixo.getRua());
        stmt.setDate(4,data);
        
        stmt.execute();
        stmt.close();
        
         }catch (SQLException e){
            System.out.println(e.getMessage());
        }
 }
    public ObservableList<Lixo>getLixo(){
        try{
         ObservableList<Lixo> lixo = FXCollections.observableArrayList();
            PreparedStatement stmt = this.c.prepareStatement("SELECT * FROM lixo");
            ResultSet rs = stmt.executeQuery();
            
             while(rs.next( )){
                //criando o obejto f
                Lixo li = new Lixo();
                li.setId(rs.getInt("id"));
                li.setNome(rs.getString("nome"));
                li.setBairro(rs.getString("bairro"));
                li.setRua(rs.getString("rua"));
                Date dt = rs.getDate("data");
                li.setData(dt.toLocalDate());
                
                lixo.add(li);
             }
                 stmt.executeQuery();
                rs.close();
                stmt.close();
                return lixo;
                
             }catch(SQLException e){
                throw new RuntimeException(e);
        }
            }
    public void deletaDica (Lixo lixo ){
        LixoDAO.c = ConnectionFactory.getConnection(); 
        String sql = "DELETE FROM lixo WHERE id=?";
        try{
            PreparedStatement stmt2 = c.prepareStatement(sql);
            stmt2.setInt(1, lixo.getId());
            stmt2.execute();
            stmt2.close();
        }catch(SQLException f){
            
        }
    }
}
                 
        
    
    
    
    


