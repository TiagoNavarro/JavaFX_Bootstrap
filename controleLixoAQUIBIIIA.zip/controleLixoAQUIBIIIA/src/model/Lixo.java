/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.time.LocalDate;

/**
 *
 * @author Beatriz
 */
public class Lixo {
   private String nome;
   private String bairro;
   private String rua;
   private LocalDate data;
   private int id;

    public Lixo() {
    }

    public Lixo(String nome, String bairro, String rua, LocalDate data) {
        this.nome = nome;
        this.bairro = bairro;
        this.rua = rua;
        this.data = data;
        
    }
   
   
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public LocalDate getData() {
        return data;
    }
      public String getDataTabela(){
        return this.data.getDayOfMonth()+"/"+this.data.getMonthValue()+"/"+this.data.getYear();
    }

    public void setData(LocalDate data) {
        this.data = data;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

   
}
